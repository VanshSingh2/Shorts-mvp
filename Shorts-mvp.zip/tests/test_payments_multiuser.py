"""Plans, concurrent limits, crypto simulate, multi-session."""
from __future__ import annotations
import os
import pytest
from app.services.billing.plans import plan_catalog, resolve_checkout_kind, concurrent_limit_for_plan
from app.services.billing import crypto_service
from app.services import users as user_service


def test_three_paid_tiers_in_catalog():
    cat = plan_catalog()
    ids = {p["id"] for p in cat["plans"]}
    assert {"free", "pro", "studio"} <= ids
    # higher plan more credits
    by_id = {p["id"]: p for p in cat["plans"]}
    assert by_id["studio"]["credits_monthly"] > by_id["pro"]["credits_monthly"] > by_id["free"]["credits_monthly"]
    assert by_id["studio"]["max_concurrent_jobs"] > by_id["pro"]["max_concurrent_jobs"] >= by_id["free"]["max_concurrent_jobs"]


def test_resolve_kinds():
    assert resolve_checkout_kind("subscription_pro")["plan"] == "pro"
    assert resolve_checkout_kind("pack_50")["credits"] == 50
    with pytest.raises(ValueError):
        resolve_checkout_kind("nope")


def test_concurrent_limits():
    assert concurrent_limit_for_plan("free") >= 1
    assert concurrent_limit_for_plan("studio") >= concurrent_limit_for_plan("pro")


def test_crypto_simulate_grants(client, auth_headers, registered_user):
    user, token, email, password = registered_user
    # force simulate path
    from app.core import config
    config.settings.NOWPAYMENTS_API_KEY = ""
    result = crypto_service.create_crypto_invoice(user["id"], email, "pack_50")
    assert result["session_id"]
    assert result.get("simulated") is True or result["status"] in ("completed", "pending")
    # user should have more credits after sim
    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200


def test_plans_endpoint(client):
    r = client.get("/api/billing/plans")
    assert r.status_code == 200
    data = r.json()
    assert "plans" in data
    assert "packs" in data
    assert "stripe_configured" in data
    assert "crypto_configured" in data


def test_checkout_stripe_sim(client, auth_headers):
    r = client.post(
        "/api/billing/checkout",
        headers={**auth_headers, "Content-Type": "application/json"},
        json={"kind": "pack_50", "provider": "stripe"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert "checkout_url" in body
    assert "session_id" in body


def test_checkout_crypto_sim(client, auth_headers):
    r = client.post(
        "/api/billing/checkout",
        headers={**auth_headers, "Content-Type": "application/json"},
        json={"kind": "subscription_pro", "provider": "crypto"},
    )
    assert r.status_code == 200, r.text


def test_multi_login_sessions(client, registered_user):
    user, token1, email, password = registered_user
    r2 = client.post("/api/auth/login", json={"email": email, "password": password})
    assert r2.status_code == 200
    token2 = r2.json()["token"]
    assert token2 != token1
    # both tokens work
    assert client.get("/api/auth/me", headers={"Authorization": f"Bearer {token1}"}).status_code == 200
    assert client.get("/api/auth/me", headers={"Authorization": f"Bearer {token2}"}).status_code == 200
    sessions = client.get("/api/auth/sessions", headers={"Authorization": f"Bearer {token1}"})
    assert sessions.status_code == 200
    assert len(sessions.json()["sessions"]) >= 2


def test_can_start_job_helper(registered_user):
    user, token, email, password = registered_user
    ok, reason = user_service.can_start_job(user["id"])
    assert ok is True


def test_stripe_configured_false_on_placeholder():
    from app.services.billing import stripe_service
    from app.core import config
    # default placeholder
    assert stripe_service._is_configured() is False


def test_stripe_configured_true_on_real_looking_key(monkeypatch):
    from app.services.billing import stripe_service
    from app.core import config
    monkeypatch.setattr(config.settings, "STRIPE_SECRET_KEY", "sk_test_" + "x" * 24)
    assert stripe_service._is_configured() is True
    # restore-ish via next test isolation


def test_live_stripe_does_not_simulate_on_error(monkeypatch, registered_user):
    """With real-looking keys, API failure must NOT grant free credits."""
    from app.services.billing import stripe_service
    from app.core import config
    from app.services import users as user_service

    user, token, email, password = registered_user
    before = user_service.get_user(user["id"]).credits_remaining

    monkeypatch.setattr(config.settings, "STRIPE_SECRET_KEY", "sk_live_" + "y" * 24)
    monkeypatch.setattr(config.settings, "ALLOW_PAYMENT_SIMULATE", False)

    def boom(*a, **k):
        raise RuntimeError("stripe network down")

    monkeypatch.setattr(stripe_service, "_stripe_checkout", boom)

    try:
        stripe_service.create_checkout_session(user["id"], email, "pack_50")
        raised = False
    except Exception:
        raised = True
    assert raised is True
    after = user_service.get_user(user["id"]).credits_remaining
    assert after == before, "must not grant credits on live failure"
