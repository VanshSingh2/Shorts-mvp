#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH=.
mkdir -p uploads outputs backgrounds temp data assets samples
if [[ ! -f .env && -f .env.example ]]; then
  cp .env.example .env
  echo "Created .env from .env.example – edit secrets before production."
fi

# Install deps on first run (or after requirements.txt changes), then always
# pull the newest yt-dlp — YouTube changes its bot-check constantly.
# Skip with SKIP_DEP_INSTALL=1.
if [[ "${SKIP_DEP_INSTALL:-0}" != "1" ]]; then
  PYBIN="python3"; command -v python3 >/dev/null 2>&1 || PYBIN="python"
  echo "Checking dependencies…"
  "$PYBIN" -m pip install -q -r requirements.txt
  echo "Upgrading yt-dlp to the latest version…"
  "$PYBIN" -m pip install -q -U yt-dlp
fi

# Deno = JS runtime yt-dlp needs for YouTube n-sig / "page needs to be reloaded"
# Install quietly if missing (Codespaces / Linux). Skip with SKIP_DENO_INSTALL=1.
if [[ "${SKIP_DENO_INSTALL:-0}" != "1" ]]; then
  if ! command -v deno >/dev/null 2>&1 && [[ ! -x "${HOME}/.deno/bin/deno" ]]; then
    echo "Installing Deno (required by yt-dlp for YouTube JS challenges)…"
    curl -fsSL https://deno.land/install.sh | sh
  fi
  if [[ -x "${HOME}/.deno/bin/deno" ]]; then
    export PATH="${HOME}/.deno/bin:${PATH}"
  fi
  if command -v deno >/dev/null 2>&1; then
    echo "Deno OK: $(deno --version 2>/dev/null | head -1)"
  else
    echo "WARNING: Deno not found — YouTube downloads may fail JS challenges."
  fi
fi

# Codespace / offline helper: tiny sample video for YOUTUBE_MOCK_DOWNLOAD_PATH
if [[ ! -f samples/sample.mp4 ]] && command -v ffmpeg >/dev/null 2>&1; then
  echo "Creating samples/sample.mp4 for offline YouTube pipeline tests…"
  ffmpeg -y -f lavfi -i color=c=blue:s=1280x720:d=15 -f lavfi -i sine=f=440:d=15 \
    -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest samples/sample.mp4 >/dev/null 2>&1 || true
fi

exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}" --reload
