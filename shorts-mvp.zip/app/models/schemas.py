from enum import Enum
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, EmailStr
from datetime import datetime


class JobStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    TRANSCRIBING = "transcribing"
    GENERATING_VOICE = "generating_voice"
    COMPOSING = "composing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class CaptionStyle(str, Enum):
    CLASSIC = "classic"
    BOLD_YELLOW = "bold_yellow"
    MINIMAL = "minimal"
    KARAOKE = "karaoke"
    NEON = "neon"
    BOUNCE = "bounce"
    POP = "pop"


class VoiceOption(str, Enum):
    JENNY = "en-US-JennyNeural"
    GUY = "en-US-GuyNeural"
    SONIA = "en-GB-SoniaNeural"
    ARIA = "en-US-AriaNeural"
    DAVIS = "en-US-DavisNeural"
    JANE = "en-US-JaneNeural"


class TemplateType(str, Enum):
    STANDARD = "standard"
    REDDIT_STORY = "reddit_story"
    FAKE_TEXT = "fake_text"
    SPLIT_SCREEN = "split_screen"
    YOUTUBE_REELS = "youtube_reels"
    AI_VISUAL = "ai_visual"  # faceless: AI scenes + Ken Burns + TTS + captions


class FakeTextPlatform(str, Enum):
    IMESSAGE = "imessage"
    WHATSAPP = "whatsapp"
    GENERIC = "generic"


class FakeTextMessage(BaseModel):
    sender: str = Field(..., description="'me' or 'them' or a name")
    text: str
    is_me: bool = False


class RedditStoryRequest(BaseModel):
    title: str = Field(..., max_length=300)
    body: str = Field(..., max_length=5000)
    subreddit: str = Field("r/AmItheAsshole", max_length=50)
    username: str = Field("u/Anonymous", max_length=40)
    upvotes: str = Field("12.4k", max_length=12)
    awards: int = Field(0, ge=0, le=20)


class FakeTextRequest(BaseModel):
    platform: FakeTextPlatform = FakeTextPlatform.IMESSAGE
    contact_name: str = Field("Alex", max_length=40)
    messages: List[FakeTextMessage] = Field(..., min_length=1, max_length=30)
    narrate: bool = True


class SplitScreenRequest(BaseModel):
    """Top = reaction/webcam area, bottom = content (gameplay or secondary video)."""
    top_label: str = Field("Streamer", max_length=40)
    layout: str = Field("top_bottom", description="top_bottom | left_right | pip")
    show_webcam_placeholder: bool = True


class YoutubeReelsRequest(BaseModel):
    """Create multiple vertical reels from a YouTube video's main moments.

    Enhanced with LLM virality ranking (hooks, emotional peaks, opinion bombs, etc.)
    inspired by https://github.com/Anil-matcha/AI-Youtube-Shorts-Generator.
    Falls back to energy/silence detection when no LLM key is configured.
    """
    url: str = Field(..., min_length=10, max_length=500)
    max_clips: int = Field(5, ge=1, le=10)
    min_clip_sec: float = Field(12.0, ge=5.0, le=30.0)
    max_clip_sec: float = Field(45.0, ge=10.0, le=90.0)
    burn_captions: bool = True
    captions_from: str = Field("original", description="original | none")
    use_llm_highlights: bool = Field(
        True,
        description="Use LLM virality scoring when available (score + hook + reason per clip)",
    )


class AiVisualRequest(BaseModel):
    """Faceless AI reel: script (or topic) → scene images → video.

    Renderer options:
    - ken_burns (default): built-in MoviePy/FFmpeg Ken Burns slideshow
    - hyperframes: HTML/CSS/GSAP composition via https://github.com/heygen-com/hyperframes
      (requires Node.js >= 22 and HYPERFRAMES_ENABLED=true)
    - auto: prefer HyperFrames when available, else Ken Burns
    """
    topic: Optional[str] = Field(None, max_length=200)
    max_scenes: int = Field(4, ge=2, le=8)
    image_style: str = Field(
        "cinematic",
        description="cinematic | illustration | photo | minimal",
    )
    renderer: str = Field(
        "auto",
        description="ken_burns | hyperframes | auto",
    )


class CreateJobRequest(BaseModel):
    template: TemplateType = TemplateType.STANDARD
    script: Optional[str] = Field(None, description="Plain text script for STANDARD / narration")
    caption_style: CaptionStyle = CaptionStyle.CLASSIC
    voice: VoiceOption = VoiceOption.JENNY
    background_id: Optional[str] = None
    burn_captions: bool = True
    # Manual captions: plain lines or simple "start-end text" lines
    manual_captions: Optional[str] = Field(
        None,
        max_length=8000,
        description="Optional user captions. Plain text (auto-timed) or SRT-like blocks.",
    )
    reddit: Optional[RedditStoryRequest] = None
    fake_text: Optional[FakeTextRequest] = None
    split_screen: Optional[SplitScreenRequest] = None
    youtube: Optional[YoutubeReelsRequest] = None
    ai_visual: Optional[AiVisualRequest] = None
    trim_start: float = Field(0.0, ge=0)
    trim_end: Optional[float] = None
    volume: float = Field(1.0, ge=0.0, le=2.0)


class JobResponse(BaseModel):
    id: str
    status: JobStatus
    progress: float = 0.0
    message: str = ""
    created_at: datetime
    updated_at: datetime
    output_url: Optional[str] = None
    error: Optional[str] = None
    input_type: str = "script"
    template: str = "standard"
    caption_style: str = "classic"
    voice: str = "en-US-JennyNeural"
    user_id: Optional[str] = None
    extra_outputs: Optional[List[str]] = None
    renderer_used: Optional[str] = None  # "ken_burns" | "hyperframes" (ai_visual only) — lets you tell outputs apart


class TweakRequest(BaseModel):
    """Post-generation tweaks without full re-pipeline where possible."""
    caption_style: Optional[CaptionStyle] = None
    trim_start: Optional[float] = Field(None, ge=0)
    trim_end: Optional[float] = None
    volume: Optional[float] = Field(None, ge=0.0, le=2.0)


class TranscriptSegment(BaseModel):
    start: float
    end: float
    text: str
    words: Optional[List[Dict[str, Any]]] = None


class BackgroundInfo(BaseModel):
    id: str
    name: str
    path: str
    duration: Optional[float] = None
    thumbnail: Optional[str] = None


class HealthResponse(BaseModel):
    status: str
    version: str = "0.7.0"
    deploy_mode: str = "growth"
    whisper_model: str
    available_voices: List[str]
    available_styles: List[str]
    available_templates: List[str]
    image_gen_enabled: bool = False
    llm_configured: bool = False
    redis_available: bool = False
    queue_backend: str = "background"  # celery | background


class UserCreate(BaseModel):
    email: EmailStr
    name: Optional[str] = None
    password: str = Field(..., min_length=8, max_length=128)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    id: str
    email: str
    name: Optional[str]
    plan: str = "free"
    credits_remaining: int = 20
    videos_this_week: int = 0
    created_at: datetime


class UsageLimits(BaseModel):
    plan: str
    max_videos_per_week: int
    max_batch_size: int
    credits_remaining: int
    voice_clone_enabled: bool = False
    storage_used_mb: float = 0
    storage_limit_mb: float = 500


class BatchJobRequest(BaseModel):
    jobs: List[CreateJobRequest] = Field(..., min_length=1, max_length=10)


class CheckoutRequest(BaseModel):
    kind: str = Field(..., description="subscription_pro | subscription_studio | pack_50 | pack_150 | pack_500")
    provider: str = Field("stripe", description="stripe | crypto")


class CheckoutResponse(BaseModel):
    checkout_url: str
    session_id: str


class ScriptGenerateRequest(BaseModel):
    topic: str = Field(..., min_length=2, max_length=200)
    brief: str = Field("", max_length=2000)
    tone: str = Field("engaging", max_length=40)  # engaging|educational|story|hype|calm
    length: str = Field("medium", max_length=20)  # short|medium|long
    language: str = Field("en", max_length=12)


class ScriptGenerateResponse(BaseModel):
    script: str
    provider: str
    model: str

