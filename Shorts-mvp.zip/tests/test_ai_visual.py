"""AI visual + manual captions helpers."""
from app.models.schemas import TranscriptSegment, TemplateType, CreateJobRequest, AiVisualRequest
from app.services.pipeline import _apply_manual_captions
from app.services.transcription import parse_srt_text, segments_to_srt


def test_template_includes_ai_visual():
    assert TemplateType.AI_VISUAL.value == "ai_visual"
    req = CreateJobRequest(
        template=TemplateType.AI_VISUAL,
        script="Hello world this is a test script for a short video about habits.",
        ai_visual=AiVisualRequest(topic="habits", max_scenes=3),
    )
    assert req.template == TemplateType.AI_VISUAL


def test_manual_captions_plain_lines():
    segs = [
        TranscriptSegment(start=0, end=2, text="old"),
        TranscriptSegment(start=2, end=4, text="old2"),
    ]
    out = _apply_manual_captions("First line\nSecond line\nThird", segs, audio_duration=6.0)
    assert len(out) == 3
    assert out[0].text == "First line"
    assert out[-1].end <= 6.01


def test_parse_srt_roundtrip():
    segs = [
        TranscriptSegment(start=0.0, end=1.5, text="Hello there"),
        TranscriptSegment(start=1.5, end=3.0, text="World"),
    ]
    srt = segments_to_srt(segs)
    parsed = parse_srt_text(srt)
    assert len(parsed) == 2
    assert "Hello" in parsed[0].text
