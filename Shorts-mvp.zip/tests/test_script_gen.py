from app.services.script_gen import _local_script
import asyncio
from app.services.script_gen import generate_script


def test_local_script_has_hook_and_body():
    s = _local_script("cold showers", "boost alertness and mood", "engaging", "medium")
    assert "cold showers" in s.lower()
    assert len(s) > 80


def test_generate_script_fallback():
    r = asyncio.run(
        generate_script("productivity", "one tip about focus", tone="educational", length="short")
    )
    assert r["provider"] in ("local", "llm")
    assert len(r["script"]) > 40


def test_generate_script_endpoint(client):
    r = client.post("/api/generate-script", json={
        "topic": "morning routines",
        "brief": "simple 3-step routine for beginners",
        "tone": "calm",
        "length": "short",
    })
    assert r.status_code == 200, r.text
    data = r.json()
    assert "script" in data
    assert len(data["script"]) > 40
