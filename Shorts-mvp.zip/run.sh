#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH=.
mkdir -p uploads outputs backgrounds temp data assets samples
if [[ -f .venv/bin/activate ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi
if [[ ! -f .env && -f .env.example ]]; then
  cp .env.example .env
  echo "Created .env from .env.example"
fi
if [[ "${SKIP_DEP_INSTALL:-0}" != "1" ]]; then
  PYBIN="python3"; command -v python3 >/dev/null 2>&1 || PYBIN="python"
  echo "Checking dependencies…"
  "$PYBIN" -m pip install -q -r requirements.txt || true
  "$PYBIN" -m pip install -q -U yt-dlp || true
fi
RELOAD_ARGS=()
if [[ "${DEV_RELOAD:-0}" == "1" ]]; then
  RELOAD_ARGS=(--reload)
fi
exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}" "${RELOAD_ARGS[@]}"
