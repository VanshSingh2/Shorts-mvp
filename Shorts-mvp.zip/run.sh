#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH=.
mkdir -p uploads outputs backgrounds temp data assets
if [[ ! -f .env && -f .env.example ]]; then
  cp .env.example .env
  echo "Created .env from .env.example – edit secrets before production."
fi
exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}" --reload
