"""Background removal and simple visual effects (Phase 4)."""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_rembg_available = None


def rembg_available() -> bool:
    global _rembg_available
    if _rembg_available is None:
        try:
            from rembg import remove  # noqa: F401
            _rembg_available = True
        except Exception:
            _rembg_available = False
    return _rembg_available


def remove_background_image(input_path: Path, output_path: Path) -> Path:
    """Remove background from a still image using rembg."""
    if not rembg_available():
        raise RuntimeError("rembg not installed")
    from rembg import remove
    from PIL import Image
    img = Image.open(input_path)
    out = remove(img)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    out.save(output_path)
    return output_path


def extract_frame(video_path: Path, t: float, out_path: Path) -> Path:
    subprocess.run(
        ["ffmpeg", "-y", "-ss", str(t), "-i", str(video_path), "-frames:v", "1", str(out_path)],
        capture_output=True, check=True,
    )
    return out_path
