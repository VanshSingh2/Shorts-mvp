"""Shared SlowAPI limiter instance used by main + routes."""
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.core.config import settings

limiter = Limiter(
    key_func=get_remote_address,
    default_limits=[getattr(settings, "RATE_LIMIT_DEFAULT", "60/minute")],
)
