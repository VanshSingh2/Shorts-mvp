# Background video library

Drop **vertical or landscape** gameplay / B-roll clips here (`.mp4`, `.mov`, `.webm`, `.mkv`).

They appear in `GET /api/backgrounds` and can be selected via `background_id` when creating a job.

## Licensing

Only use media you have rights to (your own footage, properly licensed stock, or public-domain).

Suggested free sources (check each license):
- Pexels Videos
- Pixabay
- Coverr
- Mixkit

Do **not** upload copyrighted TV/game footage you do not own the rights to redistribute.

## Naming

Prefer short lowercase names: `subway_surfers_01.mp4`, `minecraft_parkour.mp4`.
