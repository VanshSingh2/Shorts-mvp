"""AI script generation from topic + brief.

Uses an OpenAI-compatible chat API when configured (OpenAI, Groq, Together, OpenRouter, etc.).
Falls back to a structured local template generator when no key is set so the product
always works offline / free-tier.
"""
from __future__ import annotations

import logging
import re
from typing import Optional

import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You write short-form vertical video scripts (TikTok / Reels / Shorts).

Rules:
- Length: about 80–180 words (roughly 30–60 seconds spoken).
- Hook in the first sentence (curiosity, bold claim, or question).
- Conversational, spoken English — not essay tone.
- Short sentences. Line breaks between beats so TTS sounds natural.
- End with a soft CTA or punchline (comment, follow, or takeaway).
- No hashtags, no emoji spam, no stage directions like [pause].
- Do not wrap the script in quotes or markdown fences.
- Output ONLY the script text."""


def _local_script(topic: str, brief: str, tone: str, length: str) -> str:
    """Deterministic, usable script when no LLM is configured."""
    topic = (topic or "this topic").strip()
    brief = (brief or "").strip()
    tone = (tone or "engaging").strip().lower()
    length = (length or "medium").strip().lower()

    openers = {
        "engaging": f"Here's something most people get wrong about {topic}.",
        "educational": f"In under a minute, here's the simple truth about {topic}.",
        "story": f"I used to think {topic} was complicated — until this.",
        "hype": f"If you care about {topic}, you need to hear this.",
        "calm": f"Let's talk about {topic} in a clear way.",
    }
    opener = openers.get(tone, openers["engaging"])

    body_bits = []
    if brief:
        # Turn brief into 2–3 spoken beats
        cleaned = re.sub(r"\s+", " ", brief).strip()
        parts = re.split(r"(?<=[.!?])\s+|;|\n| - ", cleaned)
        parts = [p.strip(" -•\t") for p in parts if p.strip()]
        if not parts:
            parts = [cleaned]
        for p in parts[:4]:
            if not p.endswith((".", "!", "?")):
                p = p + "."
            body_bits.append(p)
    else:
        body_bits = [
            f"First, focus on the one idea that actually moves the needle with {topic}.",
            "Skip the noise. Do the simple version consistently.",
            "That's how results compound instead of stalling.",
        ]

    if length == "short":
        body_bits = body_bits[:2]
    elif length == "long":
        body_bits.append(
            f"When you apply this to {topic}, the next step becomes obvious — and easier to start today."
        )

    closer = {
        "engaging": "If that clicked, save this and try it once this week.",
        "educational": "That's the core. Master that, and the rest gets easier.",
        "story": "That's the shift. Curious if you've seen the same — drop a comment.",
        "hype": "Don't overthink it. Start, adjust, repeat.",
        "calm": "Take what you need from this and leave the rest.",
    }.get(tone, "If this helped, follow for more practical breakdowns.")

    lines = [opener, ""] + body_bits + ["", closer]
    return "\n".join(lines).strip()


async def generate_script(
    topic: str,
    brief: str = "",
    *,
    tone: str = "engaging",
    length: str = "medium",
    language: str = "en",
) -> dict:
    """
    Returns {script, provider, model}.
    provider is "llm" or "local".
    """
    topic = (topic or "").strip()
    if len(topic) < 2:
        raise ValueError("Topic is required (at least 2 characters)")
    if len(topic) > 200:
        raise ValueError("Topic too long (max 200 characters)")
    brief = (brief or "").strip()
    if len(brief) > 2000:
        raise ValueError("Brief too long (max 2000 characters)")

    if settings.LLM_API_KEY and settings.LLM_BASE_URL:
        try:
            script = await _llm_script(topic, brief, tone=tone, length=length, language=language)
            return {
                "script": script,
                "provider": "llm",
                "model": settings.LLM_MODEL,
            }
        except Exception as e:
            logger.warning(f"LLM script generation failed, using local fallback: {e}")

    return {
        "script": _local_script(topic, brief, tone, length),
        "provider": "local",
        "model": "template-v1",
    }


async def _llm_script(
    topic: str,
    brief: str,
    *,
    tone: str,
    length: str,
    language: str,
) -> str:
    length_hint = {
        "short": "about 60–90 words (20–30 seconds)",
        "medium": "about 100–150 words (35–50 seconds)",
        "long": "about 150–200 words (50–70 seconds)",
    }.get(length, "about 100–150 words")

    user = (
        f"Topic: {topic}\n"
        f"Creator brief: {brief or '(none — invent a useful angle)'}\n"
        f"Tone: {tone}\n"
        f"Target length: {length_hint}\n"
        f"Language: {language}\n\n"
        "Write the spoken script now."
    )

    headers = {
        "Authorization": f"Bearer {settings.LLM_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": settings.LLM_MODEL,
        "temperature": 0.8,
        "max_tokens": 600,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ],
    }
    url = settings.LLM_BASE_URL.rstrip("/") + "/chat/completions"
    async with httpx.AsyncClient(timeout=45.0) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()
    text = data["choices"][0]["message"]["content"].strip()
    # Strip accidental fences
    text = re.sub(r"^```(?:\w+)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    if len(text) < 40:
        raise ValueError("LLM returned an empty or too-short script")
    return text
