"""Legal pages serve HTML."""
from fastapi.testclient import TestClient


def test_terms(client: TestClient):
    r = client.get("/terms")
    assert r.status_code == 200
    assert "Terms" in r.text


def test_privacy(client: TestClient):
    r = client.get("/privacy")
    assert r.status_code == 200
    assert "Privacy" in r.text


def test_content_policy(client: TestClient):
    r = client.get("/content-policy")
    assert r.status_code == 200
    assert "Content Policy" in r.text or "Prohibited" in r.text


def test_ready(client: TestClient):
    r = client.get("/api/ready")
    assert r.status_code == 200
    assert r.json()["status"] == "ready"
