/* Clipforge frontend — wired to /api · v0.8 */

/* ── theme (light/dark, persisted) ──────────────────── */
function toggleTheme() {
  const cur = document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', cur);
  localStorage.setItem('shorts_theme', cur);
  const meta = document.getElementById('meta-theme-color');
  if (meta) meta.setAttribute('content', cur === 'light' ? '#faf9f6' : '#06070b');
}

let mode = 'ai';
let template = 'standard';
let pollTimer = null;
let currentJobId = null;
let token = localStorage.getItem('shorts_token') || null;
let authMode = 'login';
let currentUser = null;
let plansCache = null;
let _lastAuthRefresh = 0;
let _authRefreshInFlight = null;

/* ── helpers ─────────────────────────────────────────── */
function authHeaders() {
  const h = {};
  if (token) h['Authorization'] = 'Bearer ' + token;
  return h;
}

function apiError(data, fallback) {
  if (!data) return fallback || 'Request failed';
  const d = data.detail;
  if (typeof d === 'string') return d;
  if (Array.isArray(d)) return d.map(x => x.msg || JSON.stringify(x)).join('; ');
  if (d && typeof d === 'object') return d.msg || JSON.stringify(d);
  return data.message || fallback || 'Request failed';
}

function toast(msg, ok) {
  const root = document.getElementById('toast-root');
  if (!root) return;
  const el = document.createElement('div');
  el.className = 'toast text-sm ' + (ok ? 'text-tide' : 'text-ink-soft');
  el.textContent = msg;
  root.appendChild(el);
  setTimeout(() => el.remove(), 3400);
}

function showApp() {
  document.getElementById('view-landing').classList.add('hidden');
  document.getElementById('view-app').classList.remove('hidden');
}

function showLanding() {
  document.getElementById('view-app').classList.add('hidden');
  document.getElementById('view-landing').classList.remove('hidden');
}

/* ── mobile off-canvas sidebar ───────────────────────── */
function openMobileNav() {
  document.getElementById('app-sidebar').classList.remove('-translate-x-full');
  document.getElementById('sidebar-backdrop').classList.remove('hidden');
}
function closeMobileNav() {
  document.getElementById('app-sidebar').classList.add('-translate-x-full');
  document.getElementById('sidebar-backdrop').classList.add('hidden');
}

/* ── navigation ──────────────────────────────────────── */
const VALID_PAGES = ['create', 'library', 'billing', 'account'];

function navigate(page, opts) {
  opts = opts || {};
  if (!VALID_PAGES.includes(page)) page = 'create';

  ['create', 'library', 'billing', 'account'].forEach(p => {
    const el = document.getElementById('page-' + p);
    if (el) el.classList.toggle('hidden', p !== page);
  });
  document.querySelectorAll('[data-page]').forEach(b => {
    b.classList.toggle('on', b.dataset.page === page);
  });
  const titles = {
    create:  ['New short', 'Pick a tool and generate'],
    library: ['Library', 'Your recent renders'],
    billing: ['Plans & billing', 'Upgrade or buy credits'],
    account: ['Account', 'Profile and usage'],
  };
  const t = titles[page] || titles.create;
  document.getElementById('page-title').textContent = t[0];
  document.getElementById('page-sub').textContent = t[1];
  if (page === 'library') loadJobs();
  if (page === 'billing') renderBilling();
  if (page === 'account') renderAccount();
  closeMobileNav();

  // Real browser history entry per page so Back/Forward move between
  // in-app pages instead of leaving the app or landing somewhere stale.
  if (!opts.fromPopstate) {
    const url = '#' + page;
    if (window.location.hash !== url) {
      history.pushState({ page }, '', url);
    } else {
      history.replaceState({ page }, '', url);
    }
  }
}

function navigateFromHash(replace) {
  const page = (window.location.hash || '#create').replace('#', '') || 'create';
  navigate(VALID_PAGES.includes(page) ? page : 'create', { fromPopstate: true });
  if (replace) history.replaceState({ page }, '', '#' + page);
}

window.addEventListener('popstate', (e) => {
  const page = (e.state && e.state.page) || (window.location.hash || '#create').replace('#', '');
  navigate(VALID_PAGES.includes(page) ? page : 'create', { fromPopstate: true });
});

/* ── template / mode ─────────────────────────────────── */
function setTemplate(t) {
  template = t;
  document.querySelectorAll('#tool-picker .tool').forEach(b => {
    b.classList.toggle('on', b.dataset.tmpl === t);
  });
  const map = {
    standard:     'panel-standard',
    reddit_story: 'panel-reddit',
    fake_text:    'panel-fake',
    split_screen: 'panel-split',
    youtube_reels:'panel-youtube',
    ai_visual:    'panel-ai_visual',
  };
  Object.values(map).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  });
  if (map[t]) document.getElementById(map[t]).classList.remove('hidden');
  const btn = document.getElementById('submit-btn');
  if (t === 'youtube_reels') btn.textContent = 'Generate viral reels';
  else if (t === 'ai_visual') btn.textContent = 'Generate AI Visual';
  else btn.textContent = 'Generate Short';
}

function setMode(m) {
  mode = m;
  document.getElementById('ai-panel').classList.toggle('hidden', m !== 'ai');
  document.getElementById('upload-panel').classList.toggle('hidden', m !== 'upload');
  const sp = document.getElementById('script-panel');
  if (m === 'upload') sp.classList.add('hidden');
  else sp.classList.remove('hidden');
  ['ai', 'script', 'upload'].forEach(x => {
    const el = document.getElementById('mode-' + x);
    if (!el) return;
    if (m === x) {
      el.className = 'tab-pill on px-3.5 py-1.5 rounded-lg text-xs font-medium border border-transparent';
    } else {
      el.className = 'tab-pill px-3.5 py-1.5 rounded-lg text-xs font-medium text-ink-muted border border-white/10';
    }
  });
}

/* ── AI script ───────────────────────────────────────── */
async function generateAIScript() {
  const topic = document.getElementById('topic').value.trim();
  if (!topic) { toast('Enter a topic first'); return; }
  const btn = event?.target;
  if (btn) { btn.disabled = true; btn.textContent = 'Generating…'; }
  try {
    const res = await fetch('/api/generate-script', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({
        topic,
        brief: document.getElementById('brief').value.trim(),
        tone: 'engaging',
        length: 'medium',
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Script generation failed'));
    document.getElementById('script').value = data.script || data.text || '';
    toast('Script ready', true);
  } catch (e) {
    toast(e.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Generate script with AI'; }
  }
}

/* ── backgrounds ─────────────────────────────────────── */
async function loadBackgrounds() {
  try {
    const res = await fetch('/api/backgrounds');
    const data = await res.json();
    const sel = document.getElementById('background');
    const list = data.backgrounds || data || [];
    list.forEach(b => {
      const id = b.id || b;
      const name = b.name || b.id || b;
      const o = document.createElement('option');
      o.value = id;
      o.textContent = name;
      sel.appendChild(o);
    });
  } catch (_) { /* offline ok */ }
}

/* ── badges ──────────────────────────────────────────── */
function badgeClass(status) {
  const s = (status || '').toLowerCase();
  if (s === 'completed') return 'b-ok';
  if (s === 'failed' || s === 'cancelled') return 'b-fail';
  if (s === 'pending') return 'b-wait';
  return 'b-run';
}

/* ── library ─────────────────────────────────────────── */
async function loadJobs() {
  const list = document.getElementById('jobs-list');
  if (!token) {
    list.innerHTML = '<p class="text-sm text-ink-muted py-12 text-center">Log in to see your library.</p>';
    return;
  }
  list.innerHTML = '<div class="space-y-3">' +
    [1,2,3].map(() => '<div class="glass rounded-xl p-4 h-16 skeleton"></div>').join('') +
    '</div>';
  try {
    const res = await fetch('/api/jobs?limit=30', { headers: authHeaders() });
    const data = await res.json();
    const jobs = Array.isArray(data) ? data : (data.jobs || []);
    if (!jobs.length) {
      list.innerHTML = '<p class="text-sm text-ink-muted py-12 text-center">No jobs yet — create your first short.</p>';
      return;
    }
    list.innerHTML = jobs.map(j => {
      const out = j.output_url
        ? `<a href="${j.output_url}" target="_blank" rel="noopener" class="text-ember-soft text-xs font-medium hover:underline">Download</a>`
        : '';
      const extras = (j.extra_outputs || []).map((u, i) =>
        `<a href="${u}" target="_blank" rel="noopener" class="text-ember-soft text-xs hover:underline">Clip ${i + 1}</a>`
      ).join(' · ');
      return `<div class="glass rounded-xl p-4 flex items-center justify-between gap-4 hover:border-white/[0.08] transition">
        <div class="min-w-0">
          <div class="flex items-center gap-2 mb-1">
            <span class="badge ${badgeClass(j.status)}">${j.status}</span>
            <span class="text-xs text-ink-muted font-mono truncate">${j.id}</span>
          </div>
          <p class="text-sm text-ink-soft truncate">${j.template || 'standard'} · ${j.message || ''}</p>
          ${j.renderer_used ? `<span class="inline-block mt-1 text-[10px] font-mono uppercase tracking-wide text-tide bg-tide/10 border border-tide/25 rounded px-1.5 py-0.5">${j.renderer_used.replace('_',' ')}</span>` : ''}
          ${extras ? `<p class="text-xs mt-1">${extras}</p>` : ''}
        </div>
        <div class="shrink-0">${out}</div>
      </div>`;
    }).join('');
  } catch (e) {
    list.innerHTML = `<p class="text-sm text-rose-400 py-4">${e.message}</p>`;
  }
}

/* ── user UI ─────────────────────────────────────────── */
function updateUserUI(u) {
  currentUser = u;
  if (!u) return;
  const name = u.name || (u.email || '').split('@')[0] || '?';
  document.getElementById('user-name').textContent = name;
  document.getElementById('user-avatar').textContent = (name[0] || '?').toUpperCase();
  const plan = (u.plan || 'free').toLowerCase();
  document.getElementById('user-plan').textContent =
    plan === 'pro' ? 'Creator' : plan === 'studio' ? 'Studio' : 'Free';
  document.getElementById('user-credits').textContent = u.credits_remaining ?? '—';
  const maxC = plan === 'studio' ? 1000 : plan === 'pro' ? 200 : 20;
  const pct = Math.min(100, Math.round(((u.credits_remaining || 0) / maxC) * 100));
  document.getElementById('credits-bar').style.width = pct + '%';
  document.getElementById('create-plan-hint').textContent =
    document.getElementById('user-plan').textContent;
}

async function refreshAuthUI(opts) {
  opts = opts || {};
  // Throttle: avoid hammering /api/auth/me (two tabs / rapid navigations)
  const now = Date.now();
  if (!opts.force && token && now - _lastAuthRefresh < 8000 && currentUser) {
    return currentUser;
  }
  if (_authRefreshInFlight) return _authRefreshInFlight;

  if (!token) {
    showLanding();
    loadLandingPlans();
    return null;
  }

  _authRefreshInFlight = (async () => {
    try {
      const res = await fetch('/api/auth/me', { headers: authHeaders() });
      if (!res.ok) throw new Error('session');
      const u = await res.json();
      _lastAuthRefresh = Date.now();
      updateUserUI(u);
      showApp();
      if (opts.navigate !== false) navigateFromHash(true);
      return u;
    } catch (_) {
      token = null;
      localStorage.removeItem('shorts_token');
      currentUser = null;
      showLanding();
      loadLandingPlans();
      return null;
    } finally {
      _authRefreshInFlight = null;
    }
  })();
  return _authRefreshInFlight;
}

/* ── auth modal ──────────────────────────────────────── */
function showAuth(m) {
  authMode = m || 'login';
  const modal = document.getElementById('auth-modal');
  modal.classList.remove('hidden');
  modal.classList.add('flex');
  document.getElementById('auth-name-wrap').classList.toggle('hidden', authMode !== 'register');
  document.getElementById('auth-title').textContent =
    authMode === 'register' ? 'Create account' : 'Welcome back';
  document.getElementById('auth-sub').textContent =
    authMode === 'register' ? 'Start with 20 free credits' : 'Log in to continue creating';
  document.getElementById('auth-submit').textContent =
    authMode === 'register' ? 'Sign up free' : 'Log in';
  document.getElementById('auth-switch-text').textContent =
    authMode === 'register' ? 'Already have an account?' : 'No account?';
  document.getElementById('auth-error').classList.add('hidden');
  // focus first field
  setTimeout(() => {
    const el = authMode === 'register'
      ? document.getElementById('auth-name')
      : document.getElementById('auth-email');
    if (el) el.focus();
  }, 50);
}

function closeAuth() {
  const modal = document.getElementById('auth-modal');
  modal.classList.add('hidden');
  modal.classList.remove('flex');
}

function toggleAuthMode() {
  showAuth(authMode === 'login' ? 'register' : 'login');
}

async function submitAuth() {
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  const err = document.getElementById('auth-error');
  err.classList.add('hidden');
  if (!email || password.length < 8) {
    err.textContent = 'Email and password (8+ chars) required';
    err.classList.remove('hidden');
    return;
  }
  const btn = document.getElementById('auth-submit');
  btn.disabled = true;
  try {
    if (authMode === 'register') {
      const name = document.getElementById('auth-name').value.trim();
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name: name || null }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(apiError(data, 'Registration failed'));
    }
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Login failed'));
    token = data.token;
    localStorage.setItem('shorts_token', token);
    closeAuth();
    toast('Welcome to Clipforge', true);
    await refreshAuthUI();
  } catch (e) {
    err.textContent = e.message;
    err.classList.remove('hidden');
  } finally {
    btn.disabled = false;
  }
}

async function logout(callApi) {
  if (callApi && token) {
    try {
      await fetch('/api/auth/logout', { method: 'POST', headers: authHeaders() });
    } catch (_) {}
  }
  token = null;
  currentUser = null;
  localStorage.removeItem('shorts_token');
  showLanding();
  loadLandingPlans();
}

/* ── plans / billing ─────────────────────────────────── */
function planFeatures(id) {
  if (id === 'free') return [
    '20 credits on join',
    'Standard + templates',
    '2 concurrent jobs',
    'Community support',
  ];
  if (id === 'pro') return [
    '200 credits / month',
    'YouTube viral + AI Visual',
    '5 concurrent jobs',
    'No watermarks',
    'Priority queue',
  ];
  return [
    '1000 credits / month',
    'Everything in Creator',
    '15 concurrent jobs',
    'Batch up to 10',
    'Highest storage',
  ];
}

function renderPlanCards(containerId, plans, packs, opts) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const featured = opts && opts.featured;
  el.innerHTML = (plans || []).map(p => {
    const isFeat = featured && p.id === 'pro';
    const feats = planFeatures(p.id)
      .map(f => `<li class="flex gap-2 text-sm text-ink-soft"><span class="text-tide">✓</span>${f}</li>`)
      .join('');
    const cta = p.id === 'free'
      ? `<button type="button" onclick="showAuth('register')" class="btn-g w-full py-2.5 rounded-xl text-sm font-medium mt-5">Start free</button>`
      : `<button type="button" onclick="buy('${p.checkout_kind || ('subscription_' + p.id)}','stripe')" class="btn-p w-full py-2.5 rounded-xl text-sm font-semibold mt-5">${token ? 'Upgrade' : 'Get started'}</button>`;
    return `<div class="glass rounded-2xl p-6 flex flex-col ${isFeat ? 'plan-f' : ''}">
      ${isFeat ? '<div class="text-[10px] font-bold uppercase tracking-wider text-ember-soft mb-2">Most popular</div>' : ''}
      <h3 class="text-lg font-bold font-display">${p.name}</h3>
      <div class="mt-2 mb-1">
        <span class="text-3xl font-extrabold font-display">${p.price_label || '$0'}</span>
        ${p.interval ? '<span class="text-ink-muted text-sm">/mo</span>' : ''}
      </div>
      <p class="text-xs text-ink-muted mb-4">${p.blurb || ''}</p>
      <ul class="space-y-2 flex-1">${feats}</ul>
      ${cta}
    </div>`;
  }).join('');
}

async function loadLandingPlans() {
  try {
    const res = await fetch('/api/billing/plans');
    plansCache = await res.json();
    renderPlanCards('landing-plans', plansCache.plans, plansCache.packs, { featured: true });
  } catch (_) {
    const el = document.getElementById('landing-plans');
    if (el) el.innerHTML = '<p class="text-ink-muted text-sm col-span-3 text-center">Pricing loads when API is up.</p>';
  }
}

async function renderBilling() {
  if (!token) { navigate('create'); showAuth('login'); return; }
  const cur = document.getElementById('billing-current');
  cur.innerHTML = currentUser
    ? `<div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p class="text-xs text-ink-muted mb-1">Current plan</p>
          <p class="text-lg font-semibold font-display">
            ${(currentUser.plan || 'free') === 'pro' ? 'Creator' : (currentUser.plan || 'free') === 'studio' ? 'Studio' : 'Free'}
            <span class="badge ${currentUser.plan === 'studio' ? 'b-studio' : currentUser.plan === 'pro' ? 'b-pro' : 'b-free'} ml-2">${currentUser.plan || 'free'}</span>
          </p>
        </div>
        <div class="text-right">
          <p class="text-xs text-ink-muted">Credits left</p>
          <p class="text-2xl font-mono font-bold">${currentUser.credits_remaining}</p>
        </div>
      </div>`
    : '';
  if (!plansCache) {
    try {
      const res = await fetch('/api/billing/plans');
      plansCache = await res.json();
    } catch (e) {
      toast(e.message);
      return;
    }
  }
  renderPlanCards('billing-plans', plansCache.plans, null, { featured: true });
  const packs = document.getElementById('billing-packs');
  packs.innerHTML = (plansCache.packs || []).map(p => `
    <div class="glass rounded-xl p-4">
      <p class="font-semibold font-display">${p.name}</p>
      <p class="text-xs text-ink-muted mb-3">${p.blurb || p.credits + ' credits'}</p>
      <div class="flex items-center justify-between">
        <span class="font-bold">${p.price_label}</span>
        <button type="button" onclick="buy('${p.checkout_kind || p.id}','stripe')" class="btn-s px-3 py-1.5 rounded-lg text-xs font-medium">Buy</button>
      </div>
    </div>`).join('') || '<p class="text-sm text-ink-muted">No packs configured.</p>';
}

function renderAccount() {
  if (!currentUser) return;
  document.getElementById('acct-email').textContent = currentUser.email;
  document.getElementById('acct-name').textContent = currentUser.name || '—';
  document.getElementById('acct-plan').textContent = currentUser.plan || 'free';
  document.getElementById('acct-credits').textContent = currentUser.credits_remaining;
  document.getElementById('acct-videos').textContent = currentUser.videos_this_week ?? 0;
}

async function buy(kind, provider) {
  if (!token) { showAuth('login'); return; }
  if (!kind) return;
  try {
    const res = await fetch('/api/billing/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ kind, provider: provider || 'stripe' }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Checkout failed'));
    if (data.checkout_url) {
      window.location.href = data.checkout_url;
    } else {
      toast('Credits applied (simulate mode)', true);
      await refreshAuthUI();
      navigate('billing');
    }
  } catch (e) {
    toast(e.message);
  }
}

/* ── job status / poll ───────────────────────────────── */
function showStatus(job) {
  currentJobId = job.id;
  const card = document.getElementById('status-card');
  card.classList.remove('hidden');
  document.getElementById('status-badge').textContent = job.status;
  document.getElementById('status-badge').className = 'badge ' + badgeClass(job.status);
  document.getElementById('status-id').textContent = job.id;
  const isFailed = job.status === 'failed';
  let msg = isFailed && job.error ? job.error : (job.message || job.status);
  document.getElementById('status-msg').textContent = msg;
  document.getElementById('status-msg').classList.toggle('text-red-400', isFailed);
  const rendererEl = document.getElementById('status-renderer');
  if (rendererEl) {
    if (job.renderer_used) {
      rendererEl.textContent = 'Renderer: ' + job.renderer_used.replace('_', ' ');
      rendererEl.classList.remove('hidden');
    } else {
      rendererEl.classList.add('hidden');
    }
  }
  document.getElementById('status-progress').style.width = (job.progress || 0) + '%';
  const outs = document.getElementById('status-outputs');
  outs.innerHTML = '';
  if (job.output_url) {
    outs.innerHTML += `<a href="${job.output_url}" target="_blank" rel="noopener" class="inline-flex items-center gap-2 text-sm text-ember-soft font-medium hover:underline">↓ Download video</a>`;
  }
  (job.extra_outputs || []).forEach((u, i) => {
    outs.innerHTML += `<div><a href="${u}" target="_blank" rel="noopener" class="text-sm text-ember-soft hover:underline">↓ Clip ${i + 1}</a></div>`;
  });
  document.getElementById('tweak-row').classList.toggle('hidden', job.status !== 'completed');
  if (['completed', 'failed', 'cancelled'].includes(job.status)) {
    document.getElementById('submit-btn').disabled = false;
    if (job.status === 'completed') toast('Render complete', true);
    if (isFailed) toast(job.error || 'Render failed', false);
  }
}

function pollJob(id) {
  if (pollTimer) clearInterval(pollTimer);
  let ticks = 0;
  pollTimer = setInterval(async () => {
    ticks += 1;
    try {
      const res = await fetch('/api/jobs/' + id, { headers: authHeaders() });
      const job = await res.json();
      if (!res.ok) throw new Error('poll failed');
      showStatus(job);
      if (['completed', 'failed', 'cancelled'].includes(job.status)) {
        clearInterval(pollTimer);
        pollTimer = null;
        // Refresh credits once when job ends (throttled)
        refreshAuthUI({ force: true, navigate: false });
      }
    } catch (_) {
      // stop after ~3 min of continuous errors
      if (ticks > 120) {
        clearInterval(pollTimer);
        pollTimer = null;
      }
    }
  }, 1500);
}

async function cancelCurrentJob() {
  if (!currentJobId) return;
  try {
    const res = await fetch('/api/jobs/' + currentJobId + '/cancel', {
      method: 'POST',
      headers: authHeaders(),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Cancel failed'));
    showStatus(data);
    toast('Cancelled');
  } catch (e) {
    toast(e.message);
  }
}

async function tweakStyle() {
  if (!currentJobId) return;
  try {
    const res = await fetch('/api/jobs/' + currentJobId + '/tweak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({
        caption_style: document.getElementById('tweak-style').value,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Tweak failed'));
    showStatus(data);
    pollJob(data.id);
  } catch (e) {
    toast(e.message);
  }
}

/* ── form submit ─────────────────────────────────────── */
document.getElementById('job-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!token) { showAuth('login'); return; }
  const btn = document.getElementById('submit-btn');
  btn.disabled = true;
  const fd = new FormData();
  fd.append('template', template);
  fd.append('voice', document.getElementById('voice').value);
  fd.append('caption_style', document.getElementById('style').value);
  const bg = document.getElementById('background').value;
  if (bg) fd.append('background_id', bg);
  const mc = document.getElementById('manual_captions').value.trim();
  if (mc) fd.append('manual_captions', mc);

  try {
    if (template === 'standard') {
      if (mode === 'upload') {
        const file = document.getElementById('file').files[0];
        if (!file) throw new Error('Choose a file');
        fd.append('file', file);
      } else {
        const script = document.getElementById('script').value.trim();
        if (!script) throw new Error('Enter or generate a script first');
        fd.append('script', script);
      }
    } else if (template === 'ai_visual') {
      const topic = document.getElementById('ai_visual_topic').value.trim();
      const script = document.getElementById('ai_visual_script').value.trim();
      if (!topic && !script) throw new Error('Enter a topic or script');
      if (script) fd.append('script', script);
      if (topic) fd.append('ai_topic', topic);
      fd.append('ai_max_scenes', document.getElementById('ai_max_scenes').value);
      fd.append('ai_image_style', document.getElementById('ai_image_style').value);
      fd.append('ai_renderer', document.getElementById('ai_renderer').value);
    } else if (template === 'reddit_story') {
      const title = document.getElementById('reddit_title').value.trim();
      const body = document.getElementById('reddit_body').value.trim();
      if (!title || !body) throw new Error('Title and body required');
      fd.append('reddit_title', title);
      fd.append('reddit_body', body);
      fd.append('reddit_subreddit', document.getElementById('reddit_subreddit').value);
      fd.append('reddit_username', document.getElementById('reddit_username').value);
      fd.append('reddit_upvotes', document.getElementById('reddit_upvotes').value);
    } else if (template === 'fake_text') {
      const raw = document.getElementById('fake_messages').value.trim();
      if (!raw) throw new Error('Add messages');
      const messages = raw.split('\n').filter(Boolean).map(line => {
        const lower = line.toLowerCase();
        let is_me = false, text = line;
        if (lower.startsWith('me:')) { is_me = true; text = line.slice(3).trim(); }
        else if (lower.startsWith('them:')) { text = line.slice(5).trim(); }
        return { sender: is_me ? 'me' : 'them', text, is_me };
      });
      fd.append('fake_text_json', JSON.stringify(messages));
      fd.append('fake_contact', document.getElementById('fake_contact').value);
      fd.append('fake_platform', document.getElementById('fake_platform').value);
      fd.append('fake_narrate', document.getElementById('fake_narrate').checked);
    } else if (template === 'youtube_reels') {
      const url = document.getElementById('youtube_url').value.trim();
      if (!url) throw new Error('Paste a YouTube URL');
      fd.append('youtube_url', url);
      fd.append('youtube_max_clips', document.getElementById('youtube_max_clips').value);
      fd.append('youtube_min_sec', document.getElementById('youtube_min_sec').value);
      fd.append('youtube_max_sec', document.getElementById('youtube_max_sec').value);
      fd.append('youtube_captions', document.getElementById('youtube_captions').checked);
      fd.append('youtube_use_llm', document.getElementById('youtube_llm').checked);
    } else if (template === 'split_screen') {
      const script = document.getElementById('split_script').value.trim();
      if (!script) throw new Error('Enter a script');
      fd.append('script', script);
      fd.append('split_label', document.getElementById('split_label').value);
    }

    const res = await fetch('/api/jobs', {
      method: 'POST',
      body: fd,
      headers: authHeaders(),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Job failed'));
    showStatus(data);
    pollJob(data.id);
  } catch (err) {
    toast(err.message || 'Failed');
    btn.disabled = false;
  }
});

/* ── keyboard: Escape closes modal / mobile nav ──────── */
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeAuth();
    closeMobileNav();
  }
});

/* ── boot ────────────────────────────────────────────── */
setMode('ai');
loadBackgrounds();
refreshAuthUI();

const params = new URLSearchParams(location.search);
if (params.get('billing') === 'success') {
  toast('Payment successful — credits updated', true);
  refreshAuthUI();
} else if (params.get('billing') === 'cancel') {
  toast('Checkout cancelled');
}
