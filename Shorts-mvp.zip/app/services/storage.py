"""
Media storage – local disk by default (bootstrap).
Set STORAGE_BACKEND=s3 + R2/S3 credentials when disk or bandwidth becomes the bottleneck.
Cloudflare R2 free tier (~10 GB storage, no egress fees) is the usual first paid-ish step.
"""
from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Optional

from app.core.config import settings

logger = logging.getLogger(__name__)


def is_s3() -> bool:
    return (
        getattr(settings, "STORAGE_BACKEND", "local") == "s3"
        and bool(settings.S3_BUCKET)
        and bool(settings.S3_ACCESS_KEY)
    )


def save_file(local_path: Path, key: str) -> str:
    """
    Persist a file and return a public URL path.
    local → /outputs/{name}
    s3    → {S3_PUBLIC_BASE_URL}/{key}
    """
    if not is_s3():
        dest = settings.OUTPUT_DIR / Path(key).name
        if local_path.resolve() != dest.resolve():
            shutil.copy2(local_path, dest)
        return f"/api/outputs/{dest.name}"

    try:
        import boto3
        client = boto3.client(
            "s3",
            endpoint_url=settings.S3_ENDPOINT_URL or None,
            aws_access_key_id=settings.S3_ACCESS_KEY,
            aws_secret_access_key=settings.S3_SECRET_KEY,
        )
        client.upload_file(str(local_path), settings.S3_BUCKET, key)
        base = settings.S3_PUBLIC_BASE_URL.rstrip("/")
        return f"{base}/{key}"
    except Exception as e:
        logger.error(f"S3 upload failed, falling back to local: {e}")
        dest = settings.OUTPUT_DIR / Path(key).name
        if local_path.resolve() != dest.resolve():
            shutil.copy2(local_path, dest)
        return f"/api/outputs/{dest.name}"


def public_url(filename: str) -> str:
    if is_s3() and settings.S3_PUBLIC_BASE_URL:
        return f"{settings.S3_PUBLIC_BASE_URL.rstrip('/')}/{filename}"
    return f"/api/outputs/{filename}"
