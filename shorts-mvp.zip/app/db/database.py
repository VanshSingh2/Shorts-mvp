"""Postgres preferred; falls back to SQLite if DATABASE_URL unreachable or empty."""
from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from sqlalchemy import (
    create_engine, Column, String, Integer, Float, DateTime, Text, ForeignKey, text, Boolean
)
from sqlalchemy.orm import sessionmaker, declarative_base

from app.core.config import settings

logger = logging.getLogger(__name__)


def _make_engine():
    url = (settings.DATABASE_URL or "").strip()
    if url and url.startswith("postgres"):
        try:
            eng = create_engine(url, pool_pre_ping=True, pool_size=5, max_overflow=10)
            with eng.connect() as conn:
                conn.execute(text("SELECT 1"))
            logger.info(f"Using Postgres: {url.split('@')[-1] if '@' in url else 'configured'}")
            return eng
        except Exception as e:
            logger.warning(f"Postgres unavailable ({e}); falling back to SQLite")
    # Use project-local SQLite for tests / offline
    db_path = Path(settings.BASE_DIR) / "data" / "shorts.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"Using SQLite: {db_path}")
    return create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread": False})


engine = _make_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class UserRow(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True)
    email = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=True)
    password_hash = Column(String, nullable=False)
    salt = Column(String, nullable=False)
    plan = Column(String, default="free")
    credits_remaining = Column(Integer, default=20)
    videos_this_week = Column(Integer, default=0)
    week_start = Column(DateTime, default=datetime.utcnow)
    stripe_customer_id = Column(String, nullable=True)
    stripe_subscription_id = Column(String, nullable=True)
    storage_used_bytes = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class SessionToken(Base):
    """Persistent session tokens with expiry (survives restarts)."""
    __tablename__ = "session_tokens"
    token = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"), index=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    last_used_at = Column(DateTime, default=datetime.utcnow)
    user_agent = Column(String, nullable=True)
    ip = Column(String, nullable=True)


class JobRow(Base):
    __tablename__ = "jobs"
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=True, index=True)
    status = Column(String, default="pending")
    progress = Column(Float, default=0.0)
    message = Column(String, default="")
    error = Column(Text, nullable=True)
    input_type = Column(String, default="script")
    template = Column(String, default="standard")
    caption_style = Column(String, default="classic")
    voice = Column(String, default="en-US-JennyNeural")
    output_url = Column(String, nullable=True)
    output_path = Column(String, nullable=True)
    output_bytes = Column(Integer, default=0)
    renderer_used = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class PaymentRow(Base):
    """Tracks Stripe + crypto checkouts until confirmed."""
    __tablename__ = "payments"
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"), index=True, nullable=False)
    provider = Column(String, default="stripe")  # stripe | crypto | simulate
    kind = Column(String, nullable=False)  # subscription_pro | pack_50 | ...
    status = Column(String, default="pending")  # pending | completed | failed | expired
    amount_cents = Column(Integer, default=0)
    currency = Column(String, default="usd")
    credits_grant = Column(Integer, default=0)
    plan_grant = Column(String, nullable=True)
    external_id = Column(String, nullable=True, index=True)  # session/invoice id
    checkout_url = Column(String, nullable=True)
    raw_meta = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)


class CreditLedger(Base):

    __tablename__ = "credit_ledger"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, index=True, nullable=False)
    delta = Column(Integer, nullable=False)
    reason = Column(String, default="")
    stripe_payment_id = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=engine)
    _migrate_add_missing_columns()


def _migrate_add_missing_columns():
    """Lightweight additive migration: create_all() won't ALTER existing SQLite
    tables, so add any new columns by hand instead of crashing at first use."""
    try:
        from sqlalchemy import inspect, text
        inspector = inspect(engine)
        if "jobs" not in inspector.get_table_names():
            return
        existing_cols = {c["name"] for c in inspector.get_columns("jobs")}
        wanted = {"renderer_used": "VARCHAR"}
        with engine.connect() as conn:
            for col, coltype in wanted.items():
                if col not in existing_cols:
                    conn.execute(text(f"ALTER TABLE jobs ADD COLUMN {col} {coltype}"))
            conn.commit()
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning(f"Column migration skipped: {e}")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
