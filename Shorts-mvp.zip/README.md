# Shorts MVP / Clipforge v0.8

Production-oriented **vertical shorts factory**: AI script → voice → captions → 9:16 MP4, plus AI visual reels, YouTube multi-reels, and viral templates.

## UI (v0.8 redesign)

- **Brand**: Clipforge — deep void base + coral *ember* accent + teal *tide* secondary (intentionally non-generic vs purple AI SaaS)
- **Typography**: Outfit (display) + DM Sans (body)
- **App shell**: Sidebar nav (Create / Library / Plans / Account), tool cards, mode tabs, live job status + caption restyle
- **Landing**: Hero + features + how-it-works + pricing
- **Wired to**: auth, jobs, generate-script, billing, backgrounds, cancel, tweak

## What it does

| Feature | Description |
|---------|-------------|
| **AI script** | Topic + brief → spoken short-form script |
| **AI Visual Reels** | Script/topic → AI scene images → Ken Burns / HyperFrames + TTS + captions |
| **Standard** | Script or upload → TTS + captions → vertical short |
| **Manual captions** | Paste plain lines or SRT |
| **Reddit / Fake text / Split / YouTube** | Viral format templates |
| **Auth + credits** | Free / Pro (Creator) / Studio, Stripe hooks |
| **Jobs** | Queue, status, cancel, batch, tweaks |

## Quick start

```bash
cp backend/.env.example backend/.env
# set LLM_API_KEY, etc.

cd backend
pip install -r requirements.txt
# need ffmpeg on PATH
./run.sh
```

Open http://localhost:8000

## Tests

```bash
cd backend && PYTHONPATH=. pytest tests/ -q
# frontend static wiring:
PYTHONPATH=. pytest tests/test_frontend_static.py -q
```

## License

MIT — replace legal contacts before public launch.
