"""
Fake text conversation renderer (iMessage / WhatsApp style).
"""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import List, Tuple

from PIL import Image, ImageDraw, ImageFont

from app.models.schemas import FakeTextMessage, FakeTextPlatform, FakeTextRequest

logger = logging.getLogger(__name__)

W = 1080
H = 1920
BUBBLE_MAX_W = 720
PAD_X = 40
PAD_Y = 120


def _font(size: int, bold: bool = False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ]
    for p in candidates:
        if Path(p).exists():
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def _wrap(text: str, font, max_w: int) -> List[str]:
    words = text.split()
    lines, cur = [], ""
    draw = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    for w in words:
        test = f"{cur} {w}".strip()
        bb = draw.textbbox((0, 0), test, font=font)
        if bb[2] - bb[0] <= max_w:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [""]


def _platform_colors(platform: FakeTextPlatform):
    if platform == FakeTextPlatform.WHATSAPP:
        return {
            "bg": (14, 22, 33),
            "header": (31, 44, 52),
            "me_bubble": (0, 92, 75),
            "them_bubble": (31, 44, 52),
            "me_text": (255, 255, 255),
            "them_text": (233, 237, 239),
            "header_text": (255, 255, 255),
        }
    return {
        "bg": (0, 0, 0),
        "header": (28, 28, 30),
        "me_bubble": (0, 122, 255),
        "them_bubble": (58, 58, 60),
        "me_text": (255, 255, 255),
        "them_text": (255, 255, 255),
        "header_text": (255, 255, 255),
    }


def _draw_bubble(draw, xy, text_lines, font, fill, text_fill, radius=28):
    x, y = xy
    line_h = 34
    pad = 20
    max_line_w = max(draw.textbbox((0, 0), ln, font=font)[2] for ln in text_lines)
    bw = max_line_w + pad * 2
    bh = len(text_lines) * line_h + pad * 2 - 8
    draw.rounded_rectangle([x, y, x + bw, y + bh], radius=radius, fill=fill)
    ty = y + pad - 4
    for ln in text_lines:
        draw.text((x + pad, ty), ln, font=font, fill=text_fill)
        ty += line_h
    return bw, bh


def render_conversation_frames(
    req: FakeTextRequest,
    out_dir: Path,
    reveal_delay: float = 1.8,
) -> Tuple[List[Path], List[float], str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    colors = _platform_colors(req.platform)
    font_msg = _font(28)
    font_header = _font(30, bold=True)

    frames: List[Path] = []
    durations: List[float] = []
    narration_parts: List[str] = []

    messages = []
    for m in req.messages:
        is_me = m.is_me or m.sender.lower() in ("me", "i", "you")
        messages.append(FakeTextMessage(sender=m.sender, text=m.text, is_me=is_me))
        if req.narrate:
            who = "I said" if is_me else f"{req.contact_name} said"
            narration_parts.append(f"{who}: {m.text}")

    for i in range(len(messages)):
        visible = messages[: i + 1]
        img = Image.new("RGB", (W, H), colors["bg"])
        draw = ImageDraw.Draw(img)

        draw.rectangle([0, 0, W, 100], fill=colors["header"])
        draw.text((24, 36), "‹", font=_font(40), fill=colors["header_text"])
        name = req.contact_name
        nb = draw.textbbox((0, 0), name, font=font_header)
        nw = nb[2] - nb[0]
        draw.text(((W - nw) // 2, 34), name, font=font_header, fill=colors["header_text"])

        y = H - 80
        gap = 18
        bubble_specs = []
        for m in reversed(visible):
            lines = _wrap(m.text, font_msg, BUBBLE_MAX_W - 40)
            line_h = 34
            pad = 20
            max_line_w = max(draw.textbbox((0, 0), ln, font=font_msg)[2] for ln in lines)
            bw = max_line_w + pad * 2
            bh = len(lines) * line_h + pad * 2 - 8
            bubble_specs.append((m, lines, bw, bh))
            y -= bh + gap

        y = max(PAD_Y + 20, y)

        for m, lines, bw, bh in reversed(bubble_specs):
            if m.is_me:
                x = W - PAD_X - bw
                fill = colors["me_bubble"]
                tfill = colors["me_text"]
            else:
                x = PAD_X
                fill = colors["them_bubble"]
                tfill = colors["them_text"]
            _draw_bubble(draw, (x, y), lines, font_msg, fill, tfill)
            y += bh + gap

        path = out_dir / f"frame_{i:03d}.png"
        img.save(path, "PNG")
        frames.append(path)
        durations.append(reveal_delay + (0.6 if i == len(messages) - 1 else 0))

    script = ". ".join(narration_parts) if narration_parts else ""
    logger.info(f"Fake-text: {len(frames)} frames for {req.contact_name}")
    return frames, durations, script


def frames_to_video(
    frames: List[Path],
    durations: List[float],
    output_path: Path,
    audio_path: Path | None = None,
) -> Path:
    """Stitch frames into MP4. Uses a more reliable filter approach."""
    work = output_path.parent
    concat_path = work / f"concat_{output_path.stem}.txt"
    lines = []
    for f, d in zip(frames, durations):
        # Use absolute paths, escape single quotes
        p = str(f.resolve()).replace("'", "'\\''")
        lines.append(f"file '{p}'")
        lines.append(f"duration {max(0.1, d):.3f}")
    if frames:
        p = str(frames[-1].resolve()).replace("'", "'\\''")
        lines.append(f"file '{p}'")
    concat_path.write_text("\n".join(lines))

    # First create silent video from frames
    silent = work / f"silent_{output_path.stem}.mp4"
    cmd1 = [
        "ffmpeg", "-y",
        "-f", "concat", "-safe", "0", "-i", str(concat_path),
        "-vf", "fps=30,format=yuv420p",
        "-c:v", "libx264", "-preset", "fast", "-crf", "20",
        "-an",
        str(silent),
    ]
    r1 = subprocess.run(cmd1, capture_output=True, text=True)
    if r1.returncode != 0:
        logger.error(r1.stderr[-800:])
        raise RuntimeError(f"FFmpeg fake-text frames failed: {r1.stderr[-400:]}")

    if audio_path and audio_path.exists():
        cmd2 = [
            "ffmpeg", "-y",
            "-i", str(silent),
            "-i", str(audio_path),
            "-c:v", "copy",
            "-c:a", "aac", "-b:a", "192k",
            "-shortest",
            "-movflags", "+faststart",
            str(output_path),
        ]
        r2 = subprocess.run(cmd2, capture_output=True, text=True)
        if r2.returncode != 0:
            logger.error(r2.stderr[-800:])
            raise RuntimeError(f"FFmpeg fake-text audio mux failed: {r2.stderr[-400:]}")
        silent.unlink(missing_ok=True)
    else:
        silent.rename(output_path)

    concat_path.unlink(missing_ok=True)
    logger.info(f"Fake-text video → {output_path}")
    return output_path
