"""Download YouTube (and other yt-dlp sources) for reel extraction."""
from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

ALLOWED_HOST_HINTS = (
    "youtube.com", "youtu.be", "www.youtube.com", "m.youtube.com",
    "youtube-nocookie.com",
)

YOUTUBE_URL_RE = re.compile(
    r"(https?://)?(www\.)?(youtube\.com|youtu\.be)/[\w\-?=&%.]+",
    re.I,
)


def is_youtube_url(url: str) -> bool:
    if not url or not url.strip():
        return False
    url = url.strip()
    if not YOUTUBE_URL_RE.search(url):
        try:
            host = urlparse(url if "://" in url else f"https://{url}").hostname or ""
            return any(h in host for h in ALLOWED_HOST_HINTS)
        except Exception:
            return False
    return True


def normalize_url(url: str) -> str:
    url = url.strip()
    if not url.startswith("http"):
        url = "https://" + url
    return url


def _yt_dlp_bin() -> str:
    return shutil.which("yt-dlp") or "yt-dlp"


def _cookie_args() -> List[str]:
    args: List[str] = []
    cookies_file = os.environ.get("YOUTUBE_COOKIES_FILE", "").strip()
    cookies_browser = os.environ.get("YOUTUBE_COOKIES_FROM_BROWSER", "").strip()
    try:
        from app.core.config import settings
        cookies_file = cookies_file or getattr(settings, "YOUTUBE_COOKIES_FILE", "") or ""
        cookies_browser = cookies_browser or getattr(settings, "YOUTUBE_COOKIES_FROM_BROWSER", "") or ""
    except Exception:
        pass
    cookies_file = (cookies_file or "").strip()
    cookies_browser = (cookies_browser or "").strip()
    if cookies_file and Path(cookies_file).is_file():
        args.extend(["--cookies", str(Path(cookies_file).resolve())])
        logger.info(f"yt-dlp using cookies file: {cookies_file}")
    elif cookies_browser:
        args.extend(["--cookies-from-browser", cookies_browser])
        logger.info(f"yt-dlp using cookies from browser: {cookies_browser}")
    return args


def _find_output(out_dir: Path, stdout: str = "") -> Optional[Path]:
    printed = (stdout or "").strip().splitlines()
    if printed:
        candidate = Path(printed[-1].strip())
        if candidate.is_file() and candidate.stat().st_size > 1024:
            return candidate
    files = sorted(out_dir.glob("source.*"), key=lambda p: p.stat().st_mtime, reverse=True)
    for f in files:
        if f.suffix.lower() in {".mp4", ".mkv", ".webm", ".mov", ".m4a"} and f.stat().st_size > 1024:
            return f
    for pattern in ("*.mp4", "*.mkv", "*.webm", "*.mov"):
        for f in sorted(out_dir.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True):
            if f.stat().st_size > 1024:
                return f
    return None


def download_video(
    url: str,
    out_dir: Path,
    *,
    max_height: int = 1080,
    max_duration_sec: int = 1200,
) -> Path:
    """
    Download a YouTube video with yt-dlp.

    Keep format selectors simple. Strict height/ext filters break on
    android/ios clients that only expose a subset of formats.
    """
    out_dir.mkdir(parents=True, exist_ok=True)

    mock = os.environ.get("YOUTUBE_MOCK_DOWNLOAD_PATH", "").strip()
    try:
        from app.core.config import settings
        mock = mock or getattr(settings, "YOUTUBE_MOCK_DOWNLOAD_PATH", "") or ""
    except Exception:
        pass
    mock = (mock or "").strip()
    if mock and Path(mock).is_file():
        dest = out_dir / f"source{Path(mock).suffix or '.mp4'}"
        shutil.copy2(mock, dest)
        logger.info(f"yt-dlp mock: copied {mock} -> {dest}")
        return dest

    from app.services.security import assert_safe_external_url

    if not is_youtube_url(url):
        raise ValueError("Only YouTube links are supported in this version")
    url = assert_safe_external_url(
        url,
        allow_hosts=(
            "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be",
            "youtube-nocookie.com", "www.youtube-nocookie.com",
        ),
    )

    # Normalize youtu.be share links (drop ?si= tracking)
    if "youtu.be/" in url:
        url = url.split("?")[0]

    out_tmpl = str(out_dir / "source.%(ext)s")
    cookie_args = _cookie_args()
    bin_path = _yt_dlp_bin()

    attempts = [
        {
            "label": "default/best",
            "args": ["-f", "bestvideo*+bestaudio/best", "--merge-output-format", "mp4"],
            "clients": None,
        },
        {
            "label": "default/b",
            "args": ["-f", "b"],
            "clients": None,
        },
        {
            "label": "android/best",
            "args": ["-f", "bestvideo*+bestaudio/best", "--merge-output-format", "mp4"],
            "clients": "android",
        },
        {
            "label": "android/b",
            "args": ["-f", "b"],
            "clients": "android",
        },
        {
            "label": "ios/best",
            "args": ["-f", "bestvideo*+bestaudio/best", "--merge-output-format", "mp4"],
            "clients": "ios",
        },
        {
            "label": "mweb/best",
            "args": ["-f", "bestvideo*+bestaudio/best", "--merge-output-format", "mp4"],
            "clients": "mweb",
        },
        {
            "label": "default/nof",
            "args": ["--merge-output-format", "mp4"],
            "clients": None,
        },
    ]

    last_err = ""
    for attempt in attempts:
        for old in out_dir.glob("source.*"):
            try:
                old.unlink()
            except OSError:
                pass

        cmd = [
            bin_path,
            "--no-playlist",
            "--no-warnings",
            "--newline",
            "-o", out_tmpl,
            "--print", "after_move:filepath",
            "--retries", "5",
            "--fragment-retries", "5",
            "--socket-timeout", "30",
        ]
        cmd.extend(attempt["args"])
        cmd.extend(cookie_args)
        if attempt["clients"]:
            cmd.extend(["--extractor-args", f"youtube:player_client={attempt['clients']}"])
        cmd.append(url)

        logger.info(f"yt-dlp download: {url} attempt={attempt['label']}")
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        except subprocess.TimeoutExpired:
            last_err = "Download timed out"
            logger.warning(f"yt-dlp timeout ({attempt['label']})")
            continue

        if result.returncode == 0:
            found = _find_output(out_dir, result.stdout or "")
            if found:
                logger.info(f"yt-dlp ok ({attempt['label']}): {found}")
                return found
            last_err = "Download finished but no video file found"
            logger.warning(f"yt-dlp ok exit but no file ({attempt['label']})")
            continue

        err = (result.stderr or result.stdout or "")[-1500:]
        last_err = err
        logger.warning(f"yt-dlp failed ({attempt['label']}): {err[-400:]}")

        if "Private video" in err or "Video unavailable" in err:
            break

    hint = ""
    low = last_err.lower()
    if "sign in to confirm" in low or "not a bot" in low:
        hint = (
            " Bot check: re-export fresh YouTube cookies to YOUTUBE_COOKIES_FILE "
            "and run: pip install -U yt-dlp"
        )
    elif "format is not available" in low:
        hint = (
            " Format issue: run `pip install -U yt-dlp` and re-export cookies. "
            "Optional: install deno for YouTube JS challenges."
        )
    elif "page needs to be reloaded" in low:
        hint = (
            " YouTube JS challenge: install deno (https://deno.land) or upgrade yt-dlp, "
            "and use fresh cookies."
        )

    logger.error(f"yt-dlp failed all attempts: {last_err[-500:]}{hint}")
    raise RuntimeError(f"YouTube download failed: {(last_err[:220] + hint)[:500]}")


def probe_duration(path: Path) -> float:
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True, text=True,
    )
    try:
        return float(r.stdout.strip())
    except Exception:
        return 0.0
