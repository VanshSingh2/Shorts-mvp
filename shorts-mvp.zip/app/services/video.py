"""Video composition: background + voiceover + burned captions → 9:16 vertical."""
import logging
import subprocess
import uuid
from pathlib import Path
from typing import List, Optional

try:
    from moviepy import (
        VideoFileClip, AudioFileClip, TextClip, CompositeVideoClip, ColorClip, concatenate_videoclips,
    )
    from moviepy.video.fx import Loop, Resize, Crop
    HAS_MOVIEPY = True
except Exception:  # MoviePy optional – FFmpeg path is primary
    HAS_MOVIEPY = False
    VideoFileClip = AudioFileClip = TextClip = CompositeVideoClip = ColorClip = concatenate_videoclips = None
    Loop = Resize = Crop = None


from app.core.config import settings
from app.models.schemas import TranscriptSegment

logger = logging.getLogger(__name__)


def _get_background_clip(
    background_path: Optional[Path],
    duration: float,
    width: int = settings.TARGET_WIDTH,
    height: int = settings.TARGET_HEIGHT,
):
    """Load or create a background clip of the required duration and size."""
    if background_path and background_path.exists():
        clip = VideoFileClip(str(background_path))
        # Loop if shorter than needed
        if clip.duration < duration:
            n_loops = int(duration / clip.duration) + 1
            clip = concatenate_videoclips([clip] * n_loops)
        clip = clip.subclipped(0, duration)
        
        # Center-crop / resize to 9:16
        clip = _fit_to_vertical(clip, width, height)
        return clip
    else:
        # Solid dark background
        return ColorClip(size=(width, height), color=(20, 20, 30), duration=duration)


def _fit_to_vertical(clip, target_w: int, target_h: int):
    """Resize and center-crop a clip to exact 9:16."""
    # Scale so the smaller dimension fills the target
    scale = max(target_w / clip.w, target_h / clip.h)
    new_w = int(clip.w * scale)
    new_h = int(clip.h * scale)
    clip = clip.resized((new_w, new_h))
    
    # Center crop
    x_center = new_w / 2
    y_center = new_h / 2
    x1 = int(x_center - target_w / 2)
    y1 = int(y_center - target_h / 2)
    return clip.cropped(x1=x1, y1=y1, width=target_w, height=target_h)


def create_caption_clips(
    segments: List[TranscriptSegment],
    style_name: str = "classic",
    video_size: tuple[int, int] = (settings.TARGET_WIDTH, settings.TARGET_HEIGHT),
) -> List:
    """Create a list of TextClips for each transcript segment."""
    style = settings.CAPTION_STYLES.get(style_name, settings.CAPTION_STYLES["classic"])
    clips = []
    
    for seg in segments:
        # MoviePy TextClip – note: requires ImageMagick or falls back
        try:
            txt = TextClip(
                text=seg.text,
                font_size=style["fontsize"],
                color=style["color"],
                stroke_color=style.get("stroke_color"),
                stroke_width=style.get("stroke_width", 0),
                method="caption",
                size=(int(video_size[0] * 0.9), None),
                text_align="center",
                horizontal_align="center",
            )
            txt = txt.with_start(seg.start).with_end(seg.end).with_position(("center", style["position"][1] * video_size[1]))
            clips.append(txt)
        except Exception as e:
            logger.warning(f"TextClip failed for '{seg.text[:30]}...': {e}. Skipping caption.")
    
    return clips


def compose_video(
    audio_path: Path,
    segments: List[TranscriptSegment],
    output_path: Path,
    background_path: Optional[Path] = None,
    caption_style: str = "classic",
    burn_captions: bool = True,
) -> Path:
    """
    Main composition function.
    1. Load / create background of correct duration
    2. Attach voiceover audio
    3. Burn captions if requested
    4. Export as 9:16 MP4
    """
    logger.info("Starting video composition")
    
    audio = AudioFileClip(str(audio_path))
    duration = audio.duration
    
    bg = _get_background_clip(background_path, duration)
    bg = bg.with_audio(audio)
    
    final = bg
    
    if burn_captions and segments:
        caption_clips = create_caption_clips(segments, caption_style)
        if caption_clips:
            final = CompositeVideoClip([bg] + caption_clips)
    
    # Write with reasonable settings for social media
    final.write_videofile(
        str(output_path),
        fps=settings.FPS,
        codec="libx264",
        audio_codec="aac",
        preset="medium",
        threads=4,
        logger=None,  # suppress moviepy progress spam
    )
    
    # Cleanup
    audio.close()
    bg.close()
    final.close()
    
    logger.info(f"Video written to {output_path}")
    return output_path


def _style_to_force_style(style_name: str = "classic") -> str:
    """Map our caption styles to FFmpeg force_style strings (ASS-like)."""
    styles = {
        "classic": "FontSize=32,FontName=Arial,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline=3,Alignment=2,MarginV=140,Bold=1",
        "bold_yellow": "FontSize=36,FontName=Arial Black,PrimaryColour=&H0000FFFF,OutlineColour=&H00000000,Outline=4,Alignment=2,MarginV=130,Bold=1",
        "minimal": "FontSize=28,FontName=Arial,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline=2,Alignment=2,MarginV=160",
        "karaoke": "FontSize=34,FontName=Arial Black,PrimaryColour=&H00FFFFFF,SecondaryColour=&H0000FFFF,OutlineColour=&H00000000,Outline=3,Alignment=2,MarginV=135,Bold=1",
        "neon": "FontSize=34,FontName=Arial,PrimaryColour=&H00CCFF00,OutlineColour=&H00000000,Outline=3,Alignment=2,MarginV=140,Bold=1",
        "bounce": "FontSize=36,FontName=Arial Black,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline=4,Alignment=2,MarginV=130,Bold=1",
        "pop": "FontSize=38,FontName=Impact,PrimaryColour=&H0000EEFF,OutlineColour=&H00000000,Outline=5,Alignment=2,MarginV=125,Bold=1",
    }
    return styles.get(style_name, styles["classic"])


def _assert_media_output(path: Path, min_bytes: int = 2000) -> Path:
    path = Path(path)
    if not path.exists() or path.stat().st_size < min_bytes:
        raise RuntimeError(f"Output missing or too small: {path}")
    return path


def compose_video_ffmpeg(
    audio_path: Path,
    srt_path: Path,
    output_path: Path,
    background_path: Optional[Path] = None,
    duration: float | None = None,
    caption_style: str = "classic",
) -> Path:
    """
    Primary composition path using pure FFmpeg.
    Uses the ASS filter when subtitle path ends with .ass (word-level karaoke).
    """
    if duration is None:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path)],
            capture_output=True, text=True,
        )
        try:
            duration = float(probe.stdout.strip() or "0")
        except Exception:
            duration = 0.0
        if duration <= 0:
            duration = 5.0

    w, h = settings.TARGET_WIDTH, settings.TARGET_HEIGHT
    force_style = _style_to_force_style(caption_style)
    sub_escaped = str(srt_path).replace("\\", "/").replace(":", "\\:")
    is_ass = str(srt_path).lower().endswith(".ass")
    if is_ass:
        sub_filter = f"ass='{sub_escaped}'"
    else:
        sub_filter = f"subtitles='{sub_escaped}':original_size={w}x{h}:force_style='{force_style}'"

    if background_path and background_path.exists():
        filter_complex = (
            f"[0:v]scale={w}:{h}:force_original_aspect_ratio=increase,"
            f"crop={w}:{h},loop=loop=-1:size=32767:start=0,setpts=N/FRAME_RATE/TB,"
            f"trim=duration={duration},setsar=1[bg];"
            f"[bg]{sub_filter}[outv]"
        )
        cmd = [
            "ffmpeg", "-y",
            "-stream_loop", "-1",
            "-i", str(background_path),
            "-i", str(audio_path),
            "-filter_complex", filter_complex,
            "-map", "[outv]", "-map", "1:a",
            "-c:v", "libx264", "-preset", "medium", "-crf", "20",
            "-c:a", "aac", "-b:a", "192k",
            "-t", str(duration),
            "-movflags", "+faststart",
            str(output_path),
        ]
    else:
        cmd = [
            "ffmpeg", "-y",
            "-f", "lavfi", "-i", f"color=c=0x14141e:s={w}x{h}:d={duration}",
            "-i", str(audio_path),
            "-vf", sub_filter,
            "-c:v", "libx264", "-preset", "medium", "-crf", "20",
            "-c:a", "aac", "-b:a", "192k",
            "-t", str(duration),
            "-movflags", "+faststart",
            str(output_path),
        ]

    logger.info(f"Running FFmpeg composition (style={caption_style}, ass={is_ass})...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error(result.stderr[-1000:])
        raise RuntimeError(f"FFmpeg failed: {result.stderr[-500:]}")

    logger.info(f"FFmpeg composition done → {output_path}")
    if not output_path.exists() or output_path.stat().st_size < 2000:
        raise RuntimeError(f"Output missing or too small: {output_path}")
    return output_path


def extract_audio(video_path: Path, audio_path: Path) -> Path:
    """Extract audio track from a video file."""
    cmd = [
        "ffmpeg", "-y", "-i", str(video_path),
        "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
        str(audio_path),
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return audio_path


def compose_ken_burns_slideshow(
    image_paths: List[Path],
    audio_path: Path,
    output_path: Path,
    srt_path: Optional[Path] = None,
    caption_style: str = "classic",
    fps: int = settings.FPS,
) -> Path:
    """
    High-quality faceless reel: multiple stills + slow zoom/pan (Ken Burns)
    + crossfades + voiceover + optional burned captions.
    """
    if not image_paths:
        raise ValueError("At least one image required for slideshow")

    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path)],
        capture_output=True, text=True,
    )
    duration = float(probe.stdout.strip() or "10")
    n = len(image_paths)
    # Even time per image with small overlap for crossfade
    fade = min(0.45, duration / (n * 4))
    seg = duration / n
    w, h = settings.TARGET_WIDTH, settings.TARGET_HEIGHT

    # Build filter: each image zoompan then xfade chain
    inputs: list[str] = []
    for p in image_paths:
        inputs.extend(["-loop", "1", "-t", f"{seg + fade:.3f}", "-i", str(p)])
    inputs.extend(["-i", str(audio_path)])

    filter_parts = []
    for i in range(n):
        # Alternate zoom-in / zoom-out for visual interest
        if i % 2 == 0:
            zexpr = f"min(zoom+0.0015,1.18)"
            xexpr = "iw/2-(iw/zoom/2)"
            yexpr = "ih/2-(ih/zoom/2)"
        else:
            zexpr = f"if(eq(on,1),1.15,max(zoom-0.0015,1.0))"
            xexpr = "iw/2-(iw/zoom/2)"
            yexpr = "ih/2-(ih/zoom/2)"
        filter_parts.append(
            f"[{i}:v]scale={w * 2}:{h * 2}:force_original_aspect_ratio=increase,"
            f"crop={w * 2}:{h * 2},"
            f"zoompan=z='{zexpr}':x='{xexpr}':y='{yexpr}':d={int((seg + fade) * fps)}:s={w}x{h}:fps={fps},"
            f"format=yuv420p[v{i}]"
        )

    if n == 1:
        vchain = "[v0]"
        last = "v0"
    else:
        # sequential xfade
        filter_parts.append(
            f"[v0][v1]xfade=transition=fade:duration={fade:.3f}:offset={max(seg - fade, 0):.3f}[x1]"
        )
        last = "x1"
        for i in range(2, n):
            offset = (seg * i) - (fade * (i))
            offset = max(offset, 0)
            filter_parts.append(
                f"[{last}][v{i}]xfade=transition=fade:duration={fade:.3f}:offset={offset:.3f}[x{i}]"
            )
            last = f"x{i}"
        vchain = f"[{last}]"

    # Captions
    if srt_path and Path(srt_path).exists():
        force_style = _style_to_force_style(caption_style)
        sub_escaped = str(srt_path).replace("\\", "/").replace(":", "\\:")
        is_ass = str(srt_path).lower().endswith(".ass")
        if is_ass:
            sub = f"ass='{sub_escaped}'"
        else:
            sub = f"subtitles='{sub_escaped}':original_size={w}x{h}:force_style='{force_style}'"
        filter_parts.append(f"{vchain}{sub}[outv]")
        map_v = "[outv]"
    else:
        filter_parts.append(f"{vchain}null[outv]")
        map_v = "[outv]"

    filter_complex = ";".join(filter_parts)
    cmd = [
        "ffmpeg", "-y",
        *inputs,
        "-filter_complex", filter_complex,
        "-map", map_v, "-map", f"{n}:a",
        "-c:v", "libx264", "-preset", "medium", "-crf", "20",
        "-c:a", "aac", "-b:a", "192k",
        "-t", f"{duration:.3f}",
        "-movflags", "+faststart",
        str(output_path),
    ]
    logger.info(f"Ken Burns slideshow: {n} images, {duration:.1f}s")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error(result.stderr[-1500:])
        # Fallback: simpler concat without xfade
        return _slideshow_simple(image_paths, audio_path, output_path, srt_path, caption_style, duration, fps)
    return output_path


def _slideshow_simple(
    image_paths: List[Path],
    audio_path: Path,
    output_path: Path,
    srt_path: Optional[Path],
    caption_style: str,
    duration: float,
    fps: int,
) -> Path:
    """Simpler slideshow if xfade graph fails."""
    n = len(image_paths)
    seg = duration / n
    w, h = settings.TARGET_WIDTH, settings.TARGET_HEIGHT
    list_file = output_path.parent / "slides.txt"
    # Create equal-length clips then concat
    clip_paths = []
    for i, p in enumerate(image_paths):
        clip = output_path.parent / f"_slide_{i}.mp4"
        cmd = [
            "ffmpeg", "-y", "-loop", "1", "-i", str(p),
            "-vf", f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},fps={fps}",
            "-t", f"{seg:.3f}", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-an",
            str(clip),
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        clip_paths.append(clip)
    list_file.write_text("".join(f"file '{c.resolve()}'\n" for c in clip_paths))
    concat_path = output_path.parent / "_concat.mp4"
    subprocess.run(
        ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(list_file),
         "-c", "copy", str(concat_path)],
        check=True, capture_output=True,
    )
    force_style = _style_to_force_style(caption_style)
    vf = f"scale={w}:{h}"
    if srt_path and Path(srt_path).exists():
        sub_escaped = str(srt_path).replace("\\", "/").replace(":", "\\:")
        if str(srt_path).lower().endswith(".ass"):
            vf = f"ass='{sub_escaped}'"
        else:
            vf = f"subtitles='{sub_escaped}':original_size={w}x{h}:force_style='{force_style}'"
    cmd = [
        "ffmpeg", "-y", "-i", str(concat_path), "-i", str(audio_path),
        "-vf", vf,
        "-c:v", "libx264", "-preset", "medium", "-crf", "20",
        "-c:a", "aac", "-b:a", "192k",
        "-t", f"{duration:.3f}", "-movflags", "+faststart",
        "-shortest", str(output_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error(result.stderr[-1000:])
        raise RuntimeError(f"Slideshow FFmpeg failed: {result.stderr[-400:]}")
    return output_path
