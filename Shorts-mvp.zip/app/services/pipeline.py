"""End-to-end job pipeline – Phase 1–3."""
from __future__ import annotations

import logging
import re
import subprocess
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

from app.core.config import settings
from app.models.schemas import (
    JobStatus, JobResponse, CreateJobRequest, TemplateType, TranscriptSegment, TweakRequest,
)
from app.services.transcription import transcribe_audio, segments_to_srt, segments_to_ass_karaoke
from app.services.tts import generate_speech_with_timestamps
from app.services.video import compose_video_ffmpeg, extract_audio, compose_ken_burns_slideshow
from app.services.renderers.reddit import render_reddit_card, reddit_script_from_request
from app.services.renderers.fake_text import render_conversation_frames, frames_to_video
from app.services.renderers.split_screen import compose_split_screen
from app.services import users as user_service

logger = logging.getLogger(__name__)

_jobs: Dict[str, JobResponse] = {}


def _discover_extra_outputs(job_id: str) -> list[str] | None:
    """Find multi-reel files: {job_id}.mp4 + {job_id}_clipN.mp4"""
    out_dir = settings.OUTPUT_DIR
    primary = out_dir / f"{job_id}.mp4"
    clips = sorted(out_dir.glob(f"{job_id}_clip*.mp4"))
    urls = []
    if primary.exists():
        urls.append(f"/api/outputs/{primary.name}")
    for c in clips:
        urls.append(f"/api/outputs/{c.name}")
    return urls or None


def get_job(job_id: str) -> Optional[JobResponse]:
    if job_id in _jobs:
        job = _jobs[job_id]
        if not job.extra_outputs and str(getattr(job.status, 'value', job.status)) == JobStatus.COMPLETED.value:
            job.extra_outputs = _discover_extra_outputs(job_id)
        return job
    row = user_service.load_job_row(job_id)
    if not row:
        return None
    try:
        status = JobStatus(row.status)
    except ValueError:
        status = JobStatus.FAILED
    job = JobResponse(
        id=row.id, status=status, progress=row.progress or 0,
        message=row.message or "", created_at=row.created_at, updated_at=row.updated_at,
        output_url=row.output_url, error=row.error, input_type=row.input_type or "script",
        template=row.template or "standard", caption_style=row.caption_style or "classic",
        voice=row.voice or "en-US-JennyNeural", user_id=row.user_id,
        extra_outputs=_discover_extra_outputs(row.id) if row.status == "completed" else None,
    )
    _jobs[job_id] = job
    return job


def list_jobs(limit: int = 20, user_id: str | None = None) -> list[JobResponse]:
    rows = user_service.list_job_rows(user_id=user_id, limit=limit)
    out = []
    for row in rows:
        try:
            st = JobStatus(row.status)
        except ValueError:
            st = JobStatus.FAILED
        out.append(JobResponse(
            id=row.id, status=st, progress=row.progress or 0,
            message=row.message or "", created_at=row.created_at, updated_at=row.updated_at,
            output_url=row.output_url, error=row.error, input_type=row.input_type or "script",
            template=row.template or "standard", caption_style=row.caption_style or "classic",
            voice=row.voice or "en-US-JennyNeural", user_id=row.user_id,
            extra_outputs=_discover_extra_outputs(row.id) if row.status == "completed" else None,
        ))
    return out


def _persist(job: JobResponse, extra: dict | None = None):
    data = {
        "id": job.id, "user_id": job.user_id, "status": job.status.value if hasattr(job.status, "value") else job.status,
        "progress": job.progress, "message": job.message, "error": job.error,
        "input_type": job.input_type, "template": job.template, "caption_style": job.caption_style,
        "voice": job.voice, "output_url": job.output_url,
    }
    if extra:
        data.update(extra)
    user_service.save_job_row(data)


def _update_job(job_id: str, **kwargs):
    job = _jobs.get(job_id) or get_job(job_id)
    if not job:
        logger.warning(f"_update_job: unknown job {job_id}")
        return
    for k, v in kwargs.items():
        if k == "extra_outputs":
            job.extra_outputs = v
        else:
            setattr(job, k, v)
    job.updated_at = datetime.utcnow()
    _jobs[job_id] = job
    _persist(job)

def _is_cancelled(job_id: str) -> bool:
    job = _jobs.get(job_id) or get_job(job_id)
    if not job:
        return False
    status = job.status.value if hasattr(job.status, "value") else str(job.status)
    return status == JobStatus.CANCELLED.value


def _raise_if_cancelled(job_id: str):
    if _is_cancelled(job_id):
        raise RuntimeError("Job cancelled by user")


def cancel_job(job_id: str, user_id: str | None = None) -> JobResponse:
    """Mark a pending/processing job as cancelled. Returns updated job."""
    job = get_job(job_id)
    if not job:
        raise ValueError("Job not found")
    if user_id and job.user_id and job.user_id != user_id:
        raise ValueError("Not your job")
    status = job.status.value if hasattr(job.status, "value") else str(job.status)
    if status in (JobStatus.COMPLETED.value, JobStatus.FAILED.value, JobStatus.CANCELLED.value):
        raise ValueError(f"Cannot cancel job in status {status}")
    _update_job(job_id, status=JobStatus.CANCELLED, progress=job.progress, message="Cancelled by user")
    # Refund 1 credit if the job had consumed one (user present, not finished)
    if job.user_id:
        try:
            refund = int(getattr(job, "_credits_charged", 1) or 1)
            user_service.add_credits(job.user_id, refund, reason="job_cancel_refund")
        except Exception as e:
            logger.warning(f"Credit refund on cancel failed: {e}")
    return get_job(job_id)




def create_job(
    request: CreateJobRequest,
    upload_path: Optional[Path] = None,
    input_type: str = "script",
    user_id: str | None = None,
) -> JobResponse:
    job_id = str(uuid.uuid4())
    now = datetime.utcnow()
    template = request.template.value if hasattr(request.template, "value") else str(request.template)
    job = JobResponse(
        id=job_id, status=JobStatus.PENDING, progress=0.0, message="Queued",
        created_at=now, updated_at=now, input_type=input_type, template=template,
        caption_style=request.caption_style.value if hasattr(request.caption_style, "value") else str(request.caption_style),
        voice=request.voice.value if hasattr(request.voice, "value") else str(request.voice),
        user_id=user_id,
    )
    # Track credits for fair cancel refund (youtube multi-clip / ai visual)
    charged = 1
    if template == "youtube_reels" and request.youtube:
        charged = max(1, int(request.youtube.max_clips or 1))
    elif template == "ai_visual":
        charged = max(1, int(getattr(settings, "AI_VISUAL_CREDIT_COST", 2)))
    setattr(job, "_credits_charged", charged)
    _jobs[job_id] = job
    _persist(job)
    return job


async def run_pipeline(job_id: str, request: CreateJobRequest, upload_path: Optional[Path] = None):
    try:
        if _is_cancelled(job_id):
            return
        _update_job(job_id, status=JobStatus.PROCESSING, progress=5, message="Starting pipeline")
        work_dir = settings.TEMP_DIR / job_id
        work_dir.mkdir(parents=True, exist_ok=True)
        output_path = settings.OUTPUT_DIR / f"{job_id}.mp4"

        template = request.template
        if isinstance(template, str):
            template = TemplateType(template)

        if template == TemplateType.REDDIT_STORY:
            await _run_reddit(job_id, request, work_dir, output_path)
        elif template == TemplateType.FAKE_TEXT:
            await _run_fake_text(job_id, request, work_dir, output_path)
        elif template == TemplateType.SPLIT_SCREEN:
            await _run_split_screen(job_id, request, upload_path, work_dir, output_path)
        elif template == TemplateType.YOUTUBE_REELS:
            await _run_youtube_reels(job_id, request, work_dir, output_path)
        elif template == TemplateType.AI_VISUAL:
            await _run_ai_visual(job_id, request, work_dir, output_path)
        else:
            await _run_standard(job_id, request, upload_path, work_dir, output_path)

        size = output_path.stat().st_size if output_path.exists() else 0
        job = _jobs[job_id]
        if job.user_id and size:
            user_service.update_storage(job.user_id, size)

        job = _jobs.get(job_id)
        extra = getattr(job, "extra_outputs", None) if job else None
        done_msg = "Done"
        if extra and len(extra) > 1:
            done_msg = f"Done – {len(extra)} reels ready"
        _update_job(
            job_id, status=JobStatus.COMPLETED, progress=100, message=done_msg,
            output_url=f"/api/outputs/{job_id}.mp4",
        )
        if extra:
            _jobs[job_id].extra_outputs = extra
        _persist(_jobs[job_id], {"output_path": str(output_path), "output_bytes": size})
        logger.info(f"Job {job_id} completed")
        # Email owner if we know them
        try:
            job = _jobs.get(job_id)
            if job and job.user_id:
                from app.services import users as user_service
                from app.services.email_service import notify_job_complete
                u = user_service.get_user(job.user_id)
                if u and u.email:
                    notify_job_complete(u.email, job_id, f"/api/outputs/{job_id}.mp4")
        except Exception:
            pass

    except Exception as e:
        if "cancelled by user" in str(e).lower() or _is_cancelled(job_id):
            _update_job(job_id, status=JobStatus.CANCELLED, message="Cancelled by user")
            logger.info(f"Job {job_id} cancelled")
            return
        logger.exception(f"Job {job_id} failed")
        _update_job(job_id, status=JobStatus.FAILED, progress=0, message="Failed", error=str(e)[:500])


def _apply_manual_captions(
    manual: str | None,
    segments: list[TranscriptSegment],
    audio_duration: float | None = None,
) -> list[TranscriptSegment]:
    """If user provided captions, prefer them (SRT blocks or plain lines timed evenly)."""
    if not manual or not manual.strip():
        return segments
    text = manual.strip()
    # Full SRT?
    if re.search(r"\d+\s*\n\d{2}:\d{2}:\d{2}", text) or "-->" in text:
        try:
            from app.services.transcription import parse_srt_text
            parsed = parse_srt_text(text)
            if parsed:
                return parsed
        except Exception:
            pass
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return segments
    # Distribute across audio duration or existing segment span
    if audio_duration and audio_duration > 0:
        total = audio_duration
    elif segments:
        total = max(segments[-1].end, 1.0)
    else:
        total = max(len(lines) * 2.5, 5.0)
    slot = total / len(lines)
    out = []
    for i, line in enumerate(lines):
        out.append(TranscriptSegment(start=i * slot, end=min((i + 1) * slot, total), text=line))
    return out


async def _run_standard(job_id, request, upload_path, work_dir, output_path):
    audio_path = work_dir / "voice.wav"
    srt_path = work_dir / "captions.srt"
    segments: list[TranscriptSegment] = []
    bg_path = _resolve_bg(request.background_id)
    voice = request.voice.value if hasattr(request.voice, "value") else request.voice
    style = request.caption_style.value if hasattr(request.caption_style, "value") else str(request.caption_style)
    use_karaoke = style in ("karaoke", "bounce", "pop")

    _raise_if_cancelled(job_id)
    if request.script:
        _update_job(job_id, status=JobStatus.GENERATING_VOICE, progress=12, message="Generating voiceover")
        audio_path = work_dir / "voice.mp3"
        audio_path, segments = await generate_speech_with_timestamps(request.script, audio_path, voice=voice)
        _raise_if_cancelled(job_id)
        _update_job(job_id, progress=40, message="Voice ready")
    else:
        if not upload_path or not upload_path.exists():
            raise ValueError("No upload file and no script provided")
        _update_job(job_id, status=JobStatus.TRANSCRIBING, progress=12, message="Extracting audio")
        extract_audio(upload_path, audio_path)
        _raise_if_cancelled(job_id)
        _update_job(job_id, progress=25, message="Transcribing with word timings")
        segments = transcribe_audio(audio_path, word_timestamps=True)
        original_audio = work_dir / "original_audio.aac"
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(upload_path), "-vn", "-acodec", "copy", str(original_audio)],
            check=True, capture_output=True,
        )
        if original_audio.exists() and original_audio.stat().st_size > 1000:
            audio_path = original_audio
        _update_job(job_id, progress=50, message=f"Transcribed {len(segments)} segments")

    # Manual caption override
    try:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path)],
            capture_output=True, text=True,
        )
        aud_dur = float(probe.stdout.strip() or "0") or None
    except Exception:
        aud_dur = None
    segments = _apply_manual_captions(getattr(request, "manual_captions", None), segments, aud_dur)

    _raise_if_cancelled(job_id)
    srt_path.write_text(segments_to_srt(segments), encoding="utf-8")
    caption_path = srt_path
    if use_karaoke:
        ass_path = work_dir / "captions.ass"
        ass_path.write_text(segments_to_ass_karaoke(segments, style_name=style), encoding="utf-8")
        caption_path = ass_path
        _update_job(job_id, progress=55, message="Karaoke captions ready")
    (work_dir / "meta.txt").write_text(f"style={style}\naudio={audio_path}\nsrt={srt_path}\ncaption={caption_path}\n")

    _raise_if_cancelled(job_id)
    _update_job(job_id, status=JobStatus.COMPOSING, progress=65, message="Composing vertical video")
    compose_video_ffmpeg(
        audio_path=audio_path, srt_path=caption_path, output_path=output_path,
        background_path=bg_path, caption_style=style,
    )
    _update_job(job_id, progress=95, message="Finalizing")


async def _run_ai_visual(job_id, request, work_dir, output_path):
    """Faceless quality reel: script → scene prompts → images → Ken Burns + TTS + captions."""
    from app.services.image_gen import plan_scene_prompts, generate_scene_images
    from app.models.schemas import AiVisualRequest

    voice = request.voice.value if hasattr(request.voice, "value") else request.voice
    style = request.caption_style.value if hasattr(request.caption_style, "value") else str(request.caption_style)
    av = request.ai_visual or AiVisualRequest()
    max_scenes = min(int(av.max_scenes or 4), settings.AI_VISUAL_MAX_SCENES)

    script = (request.script or "").strip()
    if not script and av.topic:
        _update_job(job_id, progress=8, message="Generating script from topic")
        from app.services.script_gen import generate_script
        result = await generate_script(av.topic, brief="", tone="engaging", length="medium")
        script = result["script"]
    if not script or len(script) < 20:
        raise ValueError("ai_visual requires a script (or topic to generate one)")

    _raise_if_cancelled(job_id)
    _update_job(job_id, status=JobStatus.GENERATING_VOICE, progress=15, message="Generating voiceover")
    audio_path = work_dir / "voice.mp3"
    audio_path, segments = await generate_speech_with_timestamps(script, audio_path, voice=voice)

    segments = _apply_manual_captions(getattr(request, "manual_captions", None), segments)
    srt_path = work_dir / "captions.srt"
    srt_path.write_text(segments_to_srt(segments), encoding="utf-8")
    caption_path = srt_path
    if style in ("karaoke", "bounce", "pop"):
        ass_path = work_dir / "captions.ass"
        ass_path.write_text(segments_to_ass_karaoke(segments, style_name=style), encoding="utf-8")
        caption_path = ass_path

    _raise_if_cancelled(job_id)
    _update_job(job_id, progress=35, message="Planning visual scenes")
    style_hint = {
        "cinematic": "cinematic film still, dramatic lighting",
        "illustration": "clean digital illustration, soft shading",
        "photo": "photorealistic, natural light",
        "minimal": "minimal abstract geometric, premium",
    }.get(av.image_style or "cinematic", "cinematic film still")
    prompts = await plan_scene_prompts(script, max_scenes=max_scenes)
    prompts = [f"{p}, {style_hint}, vertical 9:16, no text, no watermark" for p in prompts]

    _raise_if_cancelled(job_id)
    _update_job(job_id, progress=45, message=f"Generating {len(prompts)} scene images")
    images = await generate_scene_images(prompts, work_dir / "scenes")

    # Choose renderer: HyperFrames (HTML/GSAP) or built-in Ken Burns
    renderer = (getattr(av, "renderer", None) or "auto").lower().strip()
    use_hf = False
    if renderer in ("hyperframes", "auto") or getattr(settings, "HYPERFRAMES_PREFER", False):
        try:
            from app.services.hyperframes_renderer import (
                hyperframes_available,
                render_ai_visual_with_hyperframes,
            )
            if hyperframes_available() or renderer == "hyperframes":
                use_hf = True
        except Exception as e:
            logger.warning(f"HyperFrames check failed: {e}")

    _raise_if_cancelled(job_id)
    if use_hf:
        _update_job(job_id, status=JobStatus.COMPOSING, progress=70, message="Composing with HyperFrames…")
        try:
            await render_ai_visual_with_hyperframes(
                work_dir,
                image_paths=images,
                audio_path=audio_path,
                segments=segments if request.burn_captions else [],
                output_path=output_path,
                title=(av.topic or "")[:60],
            )
            _update_job(job_id, progress=95, message="Finalizing HyperFrames reel")
            return
        except Exception as e:
            logger.warning(f"HyperFrames render failed, falling back to Ken Burns: {e}")

    _update_job(job_id, status=JobStatus.COMPOSING, progress=70, message="Composing Ken Burns reel")
    compose_ken_burns_slideshow(
        image_paths=images,
        audio_path=audio_path,
        output_path=output_path,
        srt_path=caption_path if request.burn_captions else None,
        caption_style=style,
    )
    _update_job(job_id, progress=95, message="Finalizing AI visual reel")


async def _run_reddit(job_id, request, work_dir, output_path):
    if not request.reddit:
        raise ValueError("reddit payload required")
    req = request.reddit
    voice = request.voice.value if hasattr(request.voice, "value") else request.voice
    style = request.caption_style.value if hasattr(request.caption_style, "value") else str(request.caption_style)

    _update_job(job_id, progress=10, message="Rendering Reddit card")
    card_path = work_dir / "reddit_card.png"
    render_reddit_card(req, card_path)

    script = reddit_script_from_request(req)
    _update_job(job_id, status=JobStatus.GENERATING_VOICE, progress=25, message="Generating narration")
    audio_path = work_dir / "voice.mp3"
    audio_path, segments = await generate_speech_with_timestamps(script, audio_path, voice=voice)
    srt_path = work_dir / "captions.srt"
    srt_path.write_text(segments_to_srt(segments), encoding="utf-8")
    bg_path = _resolve_bg(request.background_id)
    _update_job(job_id, status=JobStatus.COMPOSING, progress=55, message="Composing Reddit story video")
    _compose_reddit_video(card_path, audio_path, srt_path, bg_path, output_path, style)


def _compose_reddit_video(card_path, audio_path, srt_path, background_path, output_path, caption_style):
    from app.services.video import _style_to_force_style
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path)],
        capture_output=True, text=True,
    )
    duration = float(probe.stdout.strip())
    w, h = settings.TARGET_WIDTH, settings.TARGET_HEIGHT
    force_style = _style_to_force_style(caption_style)
    srt_escaped = Path(srt_path).resolve().as_posix().replace(":", "\\:")

    if background_path and background_path.exists():
        filter_complex = (
            f"[0:v]scale={w}:{h}:force_original_aspect_ratio=increase,"
            f"crop={w}:{h},loop=loop=-1:size=32767:start=0,setpts=N/FRAME_RATE/TB,"
            f"trim=duration={duration},setsar=1[bg];"
            f"[1:v]scale={int(w*0.92)}:-1[card];"
            f"[bg][card]overlay=(W-w)/2:(H-h)/2-80[v1];"
            f"[v1]subtitles='{srt_escaped}':force_style='{force_style}'[outv]"
        )
        cmd = [
            "ffmpeg", "-y", "-stream_loop", "-1", "-i", str(background_path),
            "-i", str(card_path), "-i", str(audio_path),
            "-filter_complex", filter_complex,
            "-map", "[outv]", "-map", "2:a",
            "-c:v", "libx264", "-preset", "medium", "-crf", "22",
            "-c:a", "aac", "-b:a", "192k", "-t", str(duration),
            "-movflags", "+faststart", str(output_path),
        ]
    else:
        filter_complex = (
            f"[0:v]scale={w}:{h}[bg];[1:v]scale={int(w*0.92)}:-1[card];"
            f"[bg][card]overlay=(W-w)/2:(H-h)/2-80[v1];"
            f"[v1]subtitles='{srt_escaped}':force_style='{force_style}'[outv]"
        )
        cmd = [
            "ffmpeg", "-y",
            "-f", "lavfi", "-i", f"color=c=0x1a1a1b:s={w}x{h}:d={duration}",
            "-i", str(card_path), "-i", str(audio_path),
            "-filter_complex", filter_complex,
            "-map", "[outv]", "-map", "2:a",
            "-c:v", "libx264", "-preset", "medium", "-crf", "22",
            "-c:a", "aac", "-b:a", "192k", "-t", str(duration),
            "-movflags", "+faststart", str(output_path),
        ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"Reddit compose failed: {result.stderr[-400:]}")


async def _run_fake_text(job_id, request, work_dir, output_path):
    if not request.fake_text:
        raise ValueError("fake_text payload required")
    ft = request.fake_text
    voice = request.voice.value if hasattr(request.voice, "value") else request.voice
    _update_job(job_id, progress=10, message="Rendering conversation frames")
    frames, durations, script = render_conversation_frames(ft, work_dir / "frames")
    audio_path = None
    if ft.narrate and script:
        _update_job(job_id, status=JobStatus.GENERATING_VOICE, progress=35, message="Generating narration")
        audio_path = work_dir / "voice.mp3"
        await generate_speech_with_timestamps(script, audio_path, voice=voice)
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path)],
            capture_output=True, text=True,
        )
        audio_dur = float(probe.stdout.strip())
        total = sum(durations)
        if total > 0 and abs(audio_dur - total) > 0.5:
            scale = audio_dur / total
            durations = [d * scale for d in durations]
    _update_job(job_id, status=JobStatus.COMPOSING, progress=65, message="Stitching conversation video")
    frames_to_video(frames, durations, output_path, audio_path=audio_path)


async def _run_split_screen(job_id, request, upload_path, work_dir, output_path):
    from app.models.schemas import SplitScreenRequest
    ss = request.split_screen or SplitScreenRequest()
    voice = request.voice.value if hasattr(request.voice, "value") else request.voice
    style = request.caption_style.value if hasattr(request.caption_style, "value") else str(request.caption_style)

    if not request.script:
        raise ValueError("script required for split_screen template")
    _update_job(job_id, status=JobStatus.GENERATING_VOICE, progress=20, message="Generating voiceover")
    audio_path = work_dir / "voice.mp3"
    audio_path, segments = await generate_speech_with_timestamps(request.script, audio_path, voice=voice)
    srt_path = work_dir / "captions.srt"
    srt_path.write_text(segments_to_srt(segments), encoding="utf-8")

    bg = _resolve_bg(request.background_id)
    content = upload_path if upload_path and upload_path.exists() else bg

    _update_job(job_id, status=JobStatus.COMPOSING, progress=55, message="Composing split-screen")
    compose_split_screen(
        content_video=content,
        audio_path=audio_path,
        srt_path=srt_path,
        output_path=output_path,
        req=ss,
        caption_style=style,
    )



async def _run_youtube_reels(job_id, request, work_dir, output_path):
    """Download YouTube video, detect viral moments (LLM + energy), export vertical reels.

    Inspired by https://github.com/Anil-matcha/AI-Youtube-Shorts-Generator:
    - Transcribe full video
    - LLM ranks clips by virality (hooks, emotional peaks, opinion bombs, …)
    - Falls back to energy/silence detection when LLM is unavailable
    - Each clip can carry score / title / hook / reason in job metadata
    """
    import shutil
    from app.services.youtube import download_video, probe_duration
    from app.services.autoclip import detect_highlights, extract_vertical_clip
    from app.services.transcription import transcribe_audio, segments_to_srt, segments_to_ass_karaoke
    from app.services.virality_highlights import (
        rank_highlights_with_llm,
        highlights_to_intervals,
    )

    yt = request.youtube
    if not yt or not yt.url:
        raise ValueError("youtube.url is required for youtube_reels template")

    max_clips = int(yt.max_clips or 5)
    min_sec = float(yt.min_clip_sec or 12)
    max_sec = float(yt.max_clip_sec or 45)
    burn = bool(getattr(yt, "burn_captions", True))
    use_llm = bool(getattr(yt, "use_llm_highlights", True)) and getattr(
        settings, "YOUTUBE_USE_LLM_HIGHLIGHTS", True
    )
    style = request.caption_style.value if hasattr(request.caption_style, "value") else str(request.caption_style)

    _raise_if_cancelled(job_id)
    _update_job(job_id, progress=8, message="Downloading YouTube video…")
    dl_dir = work_dir / "yt"
    dl_dir.mkdir(parents=True, exist_ok=True)
    source = download_video(yt.url, dl_dir)
    duration = probe_duration(source)
    _update_job(job_id, progress=22, message=f"Downloaded ({duration:.0f}s). Transcribing…")

    # Full-video transcription enables LLM virality ranking
    highlight_meta = []  # list of dicts with score/title/hook/reason
    highlights: list = []

    _raise_if_cancelled(job_id)
    full_audio = work_dir / "full_audio.wav"
    try:
        extract_audio(source, full_audio)
        full_segments = transcribe_audio(full_audio, word_timestamps=False)
    except Exception as e:
        logger.warning(f"Full transcription failed: {e}")
        full_segments = []

    if use_llm and full_segments:
        _update_job(job_id, progress=32, message="Ranking viral highlights with LLM…")
        ranked = await rank_highlights_with_llm(
            full_segments,
            max_clips=max_clips,
            min_clip_sec=min_sec,
            max_clip_sec=max_sec,
        )
        if ranked:
            highlights = highlights_to_intervals(ranked)
            highlight_meta = [h.to_dict() for h in ranked]
            _update_job(
                job_id, progress=40,
                message=f"LLM selected {len(highlights)} viral clip(s)",
            )

    if not highlights:
        _update_job(job_id, progress=35, message="Finding highlights (energy / silence)…")
        highlights = detect_highlights(
            source,
            max_clips=max_clips,
            min_clip_sec=min_sec,
            max_clip_sec=max_sec,
            target_total_sec=max_clips * max_sec,
        )
        if not highlights:
            highlights = [(0.0, min(duration or max_sec, max_sec))]

    _update_job(
        job_id, progress=42,
        message=f"Found {len(highlights)} highlight(s). Rendering vertical reels…",
    )

    outputs = []
    total = len(highlights)
    for i, (start, end) in enumerate(highlights):
        _raise_if_cancelled(job_id)
        pct = 42 + int(48 * (i / max(1, total)))
        meta = highlight_meta[i] if i < len(highlight_meta) else {}
        title_hint = meta.get("title") or f"{start:.1f}s–{end:.1f}s"
        _update_job(
            job_id, progress=pct,
            message=f"Rendering reel {i + 1}/{total}: {title_hint}",
        )

        clip_name = f"{job_id}.mp4" if i == 0 else f"{job_id}_clip{i + 1}.mp4"
        clip_out = settings.OUTPUT_DIR / clip_name
        raw_clip = work_dir / f"raw_clip_{i}.mp4"
        extract_vertical_clip(source, start, end, raw_clip)

        if burn:
            try:
                audio_path = work_dir / f"clip_{i}.wav"
                extract_audio(raw_clip, audio_path)
                segments = transcribe_audio(audio_path, word_timestamps=True)
                if segments:
                    use_karaoke = style in ("karaoke", "bounce", "pop")
                    if use_karaoke:
                        cap = work_dir / f"clip_{i}.ass"
                        cap.write_text(segments_to_ass_karaoke(segments, style_name=style), encoding="utf-8")
                    else:
                        cap = work_dir / f"clip_{i}.srt"
                        cap.write_text(segments_to_srt(segments), encoding="utf-8")
                    compose_video_ffmpeg(
                        audio_path=audio_path,
                        srt_path=cap,
                        output_path=clip_out,
                        background_path=raw_clip,
                        caption_style=style,
                    )
                else:
                    shutil.copy2(raw_clip, clip_out)
            except Exception as e:
                logger.warning(f"Caption burn failed for clip {i}: {e}; using raw vertical clip")
                shutil.copy2(raw_clip, clip_out)
        else:
            shutil.copy2(raw_clip, clip_out)

        outputs.append(f"/api/outputs/{clip_name}")

    # Persist highlight metadata for the API / UI
    if highlight_meta:
        meta_file = work_dir / "highlights.json"
        try:
            import json
            meta_file.write_text(json.dumps(highlight_meta, indent=2), encoding="utf-8")
        except Exception:
            pass

    job = _jobs.get(job_id)
    if job:
        job.extra_outputs = outputs
        _jobs[job_id] = job
    _update_job(
        job_id, progress=95,
        message=f"Created {len(outputs)} viral reel(s) from YouTube",
        extra_outputs=outputs,
    )
    logger.info(f"YouTube reels job {job_id}: {outputs} meta={len(highlight_meta)}")


def apply_tweaks(job_id: str, tweaks: TweakRequest) -> JobResponse:
    """Re-export with new style/trim/volume using cached intermediates when possible."""
    job = get_job(job_id)
    if not job or job.status != JobStatus.COMPLETED:
        raise ValueError("Job must be completed")
    work_dir = settings.TEMP_DIR / job_id
    meta_path = work_dir / "meta.txt"
    if not meta_path.exists():
        raise ValueError("No intermediate files for tweaks (only standard jobs supported currently)")

    meta = dict(line.split("=", 1) for line in meta_path.read_text().strip().splitlines() if "=" in line)
    audio_path = Path(meta.get("audio", ""))
    srt_path = Path(meta.get("srt", ""))
    if not audio_path.exists() or not srt_path.exists():
        raise ValueError("Cached audio/srt missing")

    style = tweaks.caption_style.value if tweaks.caption_style else job.caption_style
    if hasattr(style, "value"):
        style = style.value
    new_out = settings.OUTPUT_DIR / f"{job_id}_tweak.mp4"
    # Prefer ASS caption file for karaoke styles when available
    caption = Path(meta.get("caption", meta.get("srt", "")))
    if style in ("karaoke", "bounce", "pop"):
        ass_cand = work_dir / "captions.ass"
        if ass_cand.exists():
            srt_path = ass_cand
        elif caption.exists() and str(caption).endswith(".ass"):
            srt_path = caption
    elif caption.exists() and str(caption).endswith(".srt"):
        srt_path = caption

    # Optional trim via ffmpeg
    if tweaks.trim_start or tweaks.trim_end:
        trimmed = work_dir / "trimmed_audio.mp3"
        ss = tweaks.trim_start or 0
        cmd = ["ffmpeg", "-y", "-i", str(audio_path), "-ss", str(ss)]
        if tweaks.trim_end:
            cmd += ["-to", str(tweaks.trim_end)]
        cmd += ["-c", "copy", str(trimmed)]
        subprocess.run(cmd, check=True, capture_output=True)
        audio_path = trimmed

    if tweaks.volume and tweaks.volume != 1.0:
        vol_out = work_dir / "vol_audio.mp3"
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(audio_path), "-filter:a", f"volume={tweaks.volume}", str(vol_out)],
            check=True, capture_output=True,
        )
        audio_path = vol_out

    compose_video_ffmpeg(
        audio_path=audio_path, srt_path=srt_path, output_path=new_out,
        background_path=None, caption_style=style,
    )
    # Replace main output
    final = settings.OUTPUT_DIR / f"{job_id}.mp4"
    new_out.replace(final)
    _update_job(job_id, caption_style=style, message="Tweaked", output_url=f"/api/outputs/{job_id}.mp4")
    return _jobs[job_id]


def _resolve_bg(background_id: str | None) -> Optional[Path]:
    if not background_id:
        return None
    # Prevent path traversal in background_id
    name = Path(background_id).name
    if not name or name != background_id or ".." in background_id:
        return None
    candidate = (settings.BACKGROUND_DIR / name).resolve()
    base = settings.BACKGROUND_DIR.resolve()
    try:
        candidate.relative_to(base)
    except ValueError:
        return None
    return candidate if candidate.exists() else None
