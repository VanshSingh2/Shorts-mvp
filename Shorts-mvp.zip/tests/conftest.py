"""Shared fixtures. Isolated SQLite. Mocks heavy ML / media packages."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock

def _mock_pkg(name: str) -> MagicMock:
    m = MagicMock()
    m.__name__ = name
    m.__path__ = []
    sys.modules[name] = m
    return m

for name in [
    "faster_whisper",
    "edge_tts",
    "rembg",
    "celery",
    "celery.result",
    "stripe",
    "moviepy",
    "moviepy.editor",
    "moviepy.video",
    "moviepy.video.fx",
    "moviepy.video.io",
    "moviepy.audio",
    "moviepy.audio.fx",
]:
    _mock_pkg(name)

# Support: from moviepy import VideoFileClip, ...
import moviepy  # type: ignore
for attr in [
    "VideoFileClip", "AudioFileClip", "TextClip", "CompositeVideoClip",
    "ColorClip", "concatenate_videoclips", "ImageClip",
]:
    setattr(moviepy, attr, MagicMock())

# Support: from moviepy.video.fx import Loop, Resize, Crop
import moviepy.video.fx as _fx  # type: ignore
for attr in ["Loop", "Resize", "Crop"]:
    setattr(_fx, attr, MagicMock())

_tmp = tempfile.mkdtemp(prefix="shorts_test_")
os.environ["DATABASE_URL"] = ""
os.environ["CELERY_BROKER_URL"] = ""
os.environ["CELERY_RESULT_BACKEND"] = ""
os.environ["STRIPE_SECRET_KEY"] = "sk_test_placeholder"
os.environ["RESEND_API_KEY"] = ""
os.environ["DEBUG"] = "true"
os.environ["RATE_LIMIT_AUTH"] = "1000/minute"
os.environ["RATE_LIMIT_JOBS"] = "1000/minute"
os.environ["RATE_LIMIT_DEFAULT"] = "1000/minute"
os.environ["WHISPER_MODEL"] = "base"

from app.core import config as config_mod
config_mod.settings.DATABASE_URL = ""
config_mod.settings.RATE_LIMIT_AUTH = "1000/minute"
config_mod.settings.RATE_LIMIT_JOBS = "1000/minute"
config_mod.settings.RATE_LIMIT_DEFAULT = "1000/minute"
config_mod.settings.BASE_DIR = Path(_tmp)
config_mod.settings.UPLOAD_DIR = Path(_tmp) / "uploads"
config_mod.settings.OUTPUT_DIR = Path(_tmp) / "outputs"
config_mod.settings.BACKGROUND_DIR = Path(_tmp) / "backgrounds"
config_mod.settings.TEMP_DIR = Path(_tmp) / "temp"
config_mod.settings.ASSETS_DIR = Path(_tmp) / "assets"
for d in [
    config_mod.settings.UPLOAD_DIR,
    config_mod.settings.OUTPUT_DIR,
    config_mod.settings.BACKGROUND_DIR,
    config_mod.settings.TEMP_DIR,
    config_mod.settings.ASSETS_DIR,
]:
    d.mkdir(parents=True, exist_ok=True)

from app.db import database as db_mod
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

_db_path = Path(_tmp) / "test.db"
db_mod.engine = create_engine(
    f"sqlite:///{_db_path}", connect_args={"check_same_thread": False}
)
db_mod.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=db_mod.engine)
db_mod.Base.metadata.create_all(bind=db_mod.engine)

import pytest
from fastapi.testclient import TestClient

from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture
def registered_user(client):
    email = f"test_{os.urandom(4).hex()}@example.com"
    password = "TestPass123"
    r = client.post(
        "/api/auth/register",
        json={"email": email, "password": password, "name": "Test User"},
    )
    assert r.status_code == 200, r.text
    user = r.json()
    r2 = client.post("/api/auth/login", json={"email": email, "password": password})
    assert r2.status_code == 200, r2.text
    data = r2.json()
    return user, data["token"], email, password


@pytest.fixture
def auth_headers(registered_user):
    _, token, _, _ = registered_user
    return {"Authorization": f"Bearer {token}"}
