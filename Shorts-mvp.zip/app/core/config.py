from pathlib import Path
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    """
    Free-tier defaults: Postgres (Neon/local) + Redis + Resend.
    SQLite only if DATABASE_URL is empty (offline/dev fallback).
    """
    APP_NAME: str = "Shorts MVP"
    DEBUG: bool = True
    VERSION: str = "0.8.0"
    DEPLOY_MODE: str = "growth"  # bootstrap | growth | scale
    
    BASE_DIR: Path = Path(__file__).resolve().parent.parent.parent
    UPLOAD_DIR: Path = BASE_DIR / "uploads"
    OUTPUT_DIR: Path = BASE_DIR / "outputs"
    BACKGROUND_DIR: Path = BASE_DIR / "backgrounds"
    TEMP_DIR: Path = BASE_DIR / "temp"
    ASSETS_DIR: Path = BASE_DIR / "assets"
    
    TARGET_WIDTH: int = 1080
    TARGET_HEIGHT: int = 1920
    FPS: int = 30
    
    WHISPER_MODEL: str = "base"
    WHISPER_DEVICE: str = "cpu"
    WHISPER_COMPUTE: str = "int8"
    
    DEFAULT_VOICES: list[str] = [
        "en-US-JennyNeural", "en-US-GuyNeural", "en-GB-SoniaNeural",
        "en-US-AriaNeural", "en-US-DavisNeural", "en-US-JaneNeural",
        "es-ES-ElviraNeural", "fr-FR-DeniseNeural", "de-DE-KatjaNeural",
        "pt-BR-FranciscaNeural", "ja-JP-NanamiNeural", "hi-IN-SwaraNeural",
    ]
    
    CAPTION_STYLES: dict = {
        "classic": {"fontsize": 70, "color": "white", "stroke_color": "black", "stroke_width": 3, "position": ("center", 0.75)},
        "bold_yellow": {"fontsize": 80, "color": "yellow", "stroke_color": "black", "stroke_width": 4, "position": ("center", 0.7)},
        "minimal": {"fontsize": 60, "color": "white", "stroke_color": "black", "stroke_width": 2, "position": ("center", 0.8)},
        "karaoke": {"fontsize": 72, "color": "white", "stroke_color": "black", "stroke_width": 3, "position": ("center", 0.72), "highlight": True},
        "neon": {"fontsize": 75, "color": "#00ffcc", "stroke_color": "black", "stroke_width": 3, "position": ("center", 0.75)},
        "bounce": {"fontsize": 78, "color": "white", "stroke_color": "black", "stroke_width": 4, "position": ("center", 0.70)},
        "pop": {"fontsize": 82, "color": "#ffee00", "stroke_color": "black", "stroke_width": 5, "position": ("center", 0.68)},
    }
    
    FREE_CREDITS: int = 20
    FREE_VIDEOS_PER_WEEK: int = 15
    FREE_BATCH_SIZE: int = 3
    FREE_STORAGE_MB: int = 500
    FREE_CONCURRENT_JOBS: int = 2
    PRO_CREDITS_MONTHLY: int = 200
    PRO_VIDEOS_PER_WEEK: int = 200
    PRO_BATCH_SIZE: int = 5
    PRO_STORAGE_MB: int = 5000
    PRO_CONCURRENT_JOBS: int = 5
    PRO_PRICE_CENTS: int = 1900
    STUDIO_CREDITS_MONTHLY: int = 1000
    STUDIO_BATCH_SIZE: int = 10
    STUDIO_STORAGE_MB: int = 50000
    STUDIO_CONCURRENT_JOBS: int = 15
    STUDIO_PRICE_CENTS: int = 4900
    
    CREDIT_PACKS: dict = {
        "pack_50": {"credits": 50, "price_cents": 900, "label": "50 credits – $9"},
        "pack_150": {"credits": 150, "price_cents": 1900, "label": "150 credits – $19"},
        "pack_500": {"credits": 500, "price_cents": 4900, "label": "500 credits – $49"},
    }
    
    STRIPE_SECRET_KEY: str = "sk_test_placeholder"
    STRIPE_PUBLISHABLE_KEY: str = "pk_test_placeholder"
    STRIPE_WEBHOOK_SECRET: str = "whsec_placeholder"
    STRIPE_SUCCESS_URL: str = "http://localhost:8000/?billing=success"
    STRIPE_CANCEL_URL: str = "http://localhost:8000/?billing=cancel"
    # Optional pre-created Stripe Price IDs (Dashboard → Products)
    STRIPE_PRICE_PRO: str = ""
    STRIPE_PRICE_STUDIO: str = ""
    STRIPE_PRICE_PACK_50: str = ""
    STRIPE_PRICE_PACK_150: str = ""
    STRIPE_PRICE_PACK_500: str = ""
    
    # Resend (preferred) or any SMTP
    # Resend SMTP: host=smtp.resend.com user=resend password=<API_KEY>
    # Or set RESEND_API_KEY to use HTTPS API instead of SMTP
    RESEND_API_KEY: str = ""
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = "noreply@yourdomain.com"
    
    # Redis + Celery (Upstash free or local docker redis)
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/1"
    
    STORAGE_BACKEND: str = "local"
    S3_ENDPOINT_URL: str = ""
    S3_ACCESS_KEY: str = ""
    S3_SECRET_KEY: str = ""
    S3_BUCKET: str = ""
    S3_PUBLIC_BASE_URL: str = ""
    
    # Postgres: Neon/Supabase free, or local docker postgres
    # Example Neon: postgresql://user:pass@ep-xxx.region.aws.neon.tech/shorts?sslmode=require
    DATABASE_URL: str = "postgresql://shorts:shorts@localhost:5432/shorts"
    
    JOB_RETENTION_DAYS: int = 14
    ENABLE_MODERATION: bool = True
    ENABLE_REMBG: bool = True
    MAX_AUTOCLIPS: int = 5
    MAX_UPLOAD_SIZE_MB: int = 200
    JOB_TIMEOUT_SECONDS: int = 900
    SENTRY_DSN: str = ""
    ADMIN_API_TOKEN: str = ""  # optional; protects /api/metrics and admin cleanup
    # OpenAI-compatible LLM for script generation (optional)
    # Examples:
    #   OpenAI:  LLM_BASE_URL=https://api.openai.com/v1  LLM_MODEL=gpt-4o-mini
    #   Groq:    LLM_BASE_URL=https://api.groq.com/openai/v1  LLM_MODEL=llama-3.1-8b-instant
    #   OpenRouter / Together: set base URL + model accordingly
    LLM_API_KEY: str = ""
    LLM_BASE_URL: str = "https://api.openai.com/v1"
    LLM_MODEL: str = "gpt-4o-mini"
    # Image generation (OpenAI Images API or compatible)
    # OpenAI: IMAGE_MODEL=dall-e-3  or gpt-image-1
    # OpenRouter: set IMAGE_BASE_URL if different; many routes still use OpenAI for images
    IMAGE_GEN_ENABLED: bool = True
    IMAGE_MODEL: str = "dall-e-3"
    IMAGE_BASE_URL: str = ""  # empty = use LLM_BASE_URL
    IMAGE_SIZE: str = "1024x1792"  # portrait-friendly for DALL·E 3
    IMAGE_QUALITY: str = "standard"  # standard | hd
    AI_VISUAL_MAX_SCENES: int = 5
    AI_VISUAL_CREDIT_COST: int = 2  # costs more (images + render)

    # HyperFrames (https://github.com/heygen-com/hyperframes) – optional HTML→MP4 renderer
    # Requires Node.js >= 22 on the host. When enabled, AI Visual can use it as an
    # alternative to the built-in Ken Burns pipeline for polished motion + kinetic captions.
    HYPERFRAMES_ENABLED: bool = False
    HYPERFRAMES_PREFER: bool = False  # if True and available, prefer HyperFrames for AI Visual

    # YouTube reels – LLM virality ranking (inspired by Anil-matcha/AI-Youtube-Shorts-Generator)
    YOUTUBE_USE_LLM_HIGHLIGHTS: bool = True  # fall back to energy detection if LLM fails / no key
    YOUTUBE_MAX_SOURCE_DURATION_SEC: int = 3600  # 60 min hard cap for download/process

    # Rate limits (slowapi style: "N/period")
    RATE_LIMIT_AUTH: str = "10/minute"
    RATE_LIMIT_JOBS: str = "20/minute"
    RATE_LIMIT_DEFAULT: str = "60/minute"
    NOWPAYMENTS_API_KEY: str = ""
    NOWPAYMENTS_IPN_SECRET: str = ""
    CRYPTO_PAY_CURRENCY: str = "usdttrc20"
    CRYPTO_IPN_URL: str = ""
    CRYPTO_SIMULATE: bool = False
    # When true, missing payment keys may still grant credits (dev only). Default false in spirit of prod; true only if you set it.
    ALLOW_PAYMENT_SIMULATE: bool = True  # set false in production once keys are live
    MAX_SESSIONS_PER_USER: int = 20
    TOKEN_TTL_DAYS: int = 7
    PASSWORD_MIN_LENGTH: int = 8
    
    class Config:
        env_file = ".env"

settings = Settings()

for d in [settings.UPLOAD_DIR, settings.OUTPUT_DIR, settings.BACKGROUND_DIR, settings.TEMP_DIR, settings.ASSETS_DIR]:
    d.mkdir(parents=True, exist_ok=True)
