"""Moderation unit tests."""
from app.services.moderation import check_text, check_job_payload


def test_clean_text():
    assert check_text("Hello world, this is a normal story.") is None


def test_blocked_phrase():
    reason = check_text("please kill yourself now")
    assert reason is not None
    assert "policy" in reason.lower() or "blocked" in reason.lower()


def test_empty_ok():
    assert check_text("") is None
    assert check_text(None) is None  # type: ignore


def test_too_long():
    reason = check_text("x" * 16000)
    assert reason is not None
    assert "long" in reason.lower()


def test_job_payload_reddit():
    reason = check_job_payload(None, "how to make a bomb tutorial", None)
    assert reason is not None


def test_job_payload_clean():
    assert check_job_payload("Nice day for a walk", None, None) is None
