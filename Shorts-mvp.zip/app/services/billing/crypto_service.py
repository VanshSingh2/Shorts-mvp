"""Crypto checkout via NOWPayments-compatible API.

Production:
  NOWPAYMENTS_API_KEY + optional NOWPAYMENTS_IPN_SECRET
  CRYPTO_IPN_URL = https://yourdomain.com/api/billing/crypto/webhook
  Credits granted only after IPN status finished/confirmed

Simulation (dev only):
  Empty API key, or ALLOW_PAYMENT_SIMULATE=true / CRYPTO_SIMULATE=true
  Never auto-grants when a real API key is set and the provider errors
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import secrets
import uuid
from datetime import datetime
from typing import Optional

import httpx

from app.core.config import settings
from app.db.database import SessionLocal, PaymentRow
from app.services.billing.plans import resolve_checkout_kind
from app.services import users as user_service

logger = logging.getLogger(__name__)

NOWPAYMENTS_API = "https://api.nowpayments.io/v1"


def _api_key() -> str:
    return (getattr(settings, "NOWPAYMENTS_API_KEY", None) or "").strip()


def crypto_configured() -> bool:
    key = _api_key()
    if not key:
        return False
    low = key.lower()
    if low in {"placeholder", "changeme", "your_key", "xxx"} or "placeholder" in low:
        return False
    if getattr(settings, "CRYPTO_SIMULATE", False):
        return False
    return len(key) >= 8


def allow_simulate() -> bool:
    if getattr(settings, "ALLOW_PAYMENT_SIMULATE", False):
        return True
    if getattr(settings, "CRYPTO_SIMULATE", False):
        return True
    return not crypto_configured()


def _pay_currency() -> str:
    return (getattr(settings, "CRYPTO_PAY_CURRENCY", None) or "usdttrc20").lower()


def create_crypto_invoice(user_id: str, email: str, kind: str) -> dict:
    """
    Returns {checkout_url, session_id, provider, status, simulated?}
    """
    product = resolve_checkout_kind(kind)
    payment_id = str(uuid.uuid4())
    amount_usd = max(product["amount_cents"] / 100.0, 1.0)

    db = SessionLocal()
    try:
        row = PaymentRow(
            id=payment_id,
            user_id=user_id,
            provider="crypto",
            kind=product["kind"],
            status="pending",
            amount_cents=product["amount_cents"],
            currency="usd",
            credits_grant=product["credits"],
            plan_grant=product.get("plan"),
            external_id=None,
            checkout_url=None,
            raw_meta=json.dumps({"email": email, "label": product["label"]}),
        )
        db.add(row)
        db.commit()
    finally:
        db.close()

    if not crypto_configured():
        if not allow_simulate():
            raise RuntimeError(
                "Crypto payments not configured. Set NOWPAYMENTS_API_KEY "
                "or ALLOW_PAYMENT_SIMULATE=true for local testing only."
            )
        return _simulate_crypto(payment_id, user_id, product)

    # Live path — errors propagate (no free grant)
    headers = {"x-api-key": _api_key(), "Content-Type": "application/json"}
    payload = {
        "price_amount": amount_usd,
        "price_currency": "usd",
        "pay_currency": _pay_currency(),
        "order_id": payment_id,
        "order_description": product["label"],
        "ipn_callback_url": getattr(settings, "CRYPTO_IPN_URL", "") or None,
        "success_url": settings.STRIPE_SUCCESS_URL + f"&provider=crypto&payment_id={payment_id}",
        "cancel_url": settings.STRIPE_CANCEL_URL,
    }
    payload = {k: v for k, v in payload.items() if v is not None}

    with httpx.Client(timeout=30.0) as client:
        r = client.post(f"{NOWPAYMENTS_API}/invoice", headers=headers, json=payload)
        if r.status_code >= 400:
            logger.error(f"NOWPayments error {r.status_code}: {r.text[:400]}")
            raise RuntimeError(f"Crypto provider error ({r.status_code}): {r.text[:200]}")
        data = r.json()

    inv_url = data.get("invoice_url") or data.get("pay_url")
    external = str(data.get("id") or data.get("invoice_id") or "")
    _update_payment(payment_id, external_id=external, checkout_url=inv_url, meta=data)
    if not inv_url:
        raise RuntimeError("Crypto provider did not return a payment URL")

    return {
        "checkout_url": inv_url,
        "session_id": payment_id,
        "provider": "crypto",
        "status": "pending",
        "simulated": False,
    }


def _simulate_crypto(payment_id: str, user_id: str, product: dict, note: str = "") -> dict:
    logger.warning(f"Crypto simulate grant payment={payment_id} note={note}")
    fulfill_payment(payment_id, provider_ref=f"sim_{secrets.token_hex(6)}", force=True)
    url = settings.STRIPE_SUCCESS_URL + f"&provider=crypto&payment_id={payment_id}&simulated=1"
    return {
        "checkout_url": url,
        "session_id": payment_id,
        "provider": "crypto",
        "status": "completed",
        "simulated": True,
        "message": "Crypto not configured — credits granted in simulation mode (dev only)",
    }


def _update_payment(payment_id: str, **fields):
    db = SessionLocal()
    try:
        row = db.query(PaymentRow).filter(PaymentRow.id == payment_id).first()
        if not row:
            return
        for k, v in fields.items():
            if k == "meta" and v is not None:
                row.raw_meta = json.dumps(v) if not isinstance(v, str) else v
            elif hasattr(row, k) and k != "meta":
                setattr(row, k, v)
        db.commit()
    finally:
        db.close()


def fulfill_payment(payment_id: str, provider_ref: str | None = None, force: bool = False) -> bool:
    db = SessionLocal()
    try:
        row = db.query(PaymentRow).filter(PaymentRow.id == payment_id).first()
        if not row:
            logger.warning(f"Payment not found: {payment_id}")
            return False
        if row.status == "completed" and not force:
            return True
        if row.status == "failed" and not force:
            return False

        product = resolve_checkout_kind(row.kind)
        if product["type"] == "plan" and product.get("plan"):
            user_service.set_plan(row.user_id, product["plan"])
        else:
            user_service.add_credits(
                row.user_id,
                product["credits"],
                reason=f"crypto_{row.kind}",
                stripe_payment_id=provider_ref or payment_id,
            )

        row.status = "completed"
        row.completed_at = datetime.utcnow()
        if provider_ref:
            row.external_id = provider_ref
        db.commit()
        logger.info(f"Payment fulfilled {payment_id} user={row.user_id} kind={row.kind}")
        return True
    except Exception:
        db.rollback()
        logger.exception(f"fulfill_payment failed {payment_id}")
        return False
    finally:
        db.close()


def get_payment(payment_id: str) -> Optional[dict]:
    db = SessionLocal()
    try:
        row = db.query(PaymentRow).filter(PaymentRow.id == payment_id).first()
        if not row:
            return None
        return {
            "id": row.id,
            "status": row.status,
            "kind": row.kind,
            "provider": row.provider,
            "credits_grant": row.credits_grant,
            "plan_grant": row.plan_grant,
            "checkout_url": row.checkout_url,
            "amount_cents": row.amount_cents,
        }
    finally:
        db.close()


def handle_ipn(body: dict, signature: str | None = None) -> bool:
    secret = (getattr(settings, "NOWPAYMENTS_IPN_SECRET", None) or "").strip()
    if secret and signature:
        try:
            payload = json.dumps(body, separators=(",", ":"), sort_keys=True)
            calc = hmac.new(secret.encode(), payload.encode(), hashlib.sha512).hexdigest()
            if not hmac.compare_digest(calc, signature):
                logger.warning("Crypto IPN signature mismatch")
                return False
        except Exception as e:
            logger.warning(f"IPN sig check error: {e}")

    status = (body.get("payment_status") or body.get("status") or "").lower()
    order_id = body.get("order_id") or body.get("orderId")
    payment_id = order_id
    if not payment_id:
        ext = str(body.get("invoice_id") or body.get("payment_id") or "")
        db = SessionLocal()
        try:
            row = db.query(PaymentRow).filter(PaymentRow.external_id == ext).first()
            payment_id = row.id if row else None
        finally:
            db.close()
    if not payment_id:
        return False

    if status in ("finished", "confirmed", "complete", "completed", "paid"):
        return fulfill_payment(payment_id, provider_ref=str(body.get("payment_id") or body.get("id") or ""))
    if status in ("failed", "expired", "refunded"):
        _update_payment(payment_id, status=status)
        return False
    return False
