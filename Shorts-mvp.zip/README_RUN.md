# Shorts MVP — Run Guide

## Quick start

```bash
cd backend   # or repo root if this is the project root
cp .env.example .env
# set LLM_API_KEY for AI features
./run.sh
```

Open http://localhost:8000

`./run.sh` will:
- install Python deps
- upgrade **yt-dlp**
- install **Deno** (JS runtime yt-dlp needs for YouTube)
- create `samples/sample.mp4` for offline tests (if ffmpeg exists)

Jobs use FastAPI BackgroundTasks when Redis is empty.

## YouTube Viral on GitHub Codespaces

YouTube often **blocks Codespace / datacenter IPs** ("Sign in to confirm you're not a bot") even with valid cookies. That is IP reputation, not only cookies.

### What still works in Codespaces

| Feature | Codespace |
|---------|-----------|
| UI, auth, credits, Standard / Reddit / Fake text / Split | Yes |
| AI script / AI Visual (with API keys) | Yes |
| YouTube download | Often **no** without residential proxy |
| YouTube pipeline **logic** (clips, captions) | Yes via **mock** |

### Offline test (no real YouTube download)

1. Start once so `samples/sample.mp4` is created:
   ```bash
   ./run.sh
   ```
2. In `.env`:
   ```env
   YOUTUBE_MOCK_DOWNLOAD_PATH=/workspaces/YOUR_REPO/samples/sample.mp4
   ```
   (use your real path; `pwd` then append `/samples/sample.mp4`)
3. Restart `./run.sh`
4. In UI: **YouTube Viral** → paste any YouTube URL → Generate  
   The app uses the sample file instead of yt-dlp.

### Real YouTube download checklist

1. `./run.sh` (Deno + latest yt-dlp)
2. Fresh Netscape cookies (`YOUTUBE_COOKIES_FILE=...`)
3. If still bot-blocked from Codespace → use mock, or `YOUTUBE_PROXY=...` residential proxy, or run yt-dlp on a home PC and upload the file as mock

## Production-style (Redis + Celery)

```bash
# Redis
docker run -d -p 6379:6379 redis:7

export CELERY_BROKER_URL=redis://localhost:6379/0
export CELERY_RESULT_BACKEND=redis://localhost:6379/1
./run.sh          # terminal 1
./run-worker.sh   # terminal 2
```

## Tests

```bash
PYTHONPATH=. pytest tests/ -q
```
