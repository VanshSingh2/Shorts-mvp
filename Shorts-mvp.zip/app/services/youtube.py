"""Download YouTube (and other yt-dlp sources) for reel extraction."""
from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

ALLOWED_HOST_HINTS = (
    "youtube.com", "youtu.be", "www.youtube.com", "m.youtube.com",
    "youtube-nocookie.com",
)

YOUTUBE_URL_RE = re.compile(
    r"(https?://)?(www\.)?(youtube\.com|youtu\.be)/[\w\-?=&%.]+",
    re.I,
)


def is_youtube_url(url: str) -> bool:
    if not url or not url.strip():
        return False
    url = url.strip()
    if not YOUTUBE_URL_RE.search(url):
        try:
            host = urlparse(url if "://" in url else f"https://{url}").hostname or ""
            return any(h in host for h in ALLOWED_HOST_HINTS)
        except Exception:
            return False
    return True


def normalize_url(url: str) -> str:
    url = url.strip()
    if not url.startswith("http"):
        url = "https://" + url
    return url


def _yt_dlp_bin() -> str:
    return shutil.which("yt-dlp") or "yt-dlp"


def _cookie_args() -> List[str]:
    """Optional auth for bot-check / age-gated videos via env or settings."""
    args: List[str] = []
    cookies_file = os.environ.get("YOUTUBE_COOKIES_FILE", "").strip()
    cookies_browser = os.environ.get("YOUTUBE_COOKIES_FROM_BROWSER", "").strip()
    try:
        from app.core.config import settings
        cookies_file = cookies_file or getattr(settings, "YOUTUBE_COOKIES_FILE", "") or ""
        cookies_browser = cookies_browser or getattr(settings, "YOUTUBE_COOKIES_FROM_BROWSER", "") or ""
    except Exception:
        pass
    cookies_file = (cookies_file or "").strip()
    cookies_browser = (cookies_browser or "").strip()
    if cookies_file and Path(cookies_file).is_file():
        args.extend(["--cookies", cookies_file])
        logger.info(f"yt-dlp using cookies file: {cookies_file}")
    elif cookies_browser:
        args.extend(["--cookies-from-browser", cookies_browser])
        logger.info(f"yt-dlp using cookies from browser: {cookies_browser}")
    return args


def _format_candidates(max_height: int) -> List[str]:
    """Progressively looser format selectors — android/ios often lack mp4+m4a pairs."""
    h = int(max_height or 1080)
    return [
        # Prefer progressive/mp4 when available
        f"bv*[height<={h}][ext=mp4]+ba[ext=m4a]/b[height<={h}][ext=mp4]/bv*[height<={h}]+ba/b",
        # Any container under height cap
        f"bv*[height<={h}]+ba/b[height<={h}]/bv*+ba/b",
        # Best video+audio, then single-file best (most compatible)
        "bv*+ba/b",
        "best",
        # Absolute last resort
        "worst",
    ]


def download_video(
    url: str,
    out_dir: Path,
    *,
    max_height: int = 1080,
    max_duration_sec: int = 1200,
) -> Path:
    """
    Download best video+audio under max_height.
    Retries across player clients and format selectors.
    """
    out_dir.mkdir(parents=True, exist_ok=True)

    mock = os.environ.get("YOUTUBE_MOCK_DOWNLOAD_PATH", "").strip()
    try:
        from app.core.config import settings
        mock = mock or getattr(settings, "YOUTUBE_MOCK_DOWNLOAD_PATH", "") or ""
    except Exception:
        pass
    mock = (mock or "").strip()
    if mock and Path(mock).is_file():
        dest = out_dir / f"source{Path(mock).suffix or '.mp4'}"
        shutil.copy2(mock, dest)
        logger.info(f"yt-dlp mock: copied {mock} → {dest}")
        return dest

    from app.services.security import assert_safe_external_url

    if not is_youtube_url(url):
        raise ValueError("Only YouTube links are supported in this version")
    url = assert_safe_external_url(
        url,
        allow_hosts=(
            "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be",
            "youtube-nocookie.com", "www.youtube-nocookie.com",
        ),
    )
    out_tmpl = str(out_dir / "source.%(ext)s")
    cookie_args = _cookie_args()
    bin_path = _yt_dlp_bin()
    formats = _format_candidates(max_height)

    # (player_client, use_duration_filter)
    client_attempts: List[Tuple[Optional[str], bool]] = [
        (None, True),
        ("android,web", True),
        ("ios,android", False),
        ("mweb,android", False),
        ("tv", False),
        (None, False),  # default again, no duration filter, with looser formats
    ]

    last_err = ""
    for clients, use_dur in client_attempts:
        for fmt in formats:
            cmd = [
                bin_path,
                "--no-playlist",
                "--no-warnings",
                "-f", fmt,
                "--merge-output-format", "mp4",
                "--max-filesize", "500M",
                "-o", out_tmpl,
                "--print", "after_move:filepath",
                "--retries", "3",
                "--fragment-retries", "3",
                # Prefer higher res when multiple match
                "-S", f"res:{max_height},codec:h264:vp9:av01,ext:mp4:webm",
            ]
            if use_dur and max_duration_sec and max_duration_sec > 0:
                cmd.extend(["--match-filter", f"duration <= {int(max_duration_sec)}"])
            cmd.extend(cookie_args)
            if clients:
                cmd.extend(["--extractor-args", f"youtube:player_client={clients}"])
            cmd.append(url)

            logger.info(
                f"yt-dlp download: {url} clients={clients or 'default'} fmt={fmt[:48]}"
            )
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
            except subprocess.TimeoutExpired:
                last_err = "Download timed out"
                continue

            if result.returncode == 0:
                printed = (result.stdout or "").strip().splitlines()
                if printed:
                    candidate = Path(printed[-1].strip())
                    if candidate.exists() and candidate.stat().st_size > 0:
                        return candidate
                files = sorted(
                    out_dir.glob("source.*"),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True,
                )
                files = [
                    f for f in files
                    if f.suffix.lower() in {".mp4", ".mkv", ".webm", ".mov"}
                    and f.stat().st_size > 0
                ]
                if files:
                    return files[0]
                last_err = "Download finished but no video file found"
                continue

            err = (result.stderr or result.stdout or "")[-1200:]
            last_err = err
            logger.warning(
                f"yt-dlp attempt failed (clients={clients or 'default'}): {err[-350:]}"
            )

            # Fatal — no point trying more formats/clients
            if "Private video" in err or "Video unavailable" in err:
                break
            if "Sign in to confirm" in err or "not a bot" in err:
                # need different auth; still try other clients once
                break
            # "Requested format is not available" → try next format
            if "format is not available" in err.lower():
                continue
            # "The page needs to be reloaded" → next client
            if "reloaded" in err.lower():
                break

    hint = ""
    if "Sign in to confirm" in last_err or "not a bot" in last_err:
        hint = (
            " YouTube blocked this IP (bot check). "
            "Set YOUTUBE_COOKIES_FILE=/path/to/cookies.txt in .env "
            "or YOUTUBE_COOKIES_FROM_BROWSER=chrome."
        )
    elif "format is not available" in last_err.lower():
        hint = (
            " No matching stream for this client. Update yt-dlp "
            "(`pip install -U yt-dlp`) and re-export fresh cookies."
        )
    logger.error(f"yt-dlp failed: {last_err[-500:]}{hint}")
    raise RuntimeError(f"YouTube download failed: {(last_err[:250] + hint)[:500]}")


def probe_duration(path: Path) -> float:
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True, text=True,
    )
    try:
        return float(r.stdout.strip())
    except Exception:
        return 0.0
