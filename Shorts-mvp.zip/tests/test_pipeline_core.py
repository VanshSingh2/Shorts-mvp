"""Pipeline helpers, job lifecycle, templates validation."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.models.schemas import (
    CreateJobRequest, JobStatus, TemplateType, CaptionStyle, VoiceOption,
    YoutubeReelsRequest, RedditStoryRequest, FakeTextRequest, FakeTextMessage,
)
from app.services.pipeline import (
    create_job, get_job, list_jobs, cancel_job, _discover_extra_outputs, _resolve_bg,
)


def test_create_job_standard():
    job = create_job(CreateJobRequest(script="Hello world this is a test script for shorts."), user_id=None)
    assert job.id
    assert job.status == JobStatus.PENDING
    assert get_job(job.id) is not None


def test_create_job_youtube():
    job = create_job(
        CreateJobRequest(
            template=TemplateType.YOUTUBE_REELS,
            youtube=YoutubeReelsRequest(url="https://www.youtube.com/watch?v=dQw4w9WgXcQ", max_clips=3),
        )
    )
    assert job.template in ("youtube_reels", TemplateType.YOUTUBE_REELS)


def test_cancel_pending_job():
    job = create_job(CreateJobRequest(script="Cancel me please with enough text here."))
    cancelled = cancel_job(job.id)
    assert str(getattr(cancelled.status, 'value', cancelled.status)) == JobStatus.CANCELLED.value


def test_cancel_unknown_job():
    with pytest.raises(ValueError):
        cancel_job("does-not-exist-id-xyz")


def test_list_jobs_empty_user():
    jobs = list_jobs(limit=5, user_id="nobody-user-id")
    assert isinstance(jobs, list)


def test_resolve_bg_blocks_traversal(tmp_path, monkeypatch):
    from app.core import config as cfg
    monkeypatch.setattr(cfg.settings, "BACKGROUND_DIR", tmp_path)
    assert _resolve_bg("../etc/passwd") is None
    assert _resolve_bg("..") is None
    assert _resolve_bg(None) is None


def test_discover_extra_outputs_empty():
    assert _discover_extra_outputs("no-such-job-id-ever") is None


def test_reddit_schema():
    r = RedditStoryRequest(title="AITA for testing?", body="Long body text here for validation.")
    assert r.title.startswith("AITA")


def test_fake_text_schema():
    f = FakeTextRequest(messages=[FakeTextMessage(sender="me", text="hey"), FakeTextMessage(sender="them", text="hi")])
    assert len(f.messages) == 2
