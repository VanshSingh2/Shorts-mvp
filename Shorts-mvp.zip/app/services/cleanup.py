"""Data retention: delete old job outputs and expired tokens."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from pathlib import Path

from app.core.config import settings
from app.db.database import JobRow, SessionLocal
from app.services.users import cleanup_expired_tokens, update_storage

logger = logging.getLogger(__name__)


def cleanup_old_outputs(retention_days: int | None = None, user_id: str | None = None) -> dict:
    """
    Delete job output files older than retention_days.
    Updates user storage counters. Returns stats.
    """
    days = retention_days if retention_days is not None else settings.JOB_RETENTION_DAYS
    cutoff = datetime.utcnow() - timedelta(days=days)
    deleted_files = 0
    deleted_bytes = 0
    db = SessionLocal()
    try:
        q = db.query(JobRow).filter(JobRow.created_at < cutoff)
        if user_id:
            q = q.filter(JobRow.user_id == user_id)
        rows = q.all()
        for row in rows:
            path = None
            if row.output_path:
                path = Path(row.output_path)
            elif row.output_url and row.output_url.startswith("/api/outputs/"):
                path = settings.OUTPUT_DIR / Path(row.output_url).name
            if path and path.exists() and path.is_file():
                size = path.stat().st_size
                try:
                    path.unlink()
                    deleted_files += 1
                    deleted_bytes += size
                    if row.user_id:
                        update_storage(row.user_id, -size)
                except OSError as e:
                    logger.warning(f"Failed to delete {path}: {e}")
            # Keep the DB row but clear paths so UI shows expired
            row.output_path = None
            row.output_url = None
            row.output_bytes = 0
            row.message = (row.message or "") + " [output expired]"
        db.commit()
    finally:
        db.close()

    tokens = 0
    try:
        tokens = cleanup_expired_tokens()
    except Exception as e:
        logger.warning(f"Token cleanup: {e}")

    # Also purge orphan files in OUTPUT_DIR older than retention
    orphan_deleted = 0
    try:
        for p in settings.OUTPUT_DIR.glob("*"):
            if not p.is_file():
                continue
            age = datetime.utcnow() - datetime.utcfromtimestamp(p.stat().st_mtime)
            if age > timedelta(days=days):
                try:
                    p.unlink()
                    orphan_deleted += 1
                except OSError:
                    pass
    except Exception as e:
        logger.warning(f"Orphan cleanup: {e}")

    stats = {
        "deleted_files": deleted_files,
        "deleted_bytes": deleted_bytes,
        "orphan_files": orphan_deleted,
        "expired_tokens": tokens,
        "retention_days": days,
    }
    logger.info(f"Cleanup done: {stats}")
    return stats
