"""Transcription service using faster-whisper (word-level timestamps when available)."""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from typing import Any, List, Optional

from app.core.config import settings
from app.models.schemas import TranscriptSegment

logger = logging.getLogger(__name__)

_model: Any = None
_model_lock = threading.Lock()
_model_load_failed: Optional[str] = None


def get_whisper_model():
    """Process-wide singleton. ctranslate2 cannot load its native module twice."""
    global _model, _model_load_failed
    if _model is not None:
        return _model
    if _model_load_failed:
        raise RuntimeError(_model_load_failed)

    with _model_lock:
        if _model is not None:
            return _model
        if _model_load_failed:
            raise RuntimeError(_model_load_failed)
        try:
            # Limit BLAS/OMP contention which sometimes triggers native reload issues
            os.environ.setdefault("OMP_NUM_THREADS", "1")
            os.environ.setdefault("CT2_USE_EXPERIMENTAL_PACKED_GEMM", "0")

            from faster_whisper import WhisperModel

            logger.info(f"Loading Whisper model: {settings.WHISPER_MODEL}")
            _model = WhisperModel(
                settings.WHISPER_MODEL,
                device=getattr(settings, "WHISPER_DEVICE", "cpu"),
                compute_type=getattr(settings, "WHISPER_COMPUTE", "int8"),
            )
            logger.info("Whisper model loaded")
            return _model
        except Exception as e:
            msg = str(e)
            _model_load_failed = msg
            logger.exception("Whisper model load failed")
            raise


def _segments_from_raw(raw: list) -> List[TranscriptSegment]:
    result: List[TranscriptSegment] = []
    for seg in raw:
        text = (seg.get("text") or "").strip()
        if not text:
            continue
        words = seg.get("words")
        result.append(
            TranscriptSegment(
                start=round(float(seg.get("start", 0)), 3),
                end=round(float(seg.get("end", 0)), 3),
                text=text,
                words=words,
            )
        )
    return result


def _transcribe_inprocess(audio_path: Path, word_timestamps: bool) -> List[TranscriptSegment]:
    model = get_whisper_model()
    logger.info(f"Transcribing (in-process): {audio_path} (words={word_timestamps})")
    segments, info = model.transcribe(
        str(audio_path),
        beam_size=5,
        word_timestamps=word_timestamps,
        vad_filter=True,
    )
    result: List[TranscriptSegment] = []
    for seg in segments:
        text = seg.text.strip()
        if not text:
            continue
        words = None
        if word_timestamps and getattr(seg, "words", None):
            words = [
                {
                    "word": (w.word or "").strip(),
                    "start": round(float(w.start), 3),
                    "end": round(float(w.end), 3),
                }
                for w in seg.words
                if (w.word or "").strip()
            ]
        result.append(
            TranscriptSegment(
                start=round(seg.start, 3),
                end=round(seg.end, 3),
                text=text,
                words=words,
            )
        )
    lang = getattr(info, "language", "?")
    logger.info(f"Transcription complete: {len(result)} segments, language={lang}")
    return result


def _transcribe_subprocess(audio_path: Path, word_timestamps: bool) -> List[TranscriptSegment]:
    """
    Isolate faster-whisper in a fresh Python process.
    Avoids ctranslate2 'cannot load module more than once per process' when the
    parent already loaded the native extension (uvicorn reload / prior failure).
    """
    script = r'''
import json, os, sys
os.environ.setdefault("OMP_NUM_THREADS", "1")
from faster_whisper import WhisperModel
audio, model_name, device, compute, words_flag = sys.argv[1:6]
model = WhisperModel(model_name, device=device, compute_type=compute)
segments, info = model.transcribe(audio, beam_size=5, word_timestamps=(words_flag=="1"), vad_filter=True)
out = []
for seg in segments:
    text = (seg.text or "").strip()
    if not text:
        continue
    item = {"start": float(seg.start), "end": float(seg.end), "text": text, "words": None}
    if words_flag == "1" and getattr(seg, "words", None):
        item["words"] = [
            {"word": (w.word or "").strip(), "start": float(w.start), "end": float(w.end)}
            for w in seg.words if (w.word or "").strip()
        ]
    out.append(item)
print(json.dumps({"language": getattr(info, "language", None), "segments": out}))
'''
    device = getattr(settings, "WHISPER_DEVICE", "cpu")
    compute = getattr(settings, "WHISPER_COMPUTE", "int8")
    model_name = settings.WHISPER_MODEL
    logger.info(f"Transcribing (subprocess): {audio_path}")
    try:
        proc = subprocess.run(
            [
                sys.executable, "-c", script,
                str(audio_path),
                str(model_name),
                str(device),
                str(compute),
                "1" if word_timestamps else "0",
            ],
            capture_output=True,
            text=True,
            timeout=int(getattr(settings, "JOB_TIMEOUT_SECONDS", 600) or 600),
            env={**os.environ, "OMP_NUM_THREADS": "1"},
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("Transcription subprocess timed out")

    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout or "")[-800:]
        raise RuntimeError(f"Transcription subprocess failed: {err}")

    # Last line should be JSON (faster-whisper may log to stderr)
    lines = [ln for ln in (proc.stdout or "").splitlines() if ln.strip().startswith("{")]
    if not lines:
        raise RuntimeError(f"Transcription subprocess returned no JSON: {(proc.stdout or '')[:300]}")
    data = json.loads(lines[-1])
    result = _segments_from_raw(data.get("segments") or [])
    logger.info(
        f"Transcription complete (subprocess): {len(result)} segments, language={data.get('language')}"
    )
    return result


def transcribe_audio(audio_path: Path, word_timestamps: bool = True) -> List[TranscriptSegment]:
    """
    Transcribe an audio/video file and return timed segments.
    Tries in-process faster-whisper first; on native-module errors, falls back to subprocess.
    """
    audio_path = Path(audio_path)
    if not audio_path.is_file():
        raise FileNotFoundError(f"Audio not found: {audio_path}")

    try:
        return _transcribe_inprocess(audio_path, word_timestamps)
    except Exception as e:
        msg = str(e).lower()
        if "cannot load module more than once" in msg or "ctranslate" in msg or _model_load_failed:
            logger.warning(f"In-process Whisper failed ({e}); trying subprocess isolation")
            return _transcribe_subprocess(audio_path, word_timestamps)
        raise


def segments_to_srt(segments: List[TranscriptSegment]) -> str:
    def _ts(seconds: float) -> str:
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        ms = int(round((seconds - int(seconds)) * 1000))
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    lines = []
    for i, seg in enumerate(segments, 1):
        lines.append(str(i))
        lines.append(f"{_ts(seg.start)} --> {_ts(seg.end)}")
        lines.append(seg.text)
        lines.append("")
    return "\n".join(lines)


def segments_to_ass(
    segments: List[TranscriptSegment],
    style_name: str = "classic",
) -> str:
    """Basic ASS with optional word-level karaoke (\k tags) when words exist."""
    header = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,64,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,4,0,2,40,40,160,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

    def _ass_ts(seconds: float) -> str:
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        cs = int(round((seconds - int(seconds)) * 100))
        return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

    events = []
    for seg in segments:
        start, end = seg.start, seg.end
        words = getattr(seg, "words", None) or []
        if words:
            parts = []
            for w in words:
                dur_cs = max(1, int(round((float(w["end"]) - float(w["start"])) * 100)))
                token = (w.get("word") or "").replace("{", "").replace("}", "")
                parts.append(rf"{{\k{dur_cs}}}{token}")
            text = "".join(parts)
        else:
            text = (seg.text or "").replace("{", "").replace("}", "")
        events.append(
            f"Dialogue: 0,{_ass_ts(start)},{_ass_ts(end)},Default,,0,0,0,,{text}"
        )
    return header + "\n".join(events) + "\n"


def parse_srt_text(srt: str) -> List[TranscriptSegment]:
    """Parse a simple SRT string into segments."""
    import re

    blocks = re.split(r"\n\s*\n", srt.strip())
    out: List[TranscriptSegment] = []
    ts_re = re.compile(
        r"(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})"
    )

    def to_sec(h, m, s, ms):
        return int(h) * 3600 + int(m) * 60 + int(s) + int(ms.ljust(3, "0")[:3]) / 1000.0

    for block in blocks:
        lines = [ln for ln in block.splitlines() if ln.strip()]
        if len(lines) < 2:
            continue
        m = None
        text_lines = []
        for ln in lines:
            if ts_re.search(ln):
                m = ts_re.search(ln)
            elif not ln.strip().isdigit():
                text_lines.append(ln.strip())
        if not m or not text_lines:
            continue
        out.append(
            TranscriptSegment(
                start=to_sec(*m.groups()[:4]),
                end=to_sec(*m.groups()[4:]),
                text=" ".join(text_lines),
            )
        )
    return out


# Back-compat alias used by some pipeline paths
segments_to_ass_karaoke = segments_to_ass
