"""Frontend static integrity & wiring smoke tests."""
from pathlib import Path
import re

STATIC = Path(__file__).resolve().parent.parent / "static"


def test_index_exists_and_has_brand():
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    assert "Clipforge" in html
    assert "view-landing" in html
    assert "view-app" in html
    assert "tool-picker" in html
    assert "job-form" in html
    assert "auth-modal" in html
    assert 'src="/app.js"' in html or "src='/app.js'" in html
    # unique palette markers (coral/ember, not generic purple-only)
    assert "ff5c33" in html or "ember" in html
    assert "Outfit" in html or "DM Sans" in html


def test_app_js_wiring():
    js = (STATIC / "app.js").read_text(encoding="utf-8")
    # Core API endpoints used by UI
    for endpoint in [
        "/api/auth/login",
        "/api/auth/register",
        "/api/auth/me",
        "/api/auth/logout",
        "/api/jobs",
        "/api/generate-script",
        "/api/billing/plans",
        "/api/billing/checkout",
        "/api/backgrounds",
    ]:
        assert endpoint in js, f"Missing API wiring: {endpoint}"
    # Key functions
    for fn in [
        "navigate(",
        "setTemplate(",
        "setMode(",
        "submitAuth(",
        "loadJobs(",
        "pollJob(",
        "showStatus(",
        "cancelCurrentJob(",
        "tweakStyle(",
        "generateAIScript(",
        "buy(",
    ]:
        assert fn in js, f"Missing function: {fn}"
    # Templates covered
    for t in ["standard", "ai_visual", "youtube_reels", "reddit_story", "fake_text", "split_screen"]:
        assert t in js


def test_panels_present_in_html():
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    for pid in [
        "panel-standard",
        "panel-ai_visual",
        "panel-youtube",
        "panel-reddit",
        "panel-fake",
        "panel-split",
        "status-card",
        "page-library",
        "page-billing",
        "page-account",
    ]:
        assert f'id="{pid}"' in html, f"Missing panel {pid}"


def test_tool_picker_has_six_tools():
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    tools = re.findall(r'data-tmpl="([^"]+)"', html)
    assert len(tools) >= 6
    for t in ["standard", "ai_visual", "youtube_reels", "reddit_story", "fake_text", "split_screen"]:
        assert t in tools


def test_legal_pages_branded():
    for name in ["privacy.html", "terms.html", "content-policy.html"]:
        text = (STATIC / name).read_text(encoding="utf-8")
        assert "Clipforge" in text
        assert "06070b" in text or "void" in text.lower()


def test_no_generic_purple_as_sole_accent():
    """Ensure redesign moved off generic purple-only SaaS look."""
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    # New accent present
    assert "#ff5c33" in html or "ember" in html
    # Old purple may still appear in comments/history but primary CSS should use ember
    assert "from-ember" in html or "bg-ember" in html or "#ff5c33" in html


def test_nav_pages_wired():
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    for page in ["create", "library", "billing", "account"]:
        assert f'data-page="{page}"' in html
        assert f'id="page-{page}"' in html


def test_form_fields_for_templates():
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    fields = [
        "topic", "script", "file", "voice", "style", "background",
        "ai_visual_topic", "ai_max_scenes", "youtube_url",
        "reddit_title", "reddit_body", "fake_messages", "split_script",
    ]
    for f in fields:
        assert f'id="{f}"' in html, f"Missing field {f}"
