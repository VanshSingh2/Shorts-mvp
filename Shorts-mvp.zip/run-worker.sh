#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH=.
mkdir -p uploads outputs backgrounds temp data assets
if [[ ! -f .env && -f .env.example ]]; then
  cp .env.example .env
fi
CONCURRENCY="${CELERY_CONCURRENCY:-2}"
echo "Starting Celery worker (concurrency=$CONCURRENCY) broker=${CELERY_BROKER_URL:-redis://localhost:6379/0}"
exec celery -A app.workers.celery_app.celery_app worker -l info --concurrency="$CONCURRENCY"
