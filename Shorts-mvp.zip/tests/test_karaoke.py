"""ASS karaoke generation unit tests."""
from app.models.schemas import TranscriptSegment
from app.services.transcription import segments_to_ass_karaoke, segments_to_srt


def test_ass_with_words():
    segs = [
        TranscriptSegment(
            start=0.0,
            end=1.5,
            text="Hello world",
            words=[
                {"word": "Hello", "start": 0.0, "end": 0.6},
                {"word": "world", "start": 0.6, "end": 1.5},
            ],
        )
    ]
    ass = segments_to_ass_karaoke(segs, style_name="karaoke")
    assert "[Script Info]" in ass
    assert r"\k" in ass
    assert "Hello" in ass
    assert "Dialogue:" in ass


def test_ass_fallback_no_words():
    segs = [TranscriptSegment(start=0.0, end=1.0, text="Plain line", words=None)]
    ass = segments_to_ass_karaoke(segs)
    assert "Plain line" in ass
    assert "Dialogue:" in ass


def test_srt_basic():
    segs = [TranscriptSegment(start=0.0, end=1.0, text="Hi", words=None)]
    srt = segments_to_srt(segs)
    assert "00:00:00,000 --> 00:00:01,000" in srt
    assert "Hi" in srt
