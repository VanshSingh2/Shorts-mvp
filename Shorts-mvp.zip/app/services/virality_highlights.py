"""
LLM-powered virality-aware highlight detection (inspired by
https://github.com/Anil-matcha/AI-Youtube-Shorts-Generator).

Ranks transcript segments for hooks, emotional peaks, opinion bombs,
revelations, conflict, quotable lines, story peaks, and practical value.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple

import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)

VIRALITY_CRITERIA = """
Score each candidate clip 0–100 using these signals (higher = more viral):
1. Hook strength – opens with curiosity, surprise, or a bold claim
2. Emotional peak – strong feeling (anger, joy, shock, inspiration)
3. Opinion bomb / hot take – clear, quotable stance
4. Revelation / payoff – key insight, twist, or "aha" moment
5. Conflict / tension – disagreement, stakes, drama
6. Quotable line – short phrase people would clip / share
7. Story peak – climax or turning point of a narrative
8. Practical value – actionable tip, number, or framework
Prefer 20–45 second clips that stand alone without needing the full context.
"""

HIGHLIGHT_SYSTEM_PROMPT = f"""You are an expert short-form video editor who finds the most viral-ready moments in long-form content.

{VIRALITY_CRITERIA}

Given a timestamped transcript, return a JSON array of the top candidate highlights.
Each object must have:
- start: number (seconds)
- end: number (seconds)
- score: integer 0-100
- title: short catchy title (max 80 chars)
- hook_sentence: the opening line or best hook from the clip
- virality_reason: one sentence explaining why this clip will perform

Return ONLY valid JSON array, no markdown fences, no commentary.
Aim for clips between the requested min/max duration. Prefer non-overlapping moments.
"""


@dataclass
class Highlight:
    start: float
    end: float
    score: int = 50
    title: str = ""
    hook_sentence: str = ""
    virality_reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _segments_to_transcript_text(segments: List[Any], max_chars: int = 28000) -> str:
    """Format segments as ' [12.3-18.7] text ' lines for the LLM."""
    lines = []
    total = 0
    for seg in segments:
        start = getattr(seg, "start", None)
        end = getattr(seg, "end", None)
        text = (getattr(seg, "text", None) or "").strip()
        if start is None or end is None or not text:
            continue
        line = f"[{start:.1f}-{end:.1f}] {text}"
        if total + len(line) > max_chars:
            break
        lines.append(line)
        total += len(line) + 1
    return "\n".join(lines)


async def rank_highlights_with_llm(
    segments: List[Any],
    *,
    max_clips: int = 5,
    min_clip_sec: float = 12.0,
    max_clip_sec: float = 45.0,
) -> List[Highlight]:
    """
    Use the configured LLM (OpenAI-compatible) to rank viral highlights.
    Falls back to empty list on failure so caller can use energy-based detection.
    """
    transcript = _segments_to_transcript_text(segments)
    if not transcript or len(transcript) < 80:
        logger.warning("Transcript too short for LLM highlight ranking")
        return []

    api_key = getattr(settings, "LLM_API_KEY", "") or ""
    base_url = (getattr(settings, "LLM_BASE_URL", None) or "https://api.openai.com/v1").rstrip("/")
    model = getattr(settings, "LLM_MODEL", None) or "gpt-4o-mini"

    if not api_key or api_key.startswith("sk-placeholder") or "your-" in api_key.lower():
        logger.info("No real LLM key configured – skipping virality ranking")
        return []

    user_msg = (
        f"Select the top {max_clips} viral highlights.\n"
        f"Preferred clip length: {min_clip_sec:.0f}–{max_clip_sec:.0f} seconds.\n\n"
        f"TRANSCRIPT:\n{transcript}"
    )

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": HIGHLIGHT_SYSTEM_PROMPT},
            {"role": "user", "content": user_msg},
        ],
        "temperature": 0.3,
        "max_tokens": 2000,
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=90.0) as client:
            resp = await client.post(f"{base_url}/chat/completions", json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.warning(f"LLM highlight ranking failed: {e}")
        return []

    # Strip markdown fences if present
    content = re.sub(r"^```(?:json)?\s*", "", content)
    content = re.sub(r"\s*```$", "", content)

    try:
        raw = json.loads(content)
        if not isinstance(raw, list):
            raw = raw.get("highlights") or raw.get("clips") or []
    except json.JSONDecodeError:
        # Try to extract array
        m = re.search(r"\[[\s\S]*\]", content)
        if not m:
            logger.warning("Could not parse LLM highlight JSON")
            return []
        try:
            raw = json.loads(m.group(0))
        except json.JSONDecodeError:
            return []

    highlights: List[Highlight] = []
    for item in raw:
        try:
            start = float(item.get("start", 0))
            end = float(item.get("end", start + min_clip_sec))
            if end - start < min_clip_sec * 0.6:
                end = start + min_clip_sec
            if end - start > max_clip_sec * 1.3:
                end = start + max_clip_sec
            highlights.append(
                Highlight(
                    start=round(start, 2),
                    end=round(end, 2),
                    score=int(item.get("score", 50)),
                    title=str(item.get("title") or "")[:100],
                    hook_sentence=str(item.get("hook_sentence") or item.get("hook") or "")[:200],
                    virality_reason=str(item.get("virality_reason") or item.get("reason") or "")[:300],
                )
            )
        except (TypeError, ValueError):
            continue

    # Sort by score desc, dedupe heavy overlaps
    highlights.sort(key=lambda h: h.score, reverse=True)
    kept: List[Highlight] = []
    for h in highlights:
        if any(_overlap(h.start, h.end, k.start, k.end) > 0.5 * min(h.end - h.start, k.end - k.start) for k in kept):
            continue
        kept.append(h)
        if len(kept) >= max_clips:
            break

    logger.info(f"LLM ranked {len(kept)} viral highlights (from {len(highlights)} candidates)")
    return kept


def _overlap(a1: float, a2: float, b1: float, b2: float) -> float:
    return max(0.0, min(a2, b2) - max(a1, b1))


def highlights_to_intervals(highlights: List[Highlight]) -> List[Tuple[float, float]]:
    return [(h.start, h.end) for h in highlights]
