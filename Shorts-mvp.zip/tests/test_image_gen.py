"""Tests for image_gen fallbacks and scene planning (no live API required)."""
from pathlib import Path

import pytest

from app.services.image_gen import (
    _fallback_prompts,
    _gradient_poster,
    image_gen_available,
    plan_scene_prompts,
    generate_image,
)


def test_fallback_prompts_basic():
    prompts = _fallback_prompts("Why cold showers help focus and energy")
    assert len(prompts) >= 2
    assert all(isinstance(p, str) and len(p) > 10 for p in prompts)


def test_gradient_poster(tmp_path):
    out = tmp_path / "poster.png"
    _gradient_poster("focus habits cinematic", out)
    assert out.exists()
    assert out.stat().st_size > 1000


@pytest.mark.asyncio
async def test_generate_image_fallback(tmp_path, monkeypatch):
    # Force no API key path
    from app.core import config
    monkeypatch.setattr(config.settings, "LLM_API_KEY", "")
    out = tmp_path / "scene.png"
    path = await generate_image("abstract blue gradient vertical", out)
    assert path.exists()
    assert path.stat().st_size > 500


@pytest.mark.asyncio
async def test_plan_scene_prompts_local(monkeypatch):
    from app.core import config
    monkeypatch.setattr(config.settings, "LLM_API_KEY", "")
    prompts = await plan_scene_prompts(
        "Here is something most people get wrong about sleep. "
        "First, protect a consistent bedtime. Second, dim lights early. "
        "Third, avoid late caffeine. Try it for one week.",
        max_scenes=3,
    )
    assert 1 <= len(prompts) <= 3


def test_image_gen_available_false_without_key(monkeypatch):
    from app.core import config
    monkeypatch.setattr(config.settings, "LLM_API_KEY", "")
    assert image_gen_available() is False
