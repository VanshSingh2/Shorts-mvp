"""Full wiring + use-case smoke tests (no live FFmpeg/Whisper required)."""
from __future__ import annotations

import re
from pathlib import Path

import pytest


# ---------- Health / queue ----------

def test_health_reports_queue(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    d = r.json()
    assert d["status"] == "ok"
    assert "redis_available" in d
    assert d["queue_backend"] in ("celery", "background")
    assert "standard" in d["available_templates"]
    assert "ai_visual" in d["available_templates"]
    assert "youtube_reels" in d["available_templates"]


def test_redis_available_callable():
    from app.services.queue import redis_available
    # Must not raise even if Redis is down
    assert isinstance(redis_available(), bool)


def test_enqueue_fallback_without_redis(client, auth_headers, monkeypatch):
    from app.services import queue as q

    monkeypatch.setattr(q, "redis_available", lambda: False)
    r = client.post(
        "/api/jobs",
        headers=auth_headers,
        data={
            "template": "standard",
            "script": "Hello world this is a short test script for integration.",
            "voice": "en-US-JennyNeural",
            "caption_style": "classic",
        },
    )
    # May succeed or 402 if no credits - either way wiring works
    assert r.status_code in (200, 201, 402, 429), r.text
    if r.status_code in (200, 201):
        body = r.json()
        assert "id" in body
        assert body["status"] in ("pending", "processing", "completed", "failed")


# ---------- Auth multi-session ----------

def test_register_login_me_logout(client):
    email = "int_user@example.com"
    password = "Testpass1"
    reg = client.post("/api/auth/register", json={"email": email, "password": password, "name": "Int"})
    assert reg.status_code in (200, 400)  # 400 if already exists
    login = client.post("/api/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200, login.text
    token = login.json()["token"]
    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200
    assert me.json()["email"] == email
    out = client.post("/api/auth/logout", headers={"Authorization": f"Bearer {token}"})
    assert out.status_code == 200


# ---------- Billing plans + providers ----------

def test_billing_plans_shape(client):
    r = client.get("/api/billing/plans")
    assert r.status_code == 200
    d = r.json()
    assert "plans" in d and len(d["plans"]) >= 3
    ids = {p["id"] for p in d["plans"]}
    assert "free" in ids and "pro" in ids and "studio" in ids
    assert "packs" in d
    assert "stripe_configured" in d
    assert "crypto_configured" in d


def test_checkout_both_providers(client, auth_headers):
    for provider in ("stripe", "crypto"):
        r = client.post(
            "/api/billing/checkout",
            headers={**auth_headers, "Content-Type": "application/json"},
            json={"kind": "pack_50", "provider": provider},
        )
        assert r.status_code == 200, f"{provider}: {r.text}"
        assert "checkout_url" in r.json()
        assert "session_id" in r.json()


# ---------- Template form acceptance ----------

@pytest.mark.parametrize(
    "data",
    [
        {"template": "standard", "script": "A short spoken script about focus and habits."},
        {
            "template": "reddit_story",
            "reddit_title": "AITA for testing?",
            "reddit_body": "Long body text for the reddit style short video generation path.",
            "reddit_subreddit": "r/AmItheAsshole",
        },
        {
            "template": "fake_text",
            "fake_text_json": '[{"sender":"them","text":"hey","is_me":false},{"sender":"me","text":"hi","is_me":true}]',
            "fake_contact": "Alex",
            "fake_platform": "imessage",
        },
        {
            "template": "split_screen",
            "script": "Top reaction bottom content narration for split template.",
            "split_label": "Streamer",
        },
        {
            "template": "ai_visual",
            "script": "Scene one about mountains. Scene two about the ocean.",
            "ai_topic": "Nature calm",
            "ai_max_scenes": "3",
            "ai_image_style": "cinematic",
        },
        {
            "template": "youtube_reels",
            "youtube_url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            "youtube_max_clips": "2",
        },
    ],
)
def test_template_job_accepts(client, auth_headers, data):
    # Top up credits via simulated pack
    client.post(
        "/api/billing/checkout",
        headers={**auth_headers, "Content-Type": "application/json"},
        json={"kind": "pack_50", "provider": "stripe"},
    )
    payload = {
        "voice": "en-US-JennyNeural",
        "caption_style": "classic",
        **data,
    }
    r = client.post("/api/jobs", headers=auth_headers, data=payload)
    # Accept created, or validation/quota/ssrf style errors that prove endpoint is wired
    assert r.status_code in (200, 201, 400, 402, 422, 429), f"{data.get('template')}: {r.status_code} {r.text}"


# ---------- Backgrounds / legal / static UI ----------

def test_backgrounds_list(client):
    r = client.get("/api/backgrounds")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_legal_pages(client):
    for path in ("/terms", "/privacy", "/content-policy"):
        r = client.get(path)
        assert r.status_code == 200, path


def test_ui_index_and_app_js(client):
    r = client.get("/")
    assert r.status_code == 200
    html = r.text
    assert "Shorts Studio" in html or "shorts" in html.lower()
    assert "/static/app.js" in html or "script" in html.lower()
    # app.js
    js = client.get("/static/app.js")
    assert js.status_code == 200
    body = js.text
    assert "setTemplate" in body
    assert "generateAIScript" in body
    assert "ai_visual" in body
    assert "youtube_reels" in body
    assert "/api/jobs" in body
    assert "provider" in body  # billing provider
    assert "authHeaders" in body


def test_ui_covers_all_templates():
    html = Path("static/index.html").read_text(encoding="utf-8")
    js = Path("static/app.js").read_text(encoding="utf-8")
    for t in ("standard", "ai_visual", "reddit_story", "fake_text", "split_screen", "youtube_reels"):
        assert t in html or t in js, f"missing template {t}"
    for api in ("/api/auth/login", "/api/generate-script", "/api/billing/checkout", "/api/jobs"):
        assert api in js, f"missing API {api}"


# ---------- Dashboard / usage ----------

def test_dashboard(client, auth_headers):
    r = client.get("/api/dashboard", headers=auth_headers)
    assert r.status_code == 200
    d = r.json()
    assert d is not None


def test_usage(client, auth_headers):
    r = client.get("/api/usage", headers=auth_headers)
    assert r.status_code == 200


# ---------- Celery module import ----------

def test_celery_app_imports():
    from app.workers import celery_app as mod

    assert hasattr(mod, "celery_app")
    assert hasattr(mod, "run_pipeline_task")
    assert callable(mod.run_pipeline_task)


def test_createjobrequest_accepts_all_fields():
    from app.models.schemas import CreateJobRequest, TemplateType, AiVisualRequest

    req = CreateJobRequest(
        template=TemplateType.AI_VISUAL,
        script="hello",
        manual_captions="Line one",
        ai_visual=AiVisualRequest(topic="focus", max_scenes=4, image_style="cinematic"),
    )
    assert req.template.value == "ai_visual"
    data = req.model_dump()
    assert data["ai_visual"]["topic"] == "focus"
