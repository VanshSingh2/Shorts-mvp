"""Auth hardening tests: register, login, logout, lockout, password policy."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient


def test_register_success(client: TestClient):
    email = f"ok_{id(client)}@example.com"
    r = client.post(
        "/api/auth/register",
        json={"email": email, "password": "Secure1pass", "name": "Alice"},
    )
    assert r.status_code == 200
    data = r.json()
    assert data["email"] == email
    assert data["plan"] == "free"
    assert data["credits_remaining"] > 0
    assert "password" not in data


def test_register_weak_password(client: TestClient):
    r = client.post(
        "/api/auth/register",
        json={"email": "weak@example.com", "password": "short", "name": "X"},
    )
    assert r.status_code in (400, 422)


def test_register_password_no_digit(client: TestClient):
    r = client.post(
        "/api/auth/register",
        json={"email": "nodigit@example.com", "password": "NoDigitsHere", "name": "X"},
    )
    assert r.status_code == 400
    assert "letter" in r.json()["detail"].lower() or "number" in r.json()["detail"].lower()


def test_register_duplicate(client: TestClient, registered_user):
    _, _, email, password = registered_user
    r = client.post(
        "/api/auth/register",
        json={"email": email, "password": password, "name": "Dup"},
    )
    assert r.status_code == 400
    assert "already" in r.json()["detail"].lower()


def test_login_success(client: TestClient, registered_user):
    user, token, email, password = registered_user
    r = client.post("/api/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200
    data = r.json()
    assert "token" in data
    assert data["user"]["email"] == email
    assert data.get("expires_in_days", 7) >= 1


def test_login_bad_password(client: TestClient, registered_user):
    _, _, email, _ = registered_user
    r = client.post("/api/auth/login", json={"email": email, "password": "WrongPass99"})
    assert r.status_code == 401


def test_me_requires_auth(client: TestClient):
    r = client.get("/api/auth/me")
    assert r.status_code == 401


def test_me_with_token(client: TestClient, auth_headers):
    r = client.get("/api/auth/me", headers=auth_headers)
    assert r.status_code == 200
    assert "email" in r.json()


def test_logout(client: TestClient, registered_user):
    _, token, email, password = registered_user
    headers = {"Authorization": f"Bearer {token}"}
    r = client.post("/api/auth/logout", headers=headers)
    assert r.status_code == 200
    # Token should no longer work
    r2 = client.get("/api/auth/me", headers=headers)
    assert r2.status_code == 401


def test_logout_all(client: TestClient, registered_user):
    user, token, email, password = registered_user
    # Second session
    r2 = client.post("/api/auth/login", json={"email": email, "password": password})
    token2 = r2.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}
    r = client.post("/api/auth/logout-all", headers=headers)
    assert r.status_code == 200
    assert r.json()["revoked"] >= 1
    # Both tokens dead
    assert client.get("/api/auth/me", headers=headers).status_code == 401
    assert client.get("/api/auth/me", headers={"Authorization": f"Bearer {token2}"}).status_code == 401


def test_dashboard_requires_auth(client: TestClient):
    assert client.get("/api/dashboard").status_code == 401


def test_dashboard_ok(client: TestClient, auth_headers):
    r = client.get("/api/dashboard", headers=auth_headers)
    assert r.status_code == 200
    data = r.json()
    assert "user" in data
    assert "limits" in data
