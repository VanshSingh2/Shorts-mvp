"""
HyperFrames integration – alternative AI video renderer.

Uses https://github.com/heygen-com/hyperframes (HTML → deterministic MP4).
Generates a simple vertical 9:16 HTML composition with scenes, captions and
audio, then calls `npx hyperframes render` (or falls back gracefully).

Requires Node.js >= 22 and FFmpeg on the host. When HyperFrames is unavailable
the caller should fall back to the existing Ken Burns path.
"""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
import textwrap
from pathlib import Path
from typing import List, Optional

from app.core.config import settings

logger = logging.getLogger(__name__)


def hyperframes_available() -> bool:
    """Check whether the HyperFrames CLI can be invoked."""
    if not getattr(settings, "HYPERFRAMES_ENABLED", False):
        return False
    # Prefer npx (no global install required)
    npx = shutil.which("npx")
    if not npx:
        return False
    try:
        r = subprocess.run(
            [npx, "--yes", "hyperframes", "--version"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        return r.returncode == 0
    except Exception:
        return False


def _escape_html(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def build_faceless_composition(
    work_dir: Path,
    *,
    image_paths: List[Path],
    audio_path: Path,
    caption_lines: List[str],
    title: str = "",
    width: int = 1080,
    height: int = 1920,
    fps: int = 30,
) -> Path:
    """
    Write a minimal HyperFrames HTML composition for a faceless vertical reel.
    Each image becomes a timed scene with Ken-Burns-ish CSS + GSAP.
    Returns path to the composition directory (contains index.html).
    """
    comp_dir = work_dir / "hyperframes_comp"
    comp_dir.mkdir(parents=True, exist_ok=True)
    media = comp_dir / "media"
    media.mkdir(exist_ok=True)

    # Copy assets next to the HTML so relative paths work
    local_images = []
    for i, src in enumerate(image_paths):
        dst = media / f"scene_{i:02d}{src.suffix or '.jpg'}"
        shutil.copy2(src, dst)
        local_images.append(f"media/{dst.name}")

    local_audio = media / f"voice{audio_path.suffix or '.mp3'}"
    shutil.copy2(audio_path, local_audio)
    audio_rel = f"media/{local_audio.name}"

    # Probe audio duration roughly via ffprobe if available
    duration = 12.0 * max(1, len(local_images))
    try:
        r = subprocess.run(
            [
                "ffprobe", "-v", "error", "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path),
            ],
            capture_output=True, text=True, timeout=15,
        )
        if r.returncode == 0 and r.stdout.strip():
            duration = max(float(r.stdout.strip()), 4.0)
    except Exception:
        pass

    scene_dur = duration / max(1, len(local_images))
    scenes_html = []
    for i, img in enumerate(local_images):
        start = i * scene_dur
        scenes_html.append(
            f'''
  <div class="clip scene" data-start="{start:.2f}" data-duration="{scene_dur:.2f}" data-track-index="0"
       style="background-image:url('{img}'); background-size:cover; background-position:center;
              width:100%; height:100%; position:absolute; inset:0; transform-origin:center center;">
  </div>'''
        )

    caption_html = ""
    if caption_lines:
        # Simple timed captions – distribute evenly
        slot = duration / max(1, len(caption_lines))
        for i, line in enumerate(caption_lines[:24]):
            start = i * slot
            caption_html += f'''
  <div class="clip caption" data-start="{start:.2f}" data-duration="{min(slot * 1.1, 4.5):.2f}" data-track-index="2"
       style="position:absolute; left:5%; right:5%; bottom:12%; text-align:center;
              font-family:system-ui,sans-serif; font-size:48px; font-weight:800;
              color:#fff; text-shadow:0 2px 12px #000, 0 0 4px #000; line-height:1.25;">
    {_escape_html(line)}
  </div>'''

    title_html = ""
    if title:
        title_html = f'''
  <h1 class="clip" data-start="0" data-duration="2.5" data-track-index="1"
      id="title"
      style="position:absolute; top:8%; left:6%; right:6%; text-align:center;
             font-family:system-ui,sans-serif; font-size:56px; font-weight:900;
             color:#fff; text-shadow:0 3px 16px #000;">
    {_escape_html(title[:80])}
  </h1>'''

    html = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Shorts MVP – HyperFrames</title>
  <style>
    html, body {{ margin:0; padding:0; background:#000; overflow:hidden; }}
    #stage {{ width:{width}px; height:{height}px; position:relative; background:#111; overflow:hidden; }}
    .scene {{ will-change: transform; }}
  </style>
</head>
<body>
<div id="stage"
     data-composition-id="shorts-mvp"
     data-start="0"
     data-duration="{duration:.2f}"
     data-width="{width}"
     data-height="{height}"
     data-fps="{fps}">
{"".join(scenes_html)}
{title_html}
{caption_html}
  <audio data-start="0" data-duration="{duration:.2f}" data-track-index="3"
         data-volume="1" src="{audio_rel}"></audio>

  <script src="https://cdn.jsdelivr.net/npm/gsap@3/dist/gsap.min.js"></script>
  <script>
    const tl = gsap.timeline({{ paused: true }});
    // Gentle Ken Burns on each scene
    document.querySelectorAll('.scene').forEach((el, i) => {{
      const start = parseFloat(el.dataset.start || 0);
      tl.fromTo(el,
        {{ scale: 1.0, opacity: 0.85 }},
        {{ scale: 1.12, opacity: 1, duration: parseFloat(el.dataset.duration || 3) * 0.9, ease: "none" }},
        start
      );
    }});
    // Title fade
    const title = document.getElementById('title');
    if (title) {{
      tl.from(title, {{ opacity: 0, y: 30, duration: 0.7 }}, 0.15);
      tl.to(title, {{ opacity: 0, duration: 0.4 }}, 2.1);
    }}
    // Captions pop in
    document.querySelectorAll('.caption').forEach((el) => {{
      const start = parseFloat(el.dataset.start || 0);
      tl.from(el, {{ opacity: 0, y: 18, duration: 0.35 }}, start);
    }});
    window.__timelines = window.__timelines || {{}};
    window.__timelines['shorts-mvp'] = tl;
  </script>
</div>
</body>
</html>
"""
    index = comp_dir / "index.html"
    index.write_text(html, encoding="utf-8")
    # Minimal package hint for HyperFrames
    (comp_dir / "hyperframes.json").write_text(
        json.dumps({"name": "shorts-mvp", "entry": "index.html"}, indent=2),
        encoding="utf-8",
    )
    return comp_dir


def render_composition(
    composition_dir: Path,
    output_path: Path,
    *,
    timeout_sec: int = 300,
) -> Path:
    """
    Run `npx hyperframes render` inside the composition directory.
    Writes MP4 to output_path.
    """
    npx = shutil.which("npx")
    if not npx:
        raise RuntimeError("npx not found – install Node.js >= 22 to use HyperFrames")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    # HyperFrames typically writes to ./renders/ by default; we pass output if supported
    cmd = [
        npx, "--yes", "hyperframes", "render",
        "--out", str(output_path),
    ]
    # Some versions use positional / different flags – try modern CLI first
    logger.info(f"HyperFrames render: cwd={composition_dir} → {output_path}")
    result = subprocess.run(
        cmd,
        cwd=str(composition_dir),
        capture_output=True,
        text=True,
        timeout=timeout_sec,
    )
    if result.returncode != 0:
        # Fallback: try without --out and move the result
        logger.warning(f"hyperframes render --out failed: {result.stderr[-400:]}")
        cmd2 = [npx, "--yes", "hyperframes", "render"]
        result2 = subprocess.run(
            cmd2,
            cwd=str(composition_dir),
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
        if result2.returncode != 0:
            raise RuntimeError(
                f"HyperFrames render failed:\n{result.stderr[-600:]}\n{result2.stderr[-600:]}"
            )
        # Find newest mp4 under composition_dir / renders
        candidates = list(composition_dir.rglob("*.mp4"))
        if not candidates:
            raise RuntimeError("HyperFrames finished but no MP4 found")
        newest = max(candidates, key=lambda p: p.stat().st_mtime)
        shutil.copy2(newest, output_path)
    if not output_path.exists():
        raise RuntimeError("HyperFrames reported success but output file missing")
    return output_path


async def render_ai_visual_with_hyperframes(
    work_dir: Path,
    *,
    image_paths: List[Path],
    audio_path: Path,
    segments: List[Any],
    output_path: Path,
    title: str = "",
) -> Path:
    """High-level helper used by the pipeline."""
    caption_lines = []
    for seg in segments or []:
        t = (getattr(seg, "text", None) or "").strip()
        if t:
            caption_lines.append(t)

    w = getattr(settings, "TARGET_WIDTH", 1080)
    h = getattr(settings, "TARGET_HEIGHT", 1920)
    comp = build_faceless_composition(
        work_dir,
        image_paths=image_paths,
        audio_path=audio_path,
        caption_lines=caption_lines,
        title=title,
        width=w,
        height=h,
    )
    return render_composition(comp, output_path)
