"""User + usage service. Hardened auth: bcrypt, persistent tokens with expiry, lockout."""
from __future__ import annotations

import re
import secrets
import uuid
from datetime import datetime, timedelta
from typing import Optional

from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.database import UserRow, JobRow, CreditLedger, SessionToken, SessionLocal, init_db
from app.models.schemas import UserResponse, UsageLimits

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def _bcrypt_hash(password: str) -> str:
    import bcrypt as _bc
    return _bc.hashpw(password.encode("utf-8"), _bc.gensalt()).decode("utf-8")

def _bcrypt_verify(password: str, password_hash: str) -> bool:
    if not password_hash:
        return False
    import bcrypt as _bc
    try:
        ph = password_hash.encode("utf-8") if isinstance(password_hash, str) else password_hash
        return _bc.checkpw(password.encode("utf-8"), ph)
    except Exception:
        try:
            return pwd_context.verify(password, password_hash)
        except Exception:
            return False


# Token lifetime
TOKEN_TTL_DAYS = 7
MAX_FAILED_LOGINS = 8
LOCKOUT_MINUTES = 15


def _validate_password(password: str) -> None:
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters")
    if len(password) > 128:
        raise ValueError("Password too long")
    # Basic strength: at least one letter and one number recommended but not forced for MVP
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        raise ValueError("Password must contain at least one letter and one number")


def _hash_password(password: str) -> tuple[str, str]:
    """Return (hash, salt_placeholder). Salt is embedded in bcrypt hash."""
    h = _bcrypt_hash(password)
    return h, "bcrypt"


def _verify_password(password: str, password_hash: str, salt: str) -> bool:
    # Support legacy sha256 salts from earlier versions
    if salt and salt != "bcrypt":
        import hashlib
        h = hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()
        return h == password_hash
    return _bcrypt_verify(password, password_hash)


def _to_response(u: UserRow) -> UserResponse:
    return UserResponse(
        id=u.id,
        email=u.email,
        name=u.name,
        plan=u.plan,
        credits_remaining=u.credits_remaining,
        videos_this_week=u.videos_this_week,
        created_at=u.created_at,
    )


def create_user(email: str, password: str, name: str | None = None) -> UserResponse:
    email = email.lower().strip()
    if not email or "@" not in email:
        raise ValueError("Invalid email")
    _validate_password(password)
    db = SessionLocal()
    try:
        if db.query(UserRow).filter(UserRow.email == email).first():
            raise ValueError("Email already registered")
        uid = str(uuid.uuid4())
        pw_hash, salt = _hash_password(password)
        user = UserRow(
            id=uid,
            email=email,
            name=name,
            password_hash=pw_hash,
            salt=salt,
            plan="free",
            credits_remaining=settings.FREE_CREDITS,
            videos_this_week=0,
            week_start=datetime.utcnow(),
            created_at=datetime.utcnow(),
            is_active=True,
            failed_login_attempts=0,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        return _to_response(user)
    finally:
        db.close()


def authenticate(
    email: str,
    password: str,
    *,
    ip: str | None = None,
    user_agent: str | None = None,
) -> tuple[UserResponse, str]:
    email = email.lower().strip()
    db = SessionLocal()
    try:
        user = db.query(UserRow).filter(UserRow.email == email).first()
        if not user:
            raise ValueError("Invalid credentials")
        if user.is_active is False:
            raise ValueError("Account disabled")
        if user.locked_until and user.locked_until > datetime.utcnow():
            remaining = int((user.locked_until - datetime.utcnow()).total_seconds() / 60) + 1
            raise ValueError(f"Account temporarily locked. Try again in {remaining} minutes.")

        if not _verify_password(password, user.password_hash, user.salt or ""):
            user.failed_login_attempts = (user.failed_login_attempts or 0) + 1
            if user.failed_login_attempts >= MAX_FAILED_LOGINS:
                user.locked_until = datetime.utcnow() + timedelta(minutes=LOCKOUT_MINUTES)
                user.failed_login_attempts = 0
            db.commit()
            raise ValueError("Invalid credentials")

        # Success – reset lockout
        user.failed_login_attempts = 0
        user.locked_until = None
        # Upgrade legacy hash on successful login
        if (user.salt or "") != "bcrypt":
            new_hash, new_salt = _hash_password(password)
            user.password_hash = new_hash
            user.salt = new_salt

        token = secrets.token_urlsafe(32)
        expires = datetime.utcnow() + timedelta(days=TOKEN_TTL_DAYS)
        db.add(SessionToken(
            token=token,
            user_id=user.id,
            created_at=datetime.utcnow(),
            expires_at=expires,
            last_used_at=datetime.utcnow(),
            user_agent=(user_agent or "")[:200] or None,
            ip=(ip or "")[:64] or None,
        ))
        db.commit()
        return _to_response(user), token
    finally:
        db.close()


def logout(token: str) -> bool:
    if not token:
        return False
    db = SessionLocal()
    try:
        row = db.query(SessionToken).filter(SessionToken.token == token).first()
        if row:
            db.delete(row)
            db.commit()
            return True
        return False
    finally:
        db.close()


def logout_all(user_id: str) -> int:
    db = SessionLocal()
    try:
        rows = db.query(SessionToken).filter(SessionToken.user_id == user_id).all()
        n = len(rows)
        for r in rows:
            db.delete(r)
        db.commit()
        return n
    finally:
        db.close()


def get_user_by_token(token: str | None) -> Optional[UserResponse]:
    if not token:
        return None
    db = SessionLocal()
    try:
        row = db.query(SessionToken).filter(SessionToken.token == token).first()
        if not row:
            return None
        if row.expires_at < datetime.utcnow():
            db.delete(row)
            db.commit()
            return None
        # Touch last_used
        row.last_used_at = datetime.utcnow()
        db.commit()
        user = db.query(UserRow).filter(UserRow.id == row.user_id).first()
        if not user or user.is_active is False:
            return None
        return _to_response(user)
    finally:
        db.close()


def get_user(uid: str) -> Optional[UserResponse]:
    db = SessionLocal()
    try:
        u = db.query(UserRow).filter(UserRow.id == uid).first()
        return _to_response(u) if u else None
    finally:
        db.close()


def _reset_week_if_needed(user: UserRow, db: Session):
    if datetime.utcnow() - user.week_start > timedelta(days=7):
        user.videos_this_week = 0
        user.week_start = datetime.utcnow()
        db.commit()


def check_and_consume_credit(user_id: str, cost: int = 1) -> bool:
    """Atomically consume credits with a row lock to reduce race conditions."""
    from sqlalchemy import update
    db = SessionLocal()
    try:
        q = db.query(UserRow).filter(UserRow.id == user_id)
        try:
            user = q.with_for_update().first()
        except Exception:
            # SQLite / backends without row locking
            user = q.first()
        if not user:
            return False
        _reset_week_if_needed(user, db)
        weekly_cap = {
            "free": settings.FREE_VIDEOS_PER_WEEK,
            "pro": settings.PRO_VIDEOS_PER_WEEK,
            "studio": 9999,
        }.get(user.plan, settings.FREE_VIDEOS_PER_WEEK)
        if user.videos_this_week >= weekly_cap:
            return False
        if user.credits_remaining < cost:
            return False
        user.credits_remaining -= cost
        user.videos_this_week += 1
        db.add(CreditLedger(user_id=user_id, delta=-cost, reason="job_consume"))
        db.commit()
        return True
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def add_credits(user_id: str, amount: int, reason: str = "purchase", stripe_payment_id: str | None = None):
    db = SessionLocal()
    try:
        user = db.query(UserRow).filter(UserRow.id == user_id).first()
        if not user:
            return
        user.credits_remaining += amount
        db.add(CreditLedger(user_id=user_id, delta=amount, reason=reason, stripe_payment_id=stripe_payment_id))
        db.commit()
    finally:
        db.close()


def set_plan(user_id: str, plan: str, stripe_sub_id: str | None = None, stripe_customer_id: str | None = None):
    db = SessionLocal()
    try:
        user = db.query(UserRow).filter(UserRow.id == user_id).first()
        if not user:
            return
        user.plan = plan
        if stripe_sub_id:
            user.stripe_subscription_id = stripe_sub_id
        if stripe_customer_id:
            user.stripe_customer_id = stripe_customer_id
        monthly = {"pro": settings.PRO_CREDITS_MONTHLY, "studio": settings.STUDIO_CREDITS_MONTHLY}.get(plan, 0)
        if monthly:
            user.credits_remaining += monthly
            db.add(CreditLedger(user_id=user_id, delta=monthly, reason=f"plan_{plan}_grant"))
        db.commit()
    finally:
        db.close()


def usage_limits(user_id: str) -> UsageLimits:
    if not user_id:
        return UsageLimits(
            plan="anonymous",
            max_videos_per_week=3,
            max_batch_size=1,
            credits_remaining=3,
            voice_clone_enabled=False,
            storage_used_mb=0,
            storage_limit_mb=50,
        )
    db = SessionLocal()
    try:
        user = db.query(UserRow).filter(UserRow.id == user_id).first()
        if not user:
            return usage_limits("")
        _reset_week_if_needed(user, db)
        plan = user.plan
        return UsageLimits(
            plan=plan,
            max_videos_per_week={
                "free": settings.FREE_VIDEOS_PER_WEEK,
                "pro": settings.PRO_VIDEOS_PER_WEEK,
                "studio": 9999,
            }.get(plan, 15),
            max_batch_size={
                "free": settings.FREE_BATCH_SIZE,
                "pro": settings.PRO_BATCH_SIZE,
                "studio": settings.STUDIO_BATCH_SIZE,
            }.get(plan, 3),
            credits_remaining=user.credits_remaining,
            voice_clone_enabled=plan != "free",
            storage_used_mb=round((user.storage_used_bytes or 0) / (1024 * 1024), 2),
            storage_limit_mb={
                "free": settings.FREE_STORAGE_MB,
                "pro": settings.PRO_STORAGE_MB,
                "studio": settings.STUDIO_STORAGE_MB,
            }.get(plan, 500),
        )
    finally:
        db.close()


def update_storage(user_id: str, delta_bytes: int):
    db = SessionLocal()
    try:
        user = db.query(UserRow).filter(UserRow.id == user_id).first()
        if user:
            user.storage_used_bytes = max(0, (user.storage_used_bytes or 0) + delta_bytes)
            db.commit()
    finally:
        db.close()


def dashboard_stats(user_id: str) -> dict:
    db = SessionLocal()
    try:
        user = db.query(UserRow).filter(UserRow.id == user_id).first()
        if not user:
            return {}
        jobs = db.query(JobRow).filter(JobRow.user_id == user_id).all()
        completed = [j for j in jobs if j.status == "completed"]
        failed = [j for j in jobs if j.status == "failed"]
        ledger = (
            db.query(CreditLedger)
            .filter(CreditLedger.user_id == user_id)
            .order_by(CreditLedger.created_at.desc())
            .limit(20)
            .all()
        )
        return {
            "user": _to_response(user),
            "totals": {
                "jobs": len(jobs),
                "completed": len(completed),
                "failed": len(failed),
                "storage_mb": round((user.storage_used_bytes or 0) / (1024 * 1024), 2),
            },
            "recent_ledger": [
                {"delta": l.delta, "reason": l.reason, "at": l.created_at.isoformat()} for l in ledger
            ],
            "limits": usage_limits(user_id).model_dump(),
        }
    finally:
        db.close()


def save_job_row(job_data: dict):
    db = SessionLocal()
    try:
        existing = db.query(JobRow).filter(JobRow.id == job_data["id"]).first()
        if existing:
            for k, v in job_data.items():
                if hasattr(existing, k) and k != "id":
                    setattr(existing, k, v)
            existing.updated_at = datetime.utcnow()
        else:
            row = JobRow(**{k: v for k, v in job_data.items() if hasattr(JobRow, k)})
            db.add(row)
        db.commit()
    finally:
        db.close()


def load_job_row(job_id: str) -> Optional[JobRow]:
    db = SessionLocal()
    try:
        return db.query(JobRow).filter(JobRow.id == job_id).first()
    finally:
        db.close()


def list_job_rows(user_id: str | None = None, limit: int = 20) -> list:
    db = SessionLocal()
    try:
        q = db.query(JobRow)
        if user_id:
            q = q.filter(JobRow.user_id == user_id)
        return q.order_by(JobRow.created_at.desc()).limit(limit).all()
    finally:
        db.close()


def can_store(user_id: str, additional_bytes: int = 0) -> bool:
    limits = usage_limits(user_id)
    used = limits.storage_used_mb
    limit = limits.storage_limit_mb
    add_mb = additional_bytes / (1024 * 1024)
    return (used + add_mb) <= limit


def cleanup_expired_tokens() -> int:
    """Delete expired session tokens. Call periodically."""
    db = SessionLocal()
    try:
        rows = db.query(SessionToken).filter(SessionToken.expires_at < datetime.utcnow()).all()
        n = len(rows)
        for r in rows:
            db.delete(r)
        db.commit()
        return n
    finally:
        db.close()


def count_active_jobs(user_id: str) -> int:
    """Jobs still running for concurrency limits."""
    if not user_id:
        return 0
    db = SessionLocal()
    try:
        active = ("pending", "processing", "transcribing", "generating_voice", "composing")
        return (
            db.query(JobRow)
            .filter(JobRow.user_id == user_id, JobRow.status.in_(active))
            .count()
        )
    finally:
        db.close()


def can_start_job(user_id: str) -> tuple[bool, str]:
    """Check concurrent render slots for plan."""
    from app.services.billing.plans import concurrent_limit_for_plan
    if not user_id:
        return True, ""
    db = SessionLocal()
    try:
        user = db.query(UserRow).filter(UserRow.id == user_id).first()
        if not user:
            return False, "User not found"
        if not user.is_active:
            return False, "Account disabled"
        limit = concurrent_limit_for_plan(user.plan)
        active = count_active_jobs(user_id)
        if active >= limit:
            return False, f"Concurrent job limit reached ({active}/{limit}). Wait for a render to finish or upgrade."
        return True, ""
    finally:
        db.close()


def list_sessions(user_id: str) -> list[dict]:
    db = SessionLocal()
    try:
        rows = (
            db.query(SessionToken)
            .filter(SessionToken.user_id == user_id)
            .order_by(SessionToken.last_used_at.desc())
            .limit(50)
            .all()
        )
        now = datetime.utcnow()
        out = []
        for r in rows:
            out.append({
                "token_prefix": (r.token or "")[:8] + "…",
                "created_at": r.created_at.isoformat() if r.created_at else None,
                "expires_at": r.expires_at.isoformat() if r.expires_at else None,
                "last_used_at": r.last_used_at.isoformat() if r.last_used_at else None,
                "ip": r.ip,
                "expired": bool(r.expires_at and r.expires_at < now),
            })
        return out
    finally:
        db.close()
