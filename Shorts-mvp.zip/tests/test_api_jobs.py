"""Job API integration with auth and validation."""
from fastapi.testclient import TestClient


def test_create_standard_job_anonymous(client: TestClient):
    # may require credits when logged in; anonymous OK in bootstrap
    r = client.post(
        "/api/jobs",
        data={
            "template": "standard",
            "script": "This is a reasonably long test script for creating a short video job.",
            "caption_style": "classic",
            "voice": "en-US-JennyNeural",
        },
    )
    # 200 created or 402 if free requires auth - either is valid product behavior
    assert r.status_code in (200, 201, 402, 400), r.text


def test_list_jobs_anon_empty(client: TestClient):
    r = client.get("/api/jobs")
    assert r.status_code == 200
    assert r.json() == []


def test_get_unknown_job(client: TestClient):
    r = client.get("/api/jobs/not-a-real-job-id-12345")
    assert r.status_code == 404


def test_health_and_ready(client: TestClient):
    h = client.get("/api/health")
    assert h.status_code == 200
    body = h.json()
    assert "version" in body or "status" in body or "ok" in str(body).lower() or body


def test_plans_list(client: TestClient):
    r = client.get("/api/billing/plans")
    assert r.status_code == 200
    assert isinstance(r.json(), (list, dict))


def test_legal_pages(client: TestClient):
    for path in ("/terms", "/privacy", "/content-policy"):
        r = client.get(path)
        assert r.status_code == 200
        assert len(r.text) > 100


def test_backgrounds_list(client: TestClient):
    r = client.get("/api/backgrounds")
    assert r.status_code == 200
    assert isinstance(r.json(), list)
