from pathlib import Path
from app.services.pipeline import _discover_extra_outputs, _resolve_bg
from app.core.config import settings


def test_resolve_bg_blocks_traversal(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "BACKGROUND_DIR", tmp_path)
    (tmp_path / "ok.mp4").write_bytes(b"x")
    assert _resolve_bg("ok.mp4") is not None
    assert _resolve_bg("../ok.mp4") is None
    assert _resolve_bg("foo/../ok.mp4") is None


def test_discover_extra_outputs(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "OUTPUT_DIR", tmp_path)
    jid = "abc-123"
    (tmp_path / f"{jid}.mp4").write_bytes(b"1")
    (tmp_path / f"{jid}_clip2.mp4").write_bytes(b"2")
    urls = _discover_extra_outputs(jid)
    assert urls is not None
    assert len(urls) == 2
    assert urls[0].endswith(f"{jid}.mp4")
