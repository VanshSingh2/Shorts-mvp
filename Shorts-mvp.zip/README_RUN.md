# Shorts MVP — Run Guide

## Quick start (single process, no Redis)

```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
./run.sh
```

Open http://localhost:8000

Jobs run via FastAPI BackgroundTasks when Redis is not available.

## Production-style (Redis + Celery workers)

**1. Start Redis + Postgres (optional but recommended):**

```bash
# from repo root
docker compose up -d redis postgres
```

**2. API**

```bash
cd backend
export DATABASE_URL=postgresql://shorts:shorts@localhost:5432/shorts
export CELERY_BROKER_URL=redis://localhost:6379/0
export CELERY_RESULT_BACKEND=redis://localhost:6379/1
./run.sh
```

**3. Worker (separate terminal)**

```bash
cd backend
export CELERY_BROKER_URL=redis://localhost:6379/0
export CELERY_RESULT_BACKEND=redis://localhost:6379/1
./run-worker.sh
# or: CELERY_CONCURRENCY=4 ./run-worker.sh
```

**Full stack Docker:**

```bash
docker compose up --build
```

## Payments

- Stripe: set `STRIPE_SECRET_KEY` + webhook secret
- Crypto: set `NOWPAYMENTS_API_KEY` (+ optional IPN secret)
- Without keys, both providers **simulate** and grant credits/plans

## Health

`GET /api/health` → `redis_available`, `queue_backend` (`celery` | `background`)

## Tests

```bash
cd backend
PYTHONPATH=. pytest tests/ -q
```
